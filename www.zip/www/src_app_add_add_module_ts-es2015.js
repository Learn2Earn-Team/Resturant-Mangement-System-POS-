(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_add_add_module_ts"],{

/***/ 14811:
/*!*******************************************!*\
  !*** ./src/app/add/add-routing.module.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddPageRoutingModule": function() { return /* binding */ AddPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _add_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add.page */ 58566);




const routes = [
    {
        path: '',
        component: _add_page__WEBPACK_IMPORTED_MODULE_0__.AddPage
    }
];
let AddPageRoutingModule = class AddPageRoutingModule {
};
AddPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddPageRoutingModule);



/***/ }),

/***/ 9454:
/*!***********************************!*\
  !*** ./src/app/add/add.module.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddPageModule": function() { return /* binding */ AddPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _add_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add-routing.module */ 14811);
/* harmony import */ var _add_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add.page */ 58566);







let AddPageModule = class AddPageModule {
};
AddPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _add_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddPageRoutingModule
        ],
        declarations: [_add_page__WEBPACK_IMPORTED_MODULE_1__.AddPage]
    })
], AddPageModule);



/***/ }),

/***/ 58566:
/*!*********************************!*\
  !*** ./src/app/add/add.page.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddPage": function() { return /* binding */ AddPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_add_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./add.page.html */ 42871);
/* harmony import */ var _add_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add.page.scss */ 56204);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);







let AddPage = class AddPage {
    constructor(route, global, apicall) {
        this.route = route;
        this.global = global;
        this.apicall = apicall;
        this.data = { id: "", quantity: "", price: "", dealer: "" };
    }
    ngOnInit() {
        this.folder = "Café Verona";
        this.global.User.subscribe(res => {
            if (res == "") {
                this.route.navigate(["/home"]);
            }
        });
    }
    add() {
        this.global.Selected.subscribe(res => {
            this.data.id = res;
        });
        this.apicall.insertstock(this.data);
    }
};
AddPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService }
];
AddPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-add',
        template: _raw_loader_add_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_add_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddPage);



/***/ }),

/***/ 56204:
/*!***********************************!*\
  !*** ./src/app/add/add.page.scss ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".center {\n  background-color: rgba(0, 0, 0, 0.4);\n  border-radius: 20px;\n  padding-bottom: 10px;\n  margin: 10px;\n}\n.center .head {\n  padding-top: 14px;\n  justify-content: center;\n  margin-bottom: 18px;\n  margin-top: 18px;\n}\n.center .fields {\n  justify-content: center;\n  margin: 17px;\n}\n.center .fields ion-input {\n  border: none;\n  border-bottom: 1px solid #929191;\n  padding: 5px 10px;\n}\n.center ion-button {\n  margin-left: 10px;\n  margin-right: 10px;\n  height: 3.3rem;\n  margin-top: 23px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0FBQ0o7QUFBSTtFQUNJLGlCQUFBO0VBQ0YsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBRU47QUFBSTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBQUVOO0FBRE07RUFDRSxZQUFBO0VBQ0YsZ0NBQUE7RUFDQSxpQkFBQTtBQUdOO0FBQUk7RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0FBRU4iLCJmaWxlIjoiYWRkLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jZW50ZXJ7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOnJnYigwLCAwLCAwLDAuNCk7XHJcbiAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgcGFkZGluZy1ib3R0b206IDEwcHg7XHJcbiAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAuaGVhZHtcclxuICAgICAgICBwYWRkaW5nLXRvcDogMTRweDtcclxuICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDE4cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDE4cHg7XHJcbiAgICB9XHJcbiAgICAuZmllbGRze1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgbWFyZ2luOiAxN3B4O1xyXG4gICAgICBpb24taW5wdXR7XHJcbiAgICAgICAgYm9yZGVyOm5vbmU7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjOTI5MTkxO1xyXG4gICAgICBwYWRkaW5nOiA1cHggMTBweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaW9uLWJ1dHRvbntcclxuICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogMTBweDtcclxuICAgICAgaGVpZ2h0OiAzLjNyZW07XHJcbiAgICAgIG1hcmdpbi10b3A6IDIzcHg7XHJcbiAgICB9XHJcbiAgfSJdfQ== */");

/***/ }),

/***/ 42871:
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/add/add.page.html ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <div class=\"center\">\n    <ion-row class=\"head\">\n      Item Name\n    </ion-row>\n    <form #form=\"ngForm\" (ngSubmit)=\"add(form)\">\n      <ion-row class=\"fields\">\n        <ion-input type=\"number\" placeholder=\"Quantity In Grams\" name=\"quantity\"  [(ngModel)]=\"data.quantity\"></ion-input>\n      </ion-row>\n      <ion-row class=\"fields\">\n        <ion-input type=\"number\" placeholder=\"Price\" name=\"price\" [(ngModel)]=\"data.price\"></ion-input>\n      </ion-row>\n      <ion-row class=\"fields\">\n        <ion-input type=\"email\" placeholder=\"Dealer Name\" name=\"dealer\" [(ngModel)]=\"data.dealer\"></ion-input>\n      </ion-row>\n      <ion-button expand=\"block\" color=\"dark\"  type=\"submit\"  [disabled]=\"form.invalid || input\">Add</ion-button>\n    </form>\n  </div>\n\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_add_add_module_ts-es2015.js.map