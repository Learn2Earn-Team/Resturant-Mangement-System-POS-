(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["default-src_app_provider_apicall_service_ts"],{

/***/ 39829:
/*!*******************************************!*\
  !*** ./src/app/provider/alert.service.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AlertService": function() { return /* binding */ AlertService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic/angular */ 80476);



let AlertService = class AlertService {
    constructor(Alert, nav) {
        this.Alert = Alert;
        this.nav = nav;
    }
    loginAlert() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Welcome',
                message: 'Your Are Successfully Login',
                buttons: [
                    {
                        text: 'Okay',
                    }
                ]
            });
            yield alert.present();
        });
    }
    signup() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Congrats',
                subHeader: 'Your Are Successfully Registered',
                message: 'Now please Login',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    password() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Sorry',
                message: 'Password not Matched',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    email() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                message: 'Invalid Email',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    invalidlogin() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                message: 'Invalid User name or Password',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    connection() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                subHeader: 'Check your Internet connection',
                message: 'Connection failed!',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    invalidpass() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                subHeader: 'please inter Valid password',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    call(message) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Cafe Verona',
                subHeader: message,
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    country() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                message: 'Sorry We Dont Deliver to Any Country Except Orange',
                buttons: [{
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/Home');
                        },
                    }]
            });
            yield alert.present();
        });
    }
    allready() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'This Email is Already Exist',
                message: 'Please login',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    oldincorrect() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'Old Password Incorrect',
                message: 'Please Try Again',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
    newmatch() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'New Passwords Dont Match',
                message: 'Try Again',
                buttons: ['Ok']
            });
            yield alert.present();
        });
    }
    updateprofile() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Succesfull',
                subHeader: 'Profile updated',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/tabs/tab3');
                        },
                    }
                ]
            });
            yield alert.present();
        });
    }
    passupdate() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Succesfull',
                subHeader: 'Password updated',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/editprofile');
                        },
                    }
                ]
            });
            yield alert.present();
        });
    }
    addpost() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Succesfull',
                subHeader: 'Your Add has Been Posted',
                buttons: [
                    {
                        text: 'Okay',
                        handler: () => {
                            this.nav.navigateForward('/tabs/tab3');
                        },
                    }
                ]
            });
            yield alert.present();
        });
    }
    services() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.Alert.create({
                header: 'Ooops',
                subHeader: 'please select appropriate services related  sub service',
                buttons: ['ok']
            });
            yield alert.present();
        });
    }
};
AlertService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.NavController }
];
AlertService = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], AlertService);



/***/ }),

/***/ 10119:
/*!*********************************************!*\
  !*** ./src/app/provider/apicall.service.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ApicallService": function() { return /* binding */ ApicallService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./auth.service */ 62430);
/* harmony import */ var _global_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./global.service */ 82836);
/* harmony import */ var _alert_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./alert.service */ 39829);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 80476);






let ApicallService = class ApicallService {
    constructor(menuCtrl, authservice, global, Alert, navigate) {
        this.menuCtrl = menuCtrl;
        this.authservice = authservice;
        this.global = global;
        this.Alert = Alert;
        this.navigate = navigate;
        // this.authservice.observeHttp.subscribe(data => 
        //   { 
        //     this.prgres=parseInt(JSON.stringify(data))/100; 
        //     console.log(this.prgres);
        //     if(this.prgres==1){
        //     this.getmenu();
        //     this.navigate.navigateBack("/menu");
        //     this.Alert.call("New Categeory Added");
        //     }
        //   }
        //   )  
    }
    api_login(signin) {
        this.authservice.con(signin, 'login').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res));
            if (this.response.error === false) {
                this.global.set_User(this.response.user);
                this.Alert.loginAlert();
                this.navigate.navigateForward("/ordercat");
                return;
            }
            this.Alert.invalidlogin();
            console.log(this.response.error);
            // tslint:disable-next-line: whitespace
        }), (err) => { this.Alert.connection(); });
    }
    api_getallproducts() {
        this.authservice.getdata('viewrawcat').then((result) => {
            this.global.set_Products(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    addcat(data) {
        this.authservice.con(data, 'addrawcat').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Categeory Added");
                this.api_getallproducts();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    addmenucat(data) {
        this.authservice.con(data, 'insertmenucat').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.getmenu();
                this.navigate.navigateBack("/menu");
                this.Alert.call("New Categeory Added");
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    editcat(data) {
        this.authservice.con(data, 'editrawcat').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Categeory Updated");
                this.api_getallproducts();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    editsubcat(data) {
        this.authservice.con(data, 'editrawsub').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Item Editted");
                this.getsub(data.callid);
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    getsub(id) {
        this.authservice.getdata('viewrawsub/' + id).then((data) => {
            this.response = JSON.parse(String(data));
            this.global.set_Subcat(JSON.parse(String(data)));
            console.log(this.response);
            this.navigate.navigateForward("/subcat");
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    getdetails(id) {
        this.authservice.getdata('getsubhistory/' + id).then((data) => {
            this.response = JSON.parse(String(data));
            this.global.set_Cart(JSON.parse(String(data)));
            console.log(this.response);
            this.navigate.navigateForward("/stockdetail");
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    getmenudetails(id) {
        this.authservice.getdata('getallmenu/' + id).then((data) => {
            this.response = JSON.parse(String(data));
            console.log(this.response);
            this.global.set_Menusub(JSON.parse(String(data)));
        }, (err) => {
            this.Alert.connection();
        });
    }
    getmenu() {
        this.authservice.getdata('getallmenucategory').then((data) => {
            console.log(data);
            this.response = JSON.parse(String(data));
            this.global.set_Menu(JSON.parse(String(data)));
        }, (err) => {
            this.Alert.connection();
        });
    }
    getorder() {
        this.authservice.getdata('getallorder').then((data) => {
            this.all = (JSON.parse(String(data)));
            this.global.set_All(this.all);
            this.global.set_Pending(this.all.filter(data => data.o_status == "pending"));
            this.global.set_Cancelled(this.all.filter(data => data.o_status == "cancelled"));
            this.global.set_Completed(this.all.filter(data => data.o_status == "completed"));
        }, (err) => {
            this.Alert.connection();
        });
    }
    getstock() {
        this.authservice.getdata('getallstock').then((data) => {
            this.response = JSON.parse(String(data));
            console.log(this.response);
            this.less = this.response.filter(data => data.is_remaining < data.min_quantity);
            this.global.set_Stock(this.response);
            this.global.set_Less(this.less);
            console.log(this.response);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    addsub(data) {
        this.authservice.con(data, 'addrawsub').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Added New Item");
                this.getsub(data.id);
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    addorder(data) {
        this.authservice.con(data, 'addorder').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            this.updatordergradients(this.response);
            console.log(this.response);
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    updatordergradients(data) {
        ;
        this.authservice.con(data, 'updatordergradients').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Order Placed");
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_showtransaction(data) {
        ;
        this.authservice.con(data, 'gettransaction').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            this.global.set_Transactiondetail(this.response);
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    editorder(data) {
        this.authservice.con(data, 'updateorderstatus').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Order Status Updated");
                this.getorder();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    insertmenusub(data) {
        this.authservice.con(data, 'insertmenusubcat').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Added New Item");
                this.global.Id.subscribe(res => {
                    this.getmenudetails(res);
                    this.navigate.navigateBack(["/menuitem"]);
                });
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    insertstock(data) {
        this.authservice.con(data, 'insertpurchase').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("Stock Inserted");
                this.navigate.navigateBack("/subcat");
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addorder(data1) {
        this.authservice.con(data1, 'addorder').then((res) => {
            console.log(res);
            this.response = JSON.parse(String(res));
            console.log(this.response.message);
            if (this.response.error === true && this) {
                if (this.response.error1 === true) {
                    this.Alert.oldincorrect();
                    return;
                }
                this.Alert.connection();
                return;
            }
            if (this.response.error === false) {
                this.Alert.passupdate();
            }
        }, (err) => { this.Alert.connection(); });
    }
    getprofile() {
        this.global.User.subscribe((user) => {
            console.log('user from global = ' + JSON.stringify(user));
            this.authservice.getdata('getprofile/' + user.userid).then((data) => {
                this.global.set_User(JSON.parse(String(data)));
                console.log(' user profile = ' + data);
            });
        });
    }
    api_city() {
        this.authservice.getdata('getcity').then((result) => {
            this.global.set_City(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_subcat() {
        this.authservice.getdata('getallsub').then((result) => {
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_subcat1() {
        this.authservice.getdata('getallsub1').then((result) => {
            this.global.set_SubServices1(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_subcat2() {
        this.authservice.getdata('getallsub2').then((result) => {
            this.global.set_SubServices2(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getcustomer() {
        this.authservice.getdata('getcustomer').then((result) => {
            this.global.set_Customer(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getcustomerdetails(id) {
        this.authservice.getdata('getcustomerdetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Customerdetails(this.data);
            console.log(this.data);
            // this.router.navigate(['customerdetail']);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addcustomer(data) {
        this.authservice.con(data, 'insertcustomer').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Customer Added");
                this.api_getcustomer();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_updatecustomerbalance(data) {
        this.authservice.con(data, 'updatecustomerbalance').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getseller() {
        this.authservice.getdata('getseller').then((result) => {
            this.global.set_Seller(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_getsellerdetails(id) {
        this.authservice.getdata('getsellerdetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Sellerdetails(this.data);
            console.log(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_updatesellerbalance(data) {
        this.authservice.con(data, 'updatesellerbalance').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.data = JSON.parse(String(res));
        }), (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addseller(data) {
        this.authservice.con(data, 'insertseller').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Customer Added");
                this.api_getcustomer();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_getexpense() {
        this.authservice.getdata('getexpense').then((result) => {
            this.global.set_Expense(JSON.parse(String(result)));
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
    api_addexpense(data) {
        this.authservice.con(data, 'insertexpense').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Customer Added");
                this.api_getexpense();
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_addexpensedetails(data) {
        this.authservice.con(data, 'insertexpensedetail').then((res) => (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(this, void 0, void 0, function* () {
            this.response = JSON.parse(String(res).toString());
            if (this.response.error === false) {
                this.Alert.call("New Customer Added");
                return;
            }
        }), (err) => {
            console.log(err);
            this.Alert.connection();
        });
    }
    api_getexpensedetails(id) {
        this.authservice.getdata('getexpensedetail/' + id).then((result) => {
            this.data = JSON.parse(String(result));
            this.global.set_Expensedetails(this.data);
            console.log(this.data);
        }, (err) => {
            this.Alert.connection();
            console.log(err);
        });
    }
};
ApicallService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController },
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService },
    { type: _global_service__WEBPACK_IMPORTED_MODULE_1__.GlobalService },
    { type: _alert_service__WEBPACK_IMPORTED_MODULE_2__.AlertService },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController }
];
ApicallService = (0,tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
    })
], ApicallService);



/***/ }),

/***/ 62430:
/*!******************************************!*\
  !*** ./src/app/provider/auth.service.ts ***!
  \******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AuthService": function() { return /* binding */ AuthService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 79765);




const apiUrl = 'https://Learn2earnn.com/CafeVerona/public/';
//const apiUrl = 'http://localhost/caffeverona/public/';
let AuthService = class AuthService {
    constructor(http) {
        this.http = http;
        this.httpEventListener = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
        this.observeHttp = this.httpEventListener.asObservable();
    }
    //   con(data: any , type: any ) {
    //     // tslint:disable-next-line: no-shadowed-variable
    //     return new Promise((resolve, reject) => {
    //       // tslint:disable-next-line: whitespace
    //       this.http.post(apiUrl+type, JSON.stringify(data),{
    //         reportProgress: true,
    //       }).
    //       subscribe(res=>{
    //        console.log(JSON.stringify(res));
    //         resolve(JSON.stringify(res));
    //       }, (err) => {
    //         reject(err);
    //         console.log(err);
    //       });
    //     });
    //   }
    con(data, type) {
        const req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpRequest('POST', apiUrl + type, data, {
            // headers: You can put your headers type hear such as content/type, token...
            reportProgress: true
        });
        return new Promise((resolve, reject) => {
            this.http.request(req).subscribe((event) => {
                switch (event.type) {
                    case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpEventType.UploadProgress:
                        const percentDone = Math.round(100 * event.loaded / event.total);
                        this.getHttpEvent().next(percentDone);
                        // console.log(`Posting in progress! ${percentDone}% \n
                        // Bytes being upload: ${event.loaded} \n
                        // Total no. of bytes to upload: ${event.total}`);
                        break;
                    case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpEventType.Response:
                        resolve(JSON.stringify(event.body));
                }
            }, err => {
                console.log(err);
                reject(err);
            });
        });
    }
    getHttpEvent() {
        return this.httpEventListener;
    }
    // geting posts
    getdata(type) {
        return new Promise((resolve, reject) => {
            this.http.get(apiUrl + type).
                subscribe(res => {
                resolve(JSON.stringify(res));
            }, (err) => {
                reject(err);
                console.log(err);
            });
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient }
];
AuthService = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
    })
], AuthService);



/***/ })

}]);
//# sourceMappingURL=default-src_app_provider_apicall_service_ts-es2015.js.map