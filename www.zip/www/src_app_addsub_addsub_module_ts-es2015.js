(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_addsub_addsub_module_ts"],{

/***/ 60435:
/*!*************************************************!*\
  !*** ./src/app/addsub/addsub-routing.module.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddsubPageRoutingModule": function() { return /* binding */ AddsubPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _addsub_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addsub.page */ 77321);




const routes = [
    {
        path: '',
        component: _addsub_page__WEBPACK_IMPORTED_MODULE_0__.AddsubPage
    }
];
let AddsubPageRoutingModule = class AddsubPageRoutingModule {
};
AddsubPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], AddsubPageRoutingModule);



/***/ }),

/***/ 91850:
/*!*****************************************!*\
  !*** ./src/app/addsub/addsub.module.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddsubPageModule": function() { return /* binding */ AddsubPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _addsub_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./addsub-routing.module */ 60435);
/* harmony import */ var _addsub_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./addsub.page */ 77321);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ionic-selectable */ 93319);








let AddsubPageModule = class AddsubPageModule {
};
AddsubPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _addsub_routing_module__WEBPACK_IMPORTED_MODULE_0__.AddsubPageRoutingModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_7__.IonicSelectableModule
        ],
        declarations: [_addsub_page__WEBPACK_IMPORTED_MODULE_1__.AddsubPage]
    })
], AddsubPageModule);



/***/ }),

/***/ 77321:
/*!***************************************!*\
  !*** ./src/app/addsub/addsub.page.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AddsubPage": function() { return /* binding */ AddsubPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_addsub_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./addsub.page.html */ 6126);
/* harmony import */ var _addsub_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./addsub.page.scss */ 70247);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);








let AddsubPage = class AddsubPage {
    constructor(route, actionSheetCtrl, apicall, global) {
        this.route = route;
        this.actionSheetCtrl = actionSheetCtrl;
        this.apicall = apicall;
        this.global = global;
        this.data = { menu: {}, gradients: [] };
        this.selectedArray = [];
        this.Menu = { id: "", name: "", cost: "", price: "" };
    }
    ngOnInit() {
        this.folder = "Café Verona";
        this.apicall.getstock();
        this.global.Stock.subscribe(res => {
            this.stock = res;
        });
        this.global.Id.subscribe(res => {
            this.Menu.id = res;
        });
        this.global.User.subscribe(res => {
            if (res == "") {
                this.route.navigate(["/home"]);
            }
        });
    }
    onChange() {
        console.log(this.selectedArray);
    }
    check() {
        this.data.menu = this.Menu;
        this.data.gradients = this.selectedArray;
        this.apicall.insertmenusub(this.data);
        console.log(JSON.stringify(this.data));
    }
};
AddsubPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ActionSheetController },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService }
];
AddsubPage = (0,tslib__WEBPACK_IMPORTED_MODULE_6__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-addsub',
        template: _raw_loader_addsub_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_addsub_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AddsubPage);



/***/ }),

/***/ 70247:
/*!*****************************************!*\
  !*** ./src/app/addsub/addsub.page.scss ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".center {\n  background-color: rgba(0, 0, 0, 0.4);\n  border-radius: 20px;\n  padding-bottom: 10px;\n  margin: 10px;\n}\n.center .head {\n  padding-top: 14px;\n  justify-content: center;\n  margin-bottom: 18px;\n  margin-top: 18px;\n}\n.center .fields {\n  justify-content: center;\n  margin: 17px;\n}\n.center .fields ion-input {\n  border: none;\n  border-bottom: 1px solid #929191;\n  padding: 5px 10px;\n}\n.center .fields ion-button {\n  margin-left: 10px;\n  margin-right: 10px;\n  height: 3.3rem;\n  margin-top: 0;\n  width: 20rem;\n}\n.center ion-button {\n  margin-left: 10px;\n  margin-right: 10px;\n  height: 3.3rem;\n  margin-top: 23px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFkZHN1Yi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxvQ0FBQTtFQUNBLG1CQUFBO0VBQ0Esb0JBQUE7RUFDQSxZQUFBO0FBQ0o7QUFBSTtFQUNJLGlCQUFBO0VBQ0YsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBRU47QUFBSTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBQUVOO0FBRE07RUFDRSxZQUFBO0VBQ0YsZ0NBQUE7RUFDQSxpQkFBQTtBQUdOO0FBRE07RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSxZQUFBO0FBR1I7QUFBSTtFQUNFLGlCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7QUFFTiIsImZpbGUiOiJhZGRzdWIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmNlbnRlcntcclxuICAgIGJhY2tncm91bmQtY29sb3I6cmdiKDAsIDAsIDAsMC40KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDIwcHg7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogMTBweDtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIC5oZWFke1xyXG4gICAgICAgIHBhZGRpbmctdG9wOiAxNHB4O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgbWFyZ2luLWJvdHRvbTogMThweDtcclxuICAgICAgbWFyZ2luLXRvcDogMThweDtcclxuICAgIH1cclxuICAgIC5maWVsZHN7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICBtYXJnaW46IDE3cHg7XHJcbiAgICAgIGlvbi1pbnB1dHtcclxuICAgICAgICBib3JkZXI6bm9uZTtcclxuICAgICAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkICM5MjkxOTE7XHJcbiAgICAgIHBhZGRpbmc6IDVweCAxMHB4O1xyXG4gICAgICB9XHJcbiAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICAgIGhlaWdodDogMy4zcmVtO1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICAgICAgd2lkdGg6IDIwcmVtO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpb24tYnV0dG9ue1xyXG4gICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgbWFyZ2luLXJpZ2h0OiAxMHB4O1xyXG4gICAgICBoZWlnaHQ6IDMuM3JlbTtcclxuICAgICAgbWFyZ2luLXRvcDogMjNweDtcclxuICAgIH1cclxuICB9XHJcbiJdfQ== */");

/***/ }),

/***/ 6126:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/addsub/addsub.page.html ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <div class=\"center\">\n    <ion-row class=\"head\">\n      Item Name\n    </ion-row>\n    <ion-row class=\"fields\">\n      <ion-input type=\"text\" placeholder=\"Name\" name=\"name\"  [(ngModel)]=\"Menu.name\"></ion-input>\n    </ion-row>\n    <ion-row class=\"fields\">\n      <ion-input type=\"text\" placeholder=\"Production Cost\" name=\"cost\"  [(ngModel)]=\"Menu.cost\"></ion-input>\n    </ion-row>\n    <ion-row class=\"fields\">\n      <ion-input type=\"text\" placeholder=\"Retail Price\" name=\"price\"  [(ngModel)]=\"Menu.price\"></ion-input>\n    </ion-row>\n<!--    <ion-item lines=\"none\" style=\"&#45;&#45;background: transparent;\">-->\n<!--      <ion-label>Select Gradients</ion-label>-->\n<!--      <ion-select  okText=\"Okay\" multiple=\"true\" cancelText=\"Dismiss\" [(ngModel)]=\"selectedArray\"  (ionChange)=\"onChange()\">-->\n<!--        <ion-select-option *ngFor=\"let a of stock\" [value]=\"{id: a.isc_id, name: a.is_name}\">{{a.is_name}}</ion-select-option>-->\n<!--      </ion-select>-->\n<!--    </ion-item>-->\n    <ion-item lines=\"none\" style=\"--background: transparent;\">\n      <ion-label>Select Gradients</ion-label>\n      <ionic-selectable [(ngModel)]=\"selectedArray\" itemValueField=\"isc_id\" itemTextField=\"is_name\" [items]=\"stock\" [canSearch]=\"true\" [isMultiple]=\"true\"\n                        (onChange)=\"  onChange()\">\n      </ionic-selectable>\n    </ion-item>\n    <ion-row class=\"fields\" *ngFor=\"let a of selectedArray\">\n      <ion-input type=\"text\" placeholder={{a.is_name}} name={{a.is_name}}  [(ngModel)]=\"a.quantity\" ></ion-input>\n    </ion-row>\n    <ion-button expand=\"block\" color=\"dark\" (click)=\"check()\">Add</ion-button>\n  </div>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_addsub_addsub_module_ts-es2015.js.map