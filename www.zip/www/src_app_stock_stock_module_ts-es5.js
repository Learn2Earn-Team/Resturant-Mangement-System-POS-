(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_stock_stock_module_ts"], {
    /***/
    60648:
    /*!***********************************************!*\
      !*** ./src/app/stock/stock-routing.module.ts ***!
      \***********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "StockPageRoutingModule": function StockPageRoutingModule() {
          return (
            /* binding */
            _StockPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _stock_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./stock.page */
      40354);

      var routes = [{
        path: '',
        component: _stock_page__WEBPACK_IMPORTED_MODULE_0__.StockPage
      }];

      var _StockPageRoutingModule = function StockPageRoutingModule() {
        _classCallCheck(this, StockPageRoutingModule);
      };

      _StockPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _StockPageRoutingModule);
      /***/
    },

    /***/
    92718:
    /*!***************************************!*\
      !*** ./src/app/stock/stock.module.ts ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "StockPageModule": function StockPageModule() {
          return (
            /* binding */
            _StockPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _stock_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./stock-routing.module */
      60648);
      /* harmony import */


      var _stock_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./stock.page */
      40354);

      var _StockPageModule = function StockPageModule() {
        _classCallCheck(this, StockPageModule);
      };

      _StockPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _stock_routing_module__WEBPACK_IMPORTED_MODULE_0__.StockPageRoutingModule],
        declarations: [_stock_page__WEBPACK_IMPORTED_MODULE_1__.StockPage]
      })], _StockPageModule);
      /***/
    },

    /***/
    40354:
    /*!*************************************!*\
      !*** ./src/app/stock/stock.page.ts ***!
      \*************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "StockPage": function StockPage() {
          return (
            /* binding */
            _StockPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_stock_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./stock.page.html */
      15084);
      /* harmony import */


      var _stock_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./stock.page.scss */
      39692);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../provider/apicall.service */
      10119);
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../provider/global.service */
      82836);

      var _StockPage = /*#__PURE__*/function () {
        function StockPage(menu, apicall, global) {
          _classCallCheck(this, StockPage);

          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
        }

        _createClass(StockPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.sign = "Purchase";
            this.folder = "Café Verona";
            this.menu.enable(true);
            this.apicall.getstock();
            this.global.Stock.subscribe(function (res) {
              _this.stock = res;
            });
            this.global.Less.subscribe(function (res) {
              _this.less = res;
            });
          }
        }, {
          key: "detail",
          value: function detail(id) {
            this.apicall.getdetails(id);
          }
        }]);

        return StockPage;
      }();

      _StockPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService
        }];
      };

      _StockPage = (0, tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-stock',
        template: _raw_loader_stock_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_stock_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _StockPage);
      /***/
    },

    /***/
    39692:
    /*!***************************************!*\
      !*** ./src/app/stock/stock.page.scss ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".main {\n  margin: 10px;\n  background-color: black;\n  border-radius: 10px;\n}\n.main .right11 {\n  float: right;\n  margin-right: 20px;\n}\n.main .head {\n  display: inline;\n  width: 100%;\n}\n.main .head .left {\n  float: left;\n  margin-left: 10px;\n}\n.main .head .center {\n  margin: 0 auto;\n  margin-top: 16px;\n  width: 100px;\n}\n.main .head .right {\n  float: right;\n  margin-right: 20px;\n  margin-top: -22px;\n}\n.main .body {\n  display: inline;\n  width: 100%;\n}\n.main .body .left1 {\n  float: left;\n  margin-left: 10px;\n}\n.main .body .center1 {\n  margin: 0 auto;\n  margin-top: 15px;\n  width: 100px;\n  padding-left: 30px;\n}\n.main .body .right1 {\n  float: right;\n  margin-right: 20px;\n  margin-top: -22px;\n}\nion-list {\n  background: transparent;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0b2NrLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FBQ0o7QUFBSTtFQUNJLFlBQUE7RUFDQSxrQkFBQTtBQUVSO0FBQUk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQUVSO0FBRFE7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7QUFHWjtBQURRO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQUdaO0FBRFE7RUFDRyxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUdYO0FBQUk7RUFDSSxlQUFBO0VBQ0EsV0FBQTtBQUVSO0FBRFE7RUFDSSxXQUFBO0VBQ0EsaUJBQUE7QUFHWjtBQURRO0VBQ0ksY0FBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBR1o7QUFEUTtFQUNHLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FBR1g7QUFDQTtFQUNJLHVCQUFBO0FBRUoiLCJmaWxlIjoic3RvY2sucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm1haW57XHJcbiAgICBtYXJnaW46IDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsKTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAucmlnaHQxMXtcclxuICAgICAgICBmbG9hdDogcmlnaHQ7IFxyXG4gICAgICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgICB9XHJcbiAgICAuaGVhZHtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgLmxlZnR7XHJcbiAgICAgICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmNlbnRlcntcclxuICAgICAgICAgICAgbWFyZ2luOjAgYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTZweDtcclxuICAgICAgICAgICAgd2lkdGg6MTAwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yaWdodHtcclxuICAgICAgICAgICBmbG9hdDogcmlnaHQ7IFxyXG4gICAgICAgICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgICAgICAgICBtYXJnaW4tdG9wOiAtMjJweDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAuYm9keXtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgLmxlZnQxe1xyXG4gICAgICAgICAgICBmbG9hdDogbGVmdDtcclxuICAgICAgICAgICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5jZW50ZXIxe1xyXG4gICAgICAgICAgICBtYXJnaW46MCBhdXRvO1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAxNXB4O1xyXG4gICAgICAgICAgICB3aWR0aDoxMDBweDtcclxuICAgICAgICAgICAgcGFkZGluZy1sZWZ0OiAzMHB4O1xyXG4gICAgICAgIH1cclxuICAgICAgICAucmlnaHQxe1xyXG4gICAgICAgICAgIGZsb2F0OiByaWdodDsgXHJcbiAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG4gICAgICAgICAgIG1hcmdpbi10b3A6IC0yMnB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG5pb24tbGlzdHtcclxuICAgIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG59Il19 */";
      /***/
    },

    /***/
    15084:
    /*!*****************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stock/stock.page.html ***!
      \*****************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-row>\n    <ion-segment color=\"dark\" [(ngModel)]=\"sign\" mode=\"ios\">\n\n      <ion-segment-button value=\"Purchase\">\n        <ion-label>To be Purchased</ion-label>\n      </ion-segment-button>\n\n      <ion-segment-button value=\"Stock\">\n        <ion-label>All Stock</ion-label>\n      </ion-segment-button>\n\n    </ion-segment>\n  </ion-row>\n\n  <div [ngSwitch]=\"sign\">\n    <ion-list *ngSwitchCase=\"'Purchase'\">\n      <ion-searchbar></ion-searchbar>\n      <ion-row class=\"main\" *ngFor=\"let a of less\" >\n        <ion-row class=\"head\">\n          <p class=\"left\">{{a.is_name}}</p>\n          <p class=\"right11\" style=\"color: red;\">{{a.is_remaining}}</p>\n        </ion-row>\n      </ion-row>\n    </ion-list>\n    <ion-list *ngSwitchCase=\"'Stock'\">\n      <ion-searchbar></ion-searchbar>\n      <ion-row class=\"main\" *ngFor=\"let a of stock\" (click)=\"detail(a.isc_id)\">\n        <ion-row class=\"head\">\n          <p class=\"left\">{{a.is_name}}</p>\n          <p class=\"right11\">{{a.is_remaining}}</p>\n        </ion-row>\n      </ion-row>\n    </ion-list>\n  </div>\n\n</ion-content>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_stock_stock_module_ts-es5.js.map