(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_order_order_module_ts"], {
    /***/
    5649:
    /*!***********************************************!*\
      !*** ./src/app/order/order-routing.module.ts ***!
      \***********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "OrderPageRoutingModule": function OrderPageRoutingModule() {
          return (
            /* binding */
            _OrderPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _order_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./order.page */
      76107);

      var routes = [{
        path: '',
        component: _order_page__WEBPACK_IMPORTED_MODULE_0__.OrderPage
      }];

      var _OrderPageRoutingModule = function OrderPageRoutingModule() {
        _classCallCheck(this, OrderPageRoutingModule);
      };

      _OrderPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _OrderPageRoutingModule);
      /***/
    },

    /***/
    78865:
    /*!***************************************!*\
      !*** ./src/app/order/order.module.ts ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "OrderPageModule": function OrderPageModule() {
          return (
            /* binding */
            _OrderPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _order_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./order-routing.module */
      5649);
      /* harmony import */


      var _order_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./order.page */
      76107);

      var _OrderPageModule = function OrderPageModule() {
        _classCallCheck(this, OrderPageModule);
      };

      _OrderPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _order_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrderPageRoutingModule],
        declarations: [_order_page__WEBPACK_IMPORTED_MODULE_1__.OrderPage]
      })], _OrderPageModule);
      /***/
    },

    /***/
    76107:
    /*!*************************************!*\
      !*** ./src/app/order/order.page.ts ***!
      \*************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "OrderPage": function OrderPage() {
          return (
            /* binding */
            _OrderPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_order_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./order.page.html */
      99578);
      /* harmony import */


      var _order_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./order.page.scss */
      72508);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../provider/apicall.service */
      10119);
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../provider/global.service */
      82836);

      var _OrderPage = /*#__PURE__*/function () {
        function OrderPage(menu, apicall, global) {
          _classCallCheck(this, OrderPage);

          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
          this.data = {
            id: null,
            status: null
          };
        }

        _createClass(OrderPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.folder = "Café Verona";
            this.sign = "Pending";
            this.menu.enable(true);
            this.apicall.getorder();
            this.global.All.subscribe(function (res) {
              _this.all = res;
            });
            this.global.Pending.subscribe(function (res) {
              _this.pending = res;
              console.log(_this.pending);
            });
            this.global.Completed.subscribe(function (res) {
              _this.completed = res;
            });
            this.global.Cancelled.subscribe(function (res) {
              _this.cancelled = res;
            });
          }
        }, {
          key: "deliver",
          value: function deliver(id) {
            this.data.status = "completed";
            this.data.id = id;
            this.apicall.editorder(this.data);
          }
        }, {
          key: "cancel",
          value: function cancel(id) {
            this.data.status = "cancelled";
            this.data.id = id;
            this.apicall.editorder(this.data);
            console.log(this.data);
          }
        }, {
          key: "getdetails",
          value: function getdetails(id) {
            this.apicall.editorder(this.data);
          }
        }]);

        return OrderPage;
      }();

      _OrderPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService
        }];
      };

      _OrderPage = (0, tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-order',
        template: _raw_loader_order_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_order_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _OrderPage);
      /***/
    },

    /***/
    72508:
    /*!***************************************!*\
      !*** ./src/app/order/order.page.scss ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-row {\n  margin: 10px;\n}\nion-row ion-segment-button {\n  margin: 5px;\n}\nion-list {\n  background: transparent;\n}\n.row {\n  margin-top: 10px;\n  border-radius: 10px;\n  background-color: rgba(0, 0, 0, 0.4);\n  justify-content: center;\n  margin-left: 10px;\n  margin-right: 10px;\n}\n.row ion-row {\n  width: 100%;\n  justify-content: center;\n}\n.row ion-row ion-button {\n  width: 48%;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7QUFDSjtBQUFJO0VBQ0ksV0FBQTtBQUVSO0FBQ0E7RUFDSSx1QkFBQTtBQUVKO0FBQUE7RUFDSSxnQkFBQTtFQUNBLG1CQUFBO0VBQ0Esb0NBQUE7RUFDQSx1QkFBQTtFQUNBLGlCQUFBO0VBQ0Esa0JBQUE7QUFHSjtBQUZJO0VBQ0ksV0FBQTtFQUNBLHVCQUFBO0FBSVI7QUFIUTtFQUNJLFVBQUE7QUFLWiIsImZpbGUiOiJvcmRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tcm93e1xyXG4gICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgaW9uLXNlZ21lbnQtYnV0dG9ue1xyXG4gICAgICAgIG1hcmdpbjogNXB4O1xyXG4gICAgfVxyXG59XHJcbmlvbi1saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7IFxyXG59XHJcbi5yb3d7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGJhY2tncm91bmQtY29sb3I6IHJnYmEoMCwgMCwgMCwgMC40KTtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgbWFyZ2luLWxlZnQ6IDEwcHg7XHJcbiAgICBtYXJnaW4tcmlnaHQ6IDEwcHg7XHJcbiAgICBpb24tcm93e1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgICAgIHdpZHRoOiA0OCU7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */";
      /***/
    },

    /***/
    99578:
    /*!*****************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/order/order.page.html ***!
      \*****************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-row>\n    <ion-segment color=\"dark\" [(ngModel)]=\"sign\" mode=\"ios\">\n\n      <ion-segment-button value=\"Pending\">\n        <ion-label>Pending</ion-label>\n      </ion-segment-button>\n\n      <ion-segment-button value=\"Cancelled\">\n        <ion-label>Cancelled</ion-label>\n      </ion-segment-button>\n\n      <ion-segment-button value=\"Completed\">\n        <ion-label>Completed</ion-label>\n      </ion-segment-button>\n\n      <ion-segment-button value=\"All\">\n        <ion-label>All</ion-label>\n      </ion-segment-button>\n\n    </ion-segment>\n  </ion-row>\n\n  <div [ngSwitch]=\"sign\">\n    <ion-list *ngSwitchCase=\"'All'\">\n      <ion-row class=\"row\" *ngFor=\"let a of all\">\n        <ion-row>\n          <h5>Order :{{a.o_id}}</h5>\n        </ion-row>\n        <p>Order at :{{a.other}}</p>\n        <ion-row>\n          <h4>\n            Total Cost : {{a.o_total_price}}\n          </h4>\n        </ion-row>\n      </ion-row>\n    </ion-list>\n    <ion-list *ngSwitchCase=\"'Cancelled'\">\n      <ion-row class=\"row\" *ngFor=\"let a of cancelled\">\n        <ion-row>\n          <h5>Order :{{a.o_id}}</h5>\n        </ion-row>\n        <p>Order at :{{a.other}}</p>\n        <ion-row>\n          <h4>\n            Total Cost : {{a.o_total_price}}\n          </h4>\n        </ion-row>\n        <ion-row>\n          <ion-button color=\"success\" expand=\"block\" (click)=\"deliver(a.o_id)\">Delivered</ion-button>\n        </ion-row>\n      </ion-row>\n    </ion-list>\n    <ion-list *ngSwitchCase=\"'Pending'\">\n      <ion-row class=\"row\" *ngFor=\"let a of pending\">\n        <ion-row>\n          <h5>Order :{{a.o_id}}</h5>\n        </ion-row>\n        <p>Order at :{{a.other}}</p>\n        <ion-row>\n          <h4>\n            Total Cost : {{a.o_total_price}}\n          </h4>\n        </ion-row>\n        <ion-row>\n          <ion-button color=\"success\" expand=\"block\" (click)=\"deliver(a.o_id)\">Delivered</ion-button>\n          <ion-button color=\"danger\" expand=\"block\" (click)=\"cancel(a.o_id)\">Cancelled</ion-button>\n        </ion-row>\n      </ion-row>\n    </ion-list>\n    <ion-list *ngSwitchCase=\"'Completed'\">\n      <ion-row class=\"row\" *ngFor=\"let a of completed\">\n        <ion-row>\n          <h5>Order :{{a.o_id}}</h5>\n        </ion-row>\n        <p>Order at :{{a.other}}</p>\n        <ion-row>\n          <h4>\n            Total Cost : {{a.o_total_price}}\n          </h4>\n        </ion-row>\n        <ion-row>\n          <ion-button color=\"danger\" expand=\"block\" (click)=\"cancel(a.o_id)\">Cancelled</ion-button>\n        </ion-row>\n      </ion-row>\n    </ion-list>\n  </div>\n</ion-content>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_order_order_module_ts-es5.js.map