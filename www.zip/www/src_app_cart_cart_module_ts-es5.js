(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_cart_cart_module_ts"], {
    /***/
    63951:
    /*!*********************************************!*\
      !*** ./src/app/cart/cart-routing.module.ts ***!
      \*********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "CartPageRoutingModule": function CartPageRoutingModule() {
          return (
            /* binding */
            _CartPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _cart_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./cart.page */
      34612);

      var routes = [{
        path: '',
        component: _cart_page__WEBPACK_IMPORTED_MODULE_0__.CartPage
      }];

      var _CartPageRoutingModule = function CartPageRoutingModule() {
        _classCallCheck(this, CartPageRoutingModule);
      };

      _CartPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _CartPageRoutingModule);
      /***/
    },

    /***/
    12943:
    /*!*************************************!*\
      !*** ./src/app/cart/cart.module.ts ***!
      \*************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "CartPageModule": function CartPageModule() {
          return (
            /* binding */
            _CartPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _cart_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./cart-routing.module */
      63951);
      /* harmony import */


      var _cart_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./cart.page */
      34612);

      var _CartPageModule = function CartPageModule() {
        _classCallCheck(this, CartPageModule);
      };

      _CartPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _cart_routing_module__WEBPACK_IMPORTED_MODULE_0__.CartPageRoutingModule],
        declarations: [_cart_page__WEBPACK_IMPORTED_MODULE_1__.CartPage]
      })], _CartPageModule);
      /***/
    },

    /***/
    34612:
    /*!***********************************!*\
      !*** ./src/app/cart/cart.page.ts ***!
      \***********************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "CartPage": function CartPage() {
          return (
            /* binding */
            _CartPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_cart_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./cart.page.html */
      86568);
      /* harmony import */


      var _cart_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./cart.page.scss */
      9281);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _provider_alert_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../provider/alert.service */
      39829);
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../provider/apicall.service */
      10119);
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../provider/global.service */
      82836);

      var _CartPage = /*#__PURE__*/function () {
        function CartPage(route, global, apicall, Alert, navigate) {
          _classCallCheck(this, CartPage);

          this.route = route;
          this.global = global;
          this.apicall = apicall;
          this.Alert = Alert;
          this.navigate = navigate;
          this.number = 1;
          this.user = {
            customer_name: "Anonymous"
          };
          this.display0 = "";
          this.display1 = "";
          this.discount = 0;
        }

        _createClass(CartPage, [{
          key: "ionViewWillEnter",
          value: function ionViewWillEnter() {
            var _this = this;

            this.global.Cart.subscribe(function (res) {
              _this.cart = res;

              if (_this.cart.length == 0) {
                _this.display0 = "none";
                _this.display1 = "show";
              } else {
                _this.display0 = "show";
                _this.display1 = "none";
              }
            });
            this.gettotal();
          }
        }, {
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this2 = this;

            this.global.User.subscribe(function (res) {
              if (res == "") {
                _this2.route.navigate(["/home"]);
              }
            });
          }
        }, {
          key: "close",
          value: function close(i) {
            console.log(i);
            this.cart.splice(i, 1);
            this.gettotal();
            this.global.set_Cart(this.cart);
          }
        }, {
          key: "add",
          value: function add(i) {
            if (this.cart[i].quantity != 5) {
              this.cart[i].quantity++;
              this.global.set_Cart(this.cart);
            }

            this.gettotal();
          }
        }, {
          key: "minus",
          value: function minus(i) {
            if (this.cart[i].quantity != 1) {
              this.cart[i].quantity--;
              this.global.set_Cart(this.cart);
            }

            this.gettotal();
          }
        }, {
          key: "gettotal",
          value: function gettotal() {
            this.subtotal = 0;

            for (var index = 0; index < this.cart.length; index++) {
              this.sub = this.cart[index].quantity * this.cart[index].price;
              this.subtotal = this.sub + this.subtotal;
            }

            this.total = this.subtotal;
          }
        }, {
          key: "addorder",
          value: function addorder() {
            this.data = {
              user: this.user,
              cart: this.cart
            };
            console.log(this.data);
            this.apicall.addorder(this.data);
            this.global.set_Cart("");
            this.cart = [];
            this.apicall.getorder();
            this.route.navigate(['order']);
          }
        }]);

        return CartPage;
      }();

      _CartPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_3__.ApicallService
        }, {
          type: _provider_alert_service__WEBPACK_IMPORTED_MODULE_2__.AlertService
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.NavController
        }];
      };

      _CartPage = (0, tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-cart',
        template: _raw_loader_cart_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_cart_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _CartPage);
      /***/
    },

    /***/
    9281:
    /*!*************************************!*\
      !*** ./src/app/cart/cart.page.scss ***!
      \*************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "Headers ion-button {\n  display: none;\n}\n\nion-card img {\n  max-width: 4rem;\n  max-height: 4rem;\n  margin: 1rem;\n}\n\nion-card ion-col .title {\n  margin-top: 0.5rem;\n}\n\nion-card ion-col .title h5 {\n  margin-top: 0;\n}\n\nion-card ion-col .quantity {\n  margin-top: 0.4rem;\n}\n\nion-card ion-col .quantity .price h4 {\n  margin-top: 0.2rem;\n  color: #16942b;\n  float: left;\n}\n\nion-card ion-col .quantity .num {\n  float: right;\n  width: 7rem;\n}\n\nion-card ion-col .quantity .num .minus {\n  background-color: var(--ion-color-medium);\n  height: 2rem;\n  width: 2rem;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n\nion-card ion-col .quantity .num .minus ion-icon {\n  color: var(--ion-color-light);\n  padding: 0.6rem;\n}\n\nion-card ion-col .quantity .num .input {\n  border: 1px solid var(--ion-color-medium);\n  float: left;\n  width: 25%;\n  text-align: center;\n  height: 2rem;\n  justify-content: center;\n}\n\nion-card ion-col .quantity .num .input h6 {\n  margin: 6px 0 0 0;\n}\n\nion-card ion-col .quantity .num .plus {\n  float: right;\n  background-color: var(--ion-color-medium);\n  height: 2rem;\n  width: 2rem;\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n\nion-card ion-col .quantity .num .plus ion-icon {\n  color: var(--ion-color-light);\n  padding: 0.6rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhcnQucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNJO0VBQ0ksYUFBQTtBQUFSOztBQUlJO0VBQ0ksZUFBQTtFQUNBLGdCQUFBO0VBQ0EsWUFBQTtBQURSOztBQUlRO0VBQ0ksa0JBQUE7QUFGWjs7QUFHWTtFQUNJLGFBQUE7QUFEaEI7O0FBSVE7RUFDSSxrQkFBQTtBQUZaOztBQUlnQjtFQUNJLGtCQUFBO0VBQ0EsY0FBQTtFQUNBLFdBQUE7QUFGcEI7O0FBS1k7RUFDSSxZQUFBO0VBQ0EsV0FBQTtBQUhoQjs7QUFLZ0I7RUFDSSx5Q0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7RUFDQSw4QkFBQTtBQUhwQjs7QUFJb0I7RUFDSSw2QkFBQTtFQUNBLGVBQUE7QUFGeEI7O0FBS2dCO0VBQ0kseUNBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLHVCQUFBO0FBSHBCOztBQUlvQjtFQUNJLGlCQUFBO0FBRnhCOztBQUtnQjtFQUNJLFlBQUE7RUFDQSx5Q0FBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0EsNEJBQUE7RUFDQSwrQkFBQTtBQUhwQjs7QUFJb0I7RUFDSSw2QkFBQTtFQUNBLGVBQUE7QUFGeEIiLCJmaWxlIjoiY2FydC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJIZWFkZXJze1xyXG4gICAgaW9uLWJ1dHRvbntcclxuICAgICAgICBkaXNwbGF5OiBub25lO1xyXG4gICAgfVxyXG59XHJcbmlvbi1jYXJke1xyXG4gICAgaW1ne1xyXG4gICAgICAgIG1heC13aWR0aDogNHJlbTtcclxuICAgICAgICBtYXgtaGVpZ2h0OiA0cmVtO1xyXG4gICAgICAgIG1hcmdpbjogMXJlbTtcclxuICAgIH1cclxuICAgIGlvbi1jb2x7XHJcbiAgICAgICAgLnRpdGxle1xyXG4gICAgICAgICAgICBtYXJnaW4tdG9wOiAwLjVyZW07XHJcbiAgICAgICAgICAgIGg1e1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogMDsgIFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5xdWFudGl0eXtcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMC40cmVtO1xyXG4gICAgICAgICAgICAucHJpY2V7XHJcbiAgICAgICAgICAgICAgICBoNHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW4tdG9wOiAwLjJyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IHJnYigyMiwgMTQ4LCA0Myk7XHJcbiAgICAgICAgICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgLm51bXtcclxuICAgICAgICAgICAgICAgIGZsb2F0OiByaWdodDtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiA3cmVtO1xyXG5cclxuICAgICAgICAgICAgICAgIC5taW51c3tcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgICAgICAgICAgICAgICAgICBoZWlnaHQ6IDJyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDJyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLXRvcC1sZWZ0LXJhZGl1czogNXB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuNnJlbTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAuaW5wdXR7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgICAgICAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgd2lkdGg6IDI1JTtcclxuICAgICAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAycmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgIGg2e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW46IDZweCAwIDAgMDtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAucGx1c3tcclxuICAgICAgICAgICAgICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAycmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIHdpZHRoOiAycmVtO1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlci10b3AtcmlnaHQtcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyLWJvdHRvbS1yaWdodC1yYWRpdXM6IDVweDtcclxuICAgICAgICAgICAgICAgICAgICBpb24taWNvbntcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc6IDAuNnJlbTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxufSJdfQ== */";
      /***/
    },

    /***/
    86568:
    /*!***************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cart/cart.page.html ***!
      \***************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n    <ion-toolbar color=\"dark\">\n      <ion-buttons slot=\"start\">\n        <ion-back-button></ion-back-button>\n      </ion-buttons>\n      <ion-title>Cart</ion-title>\n    </ion-toolbar>\n  </ion-header>\n<ion-content color=\"medium\" >\n    <div [style.display]=\"display0\">\n        <ion-row style=\"margin-left:10px;\">\n            <h1>Shopping Cart</h1>\n        </ion-row>\n        <ion-card *ngFor=\"let grid of cart;let i = index\" color=\"dark\">\n            <ion-row>\n                <img src={{grid.image}}>\n                <ion-col>\n                    <ion-row class=\"title\">\n                        <h5>\n                            {{grid.item_name}}\n                        </h5>\n                        <ion-icon name=\"close-outline\" style=\"position: absolute;top: 6px;right: 5px;zoom:1.3\" (click)=\"close(i)\"></ion-icon>\n                    </ion-row>\n                   \n                    <div class=\"quantity\">\n                        <div class=\"price\">\n                            <H4>\n                                Rs{{grid.price*grid.quantity}}\n                            </H4>\n                        </div>\n                        <ion-row class=\"num\" >\n                            <div class=\"minus\" (click)=\"minus(i)\">\n                                <ion-icon name=\"remove-outline\"></ion-icon>\n                            </div>\n                            <div class=\"input\">\n                                <h6>{{index}} {{grid.quantity}}</h6>\n                            </div>\n                            <div class=\"plus\" (click)=\"add(i)\">\n                                <ion-icon name=\"add-outline\"></ion-icon>\n                            </div>\n                        </ion-row>\n                    </div>\n                </ion-col>\n            </ion-row>\n        </ion-card>\n        <ion-list>\n            <ion-item color=\"medium\">\n                <ion-label style=\"float: left;\">Sub Total</ion-label>\n                <ion-label style=\"float: right; text-align: end;\">Rs{{subtotal}}</ion-label>\n            </ion-item>\n            <ion-item color=\"medium\">\n                <ion-label style=\"float: left;\">Discount</ion-label>\n                <ion-label style=\"float: right; text-align: end;\">{{discount}}%</ion-label>\n            </ion-item>\n            <ion-item color=\"medium\">\n                <ion-label style=\"float: left;\"><b>\n                    Total\n                </b></ion-label>\n                <ion-label style=\"float: right; text-align: end;\"><b>Rs{{total}}</b></ion-label>\n            </ion-item>\n        </ion-list>\n        <ion-button expand=\"block\" color=\"dark\" style=\"margin:1rem\" (click)=\"addorder()\">Order Now</ion-button>\n    </div>\n    \n    <div  [style.display]=\"display1\" style=\"margin-left: 10px;\">\n        <h1>You Haven't Added Anything to Cart Yet</h1>\n    </div>\n</ion-content>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_cart_cart_module_ts-es5.js.map