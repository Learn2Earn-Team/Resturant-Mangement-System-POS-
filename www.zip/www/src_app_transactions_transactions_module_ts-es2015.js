(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_transactions_transactions_module_ts"],{

/***/ 77052:
/*!*************************************************************!*\
  !*** ./src/app/transactions/transactions-routing.module.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactionsPageRoutingModule": function() { return /* binding */ TransactionsPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _transactions_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transactions.page */ 37138);




const routes = [
    {
        path: '',
        component: _transactions_page__WEBPACK_IMPORTED_MODULE_0__.TransactionsPage
    }
];
let TransactionsPageRoutingModule = class TransactionsPageRoutingModule {
};
TransactionsPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], TransactionsPageRoutingModule);



/***/ }),

/***/ 65528:
/*!*****************************************************!*\
  !*** ./src/app/transactions/transactions.module.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactionsPageModule": function() { return /* binding */ TransactionsPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _transactions_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./transactions-routing.module */ 77052);
/* harmony import */ var _transactions_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transactions.page */ 37138);







let TransactionsPageModule = class TransactionsPageModule {
};
TransactionsPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _transactions_routing_module__WEBPACK_IMPORTED_MODULE_0__.TransactionsPageRoutingModule
        ],
        declarations: [_transactions_page__WEBPACK_IMPORTED_MODULE_1__.TransactionsPage]
    })
], TransactionsPageModule);



/***/ }),

/***/ 37138:
/*!***************************************************!*\
  !*** ./src/app/transactions/transactions.page.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "TransactionsPage": function() { return /* binding */ TransactionsPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_transactions_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./transactions.page.html */ 59096);
/* harmony import */ var _transactions_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./transactions.page.scss */ 8995);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);






let TransactionsPage = class TransactionsPage {
    constructor(apicall, global) {
        this.apicall = apicall;
        this.global = global;
        this.data = { id: null, start: null, end: null };
        this.filter = [{ id: 1, name: "Orders" }, { id: 2, name: "Transactions" }];
    }
    ngOnInit() {
        this.folder = "Café Verona";
    }
    check() {
        this.data.start = this.data.start.slice(0, 10);
        this.data.end = this.data.end.slice(0, 10);
        console.log(this.data);
        this.apicall.api_showtransaction(this.data);
        this.global.Transactiondetail.subscribe(res => {
            this.transactions = res;
            console.log(this.transactions);
        });
    }
};
TransactionsPage.ctorParameters = () => [
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService }
];
TransactionsPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-transactions',
        template: _raw_loader_transactions_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_transactions_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], TransactionsPage);



/***/ }),

/***/ 8995:
/*!*****************************************************!*\
  !*** ./src/app/transactions/transactions.page.scss ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content .start {\n  float: left;\n  color: #000;\n}\nion-content .end {\n  float: right;\n  color: #000;\n}\nion-content ion-datetime {\n  color: #000;\n}\nion-content ion-grid {\n  margin: 10px;\n  justify-content: center;\n  align-content: center;\n}\nion-content ion-grid ion-row {\n  justify-content: center;\n}\nion-content ion-grid ion-row ion-col {\n  background: var(--ion-color-dark);\n  box-shadow: 4px 10px 30px -3px #050505;\n  min-width: 18rem;\n  max-width: 18rem;\n  height: 11rem;\n  margin: 10px;\n  text-align: center;\n  justify-content: center;\n  border-radius: 20px;\n}\nion-content ion-grid ion-row ion-col ion-item {\n  margin: -8px;\n  margin-top: -15px;\n  text-align: center;\n  justify-content: center;\n  --background: transparent;\n}\nion-content ion-grid ion-row ion-col ion-item ion-label {\n  font-size: 0.8rem;\n  color: var(--ion-color-light);\n}\nion-content ion-grid ion-row ion-col ion-button {\n  margin: 0.5rem;\n  --border-radius: 20px;\n  height: 2rem;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInRyYW5zYWN0aW9ucy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0s7RUFDRyxXQUFBO0VBQ0EsV0FBQTtBQUFSO0FBRUk7RUFDSSxZQUFBO0VBQ0EsV0FBQTtBQUFSO0FBRUk7RUFDSSxXQUFBO0FBQVI7QUFFSTtFQUNJLFlBQUE7RUFDQSx1QkFBQTtFQUNBLHFCQUFBO0FBQVI7QUFDUTtFQUNJLHVCQUFBO0FBQ1o7QUFBWTtFQUNJLGlDQUFBO0VBQ0Esc0NBQUE7RUFDQSxnQkFBQTtFQUNBLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBRUEsbUJBQUE7QUFDaEI7QUFBZ0I7RUFDSSxZQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0VBQ0EseUJBQUE7QUFFcEI7QUFEb0I7RUFDSSxpQkFBQTtFQUNBLDZCQUFBO0FBR3hCO0FBQWdCO0VBQ0ksY0FBQTtFQUNBLHFCQUFBO0VBQ0EsWUFBQTtBQUVwQiIsImZpbGUiOiJ0cmFuc2FjdGlvbnMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgIC5zdGFydCB7XHJcbiAgICAgICAgZmxvYXQ6IGxlZnQ7XHJcbiAgICAgICAgY29sb3I6ICMwMDA7XHJcbiAgICB9XHJcbiAgICAuZW5kIHtcclxuICAgICAgICBmbG9hdDogcmlnaHQ7XHJcbiAgICAgICAgY29sb3I6ICMwMDA7XHJcbiAgICB9XHJcbiAgICBpb24tZGF0ZXRpbWV7XHJcbiAgICAgICAgY29sb3I6ICMwMDA7XHJcbiAgICB9XHJcbiAgICBpb24tZ3JpZCB7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGFsaWduLWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICBpb24tcm93IHtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1jb2wge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgICAgICAgICAgICAgYm94LXNoYWRvdzogNHB4IDEwcHggMzBweCAtM3B4ICMwNTA1MDU7XHJcbiAgICAgICAgICAgICAgICBtaW4td2lkdGg6IDE4cmVtO1xyXG4gICAgICAgICAgICAgICAgbWF4LXdpZHRoOiAxOHJlbTtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogMTFyZW07XHJcbiAgICAgICAgICAgICAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgICAgICAgIC8vIG1heC1oZWlnaHQ6IDEycmVtO1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMjBweDtcclxuICAgICAgICAgICAgICAgIGlvbi1pdGVtIHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW46IC04cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luLXRvcDogLTE1cHg7XHJcbiAgICAgICAgICAgICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICAgICAgICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgICAgICAgICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250LXNpemU6IDAuOHJlbTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I6IHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luOiAwLjVyZW07XHJcbiAgICAgICAgICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiAyMHB4O1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogMnJlbTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 59096:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/transactions/transactions.page.html ***!
  \*******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-row style=\"border-bottom: 1px solid black;\">\n    <div style=\"width: 90%; margin-left: 20px; margin-right: 20px;\">\n      <p class=\"start\">Start Date</p>\n      <p class=\"end\">End Date</p>\n    </div>\n    <div style=\"width: 90%; margin-left: 20px; margin-right: 20px;\">\n      <ion-datetime style=\"margin-left: -21px;width: 50%; float: left;\" placeholder=\"Select Date\" display-format=\"YYYY-MM-DD\" picker-format=\"YYYY-MM-DD\" name=\"start\" [(ngModel)]=\"data.start\"\n      ></ion-datetime>\n      <ion-datetime style=\"margin-right: -5px;float: right;\" placeholder=\"Select Date\" min={{data.start}} display-format=\"YYYY-MM-DD\" picker-format=\"YYYY-MM-DD\" name=\"end\" [(ngModel)]=\"data.end\" >\n      </ion-datetime>\n    </div>\n  </ion-row>\n  <ion-item lines=\"none\" style=\"--background:transparent;\">\n    <ion-label>Filter</ion-label>\n    <ion-select name=\"id\" [(ngModel)]=\"data.id\" interface=\"action-sheet\">\n      <ion-select-option value={{a.id}} *ngFor=\"let a of filter\">{{a.name}}</ion-select-option>\n    </ion-select>\n  </ion-item>\n  <ion-button expand=\"block\" color=\"light\" (click)=\"check()\" [disabled]=\"data.id==null || data.start==null || data.end==null \">See Data</ion-button>\n  <ion-grid>\n    <ion-row color=\"success\" >\n      <ion-col *ngFor=\"let trans of transactions\">\n        <div *ngIf=\"trans.number == 1\">\n          <ion-item text-center lines=\"none\" style=\"margin-top: 1px;\"><ion-label>Id: {{trans.o_id}}</ion-label></ion-item>\n          <ion-item text-center lines=\"none\"><ion-label>Date:{{trans.date}}</ion-label></ion-item>\n          <ion-item lines=\"none\"><ion-label>Total Price: {{trans.o_total_price}}</ion-label></ion-item>\n          <ion-item lines=\"none\"><ion-label>Status: {{trans.o_status}}</ion-label></ion-item>\n          <!-- <ion-button color=\"light\" expand=\"block\" (click)=\"showdetail(trans.invoice_id)\" >View Detail</ion-button> -->\n        </div>\n        <div *ngIf=\"trans.number == 2\">\n          <ion-item text-center lines=\"none\" ><ion-label>Id: {{trans.isc_id}}</ion-label></ion-item>\n          <ion-item text-center lines=\"none\"><ion-label>Date: {{trans.ish_date_time}}</ion-label></ion-item>\n          <ion-item text-center lines=\"none\"><ion-label>Total Quantity: {{trans.ish_quantity}}</ion-label></ion-item>\n          <ion-item text-center lines=\"none\"><ion-label>Total Price: {{trans.ish_price}}</ion-label></ion-item>\n          <ion-item lines=\"none\"><ion-label>Dealer Name: {{trans.ish_deller}}</ion-label></ion-item>\n        </div>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_transactions_transactions_module_ts-es2015.js.map