(function () {
  function _objectDestructuringEmpty(obj) { if (obj == null) throw new TypeError("Cannot destructure undefined"); }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_showdetail_showdetail_module_ts"], {
    /***/
    92867:
    /*!*********************************************************!*\
      !*** ./src/app/showdetail/showdetail-routing.module.ts ***!
      \*********************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ShowdetailPageRoutingModule": function ShowdetailPageRoutingModule() {
          return (
            /* binding */
            _ShowdetailPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _showdetail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./showdetail.page */
      61913);

      var routes = [{
        path: '',
        component: _showdetail_page__WEBPACK_IMPORTED_MODULE_0__.ShowdetailPage
      }];

      var _ShowdetailPageRoutingModule = function ShowdetailPageRoutingModule() {
        _classCallCheck(this, ShowdetailPageRoutingModule);
      };

      _ShowdetailPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _ShowdetailPageRoutingModule);
      /***/
    },

    /***/
    33933:
    /*!*************************************************!*\
      !*** ./src/app/showdetail/showdetail.module.ts ***!
      \*************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ShowdetailPageModule": function ShowdetailPageModule() {
          return (
            /* binding */
            _ShowdetailPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _showdetail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./showdetail-routing.module */
      92867);
      /* harmony import */


      var _showdetail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./showdetail.page */
      61913);

      var _ShowdetailPageModule = function ShowdetailPageModule() {
        _classCallCheck(this, ShowdetailPageModule);
      };

      _ShowdetailPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _showdetail_routing_module__WEBPACK_IMPORTED_MODULE_0__.ShowdetailPageRoutingModule],
        declarations: [_showdetail_page__WEBPACK_IMPORTED_MODULE_1__.ShowdetailPage]
      })], _ShowdetailPageModule);
      /***/
    },

    /***/
    61913:
    /*!***********************************************!*\
      !*** ./src/app/showdetail/showdetail.page.ts ***!
      \***********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ShowdetailPage": function ShowdetailPage() {
          return (
            /* binding */
            _ShowdetailPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_showdetail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./showdetail.page.html */
      4471);
      /* harmony import */


      var _showdetail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./showdetail.page.scss */
      89386);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! src/app/provider/apicall.service */
      10119);
      /* harmony import */


      var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! src/app/provider/global.service */
      82836);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      39895);

      var _ShowdetailPage = /*#__PURE__*/function () {
        function ShowdetailPage(loadingController, alert, router, menu, apicall, global) {
          _classCallCheck(this, ShowdetailPage);

          this.loadingController = loadingController;
          this.alert = alert;
          this.router = router;
          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
          this.history = {
            invoice_id: null,
            name: 'customer',
            type: null,
            quantity: null,
            action: null,
            user: null
          };
          this.updatedetail = {
            customer_id: '',
            net_balance: '',
            received: ''
          }; // tslint:disable-next-line:variable-name

          this.rece = {
            c_id: null,
            total: null,
            debit: null,
            net_balance: 0
          };
        }

        _createClass(ShowdetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            console.log(history.state.data);
            this.rece.c_id = history.state.data.c_id;
            this.global.Customerdetails.subscribe(function (res) {
              console.log(res);
              _this.data = res;

              if (Object.keys(_this.data).length === 0) {
                _this.rece.net_balance = 0;
                console.log(_this.rece.net_balance);
              } else {
                _this.last = _this.data[_this.data.length - 1];
                _this.rece.net_balance = _this.last.net_balance;
                console.log(_this.rece.net_balance); // console.log(this.last.net_balance);
              }
            });
          }
        }, {
          key: "updatecustomerbalance",
          value: function updatecustomerbalance() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      // this.rece.c_id = this.data[0].c_id;
                      this.updatedetail.received = this.rece;
                      console.log(this.rece.c_id);
                      this.apicall.api_updatecustomerbalance(this.rece);
                      this.router.navigate(['detail']);

                    case 4:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "presentLoadingWithOptions",
          value: function presentLoadingWithOptions() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var loading, _yield$loading$onDidD;

              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.loadingController.create({
                        spinner: "circular",
                        duration: 200,
                        message: 'Order Is Being Placed',
                        translucent: true,
                        cssClass: 'custom-class custom-loading',
                        backdropDismiss: true
                      });

                    case 2:
                      loading = _context2.sent;
                      _context2.next = 5;
                      return loading.present();

                    case 5:
                      _context2.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context2.sent;

                      _objectDestructuringEmpty(_yield$loading$onDidD);

                    case 9:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return ShowdetailPage;
      }();

      _ShowdetailPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController
        }, {
          type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService
        }, {
          type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService
        }];
      };

      _ShowdetailPage = (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-showdetail',
        template: _raw_loader_showdetail_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_showdetail_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _ShowdetailPage);
      /***/
    },

    /***/
    89386:
    /*!*************************************************!*\
      !*** ./src/app/showdetail/showdetail.page.scss ***!
      \*************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content {\n  /* Zebra striping */\n}\n@media screen and (max-width: 550px) {\n  ion-content td, ion-content th {\n    font-size: 14px;\n  }\n}\n@media screen and (max-width: 500px) {\n  ion-content td, ion-content th {\n    font-size: 12px;\n  }\n}\n@media screen and (max-width: 450px) {\n  ion-content td, ion-content th {\n    font-size: 11px;\n  }\n}\n@media screen and (max-width: 400px) {\n  ion-content td, ion-content th {\n    font-size: 10px;\n  }\n}\n@media screen and (max-width: 370px) {\n  ion-content td, ion-content th {\n    font-size: 9px;\n  }\n}\nion-content table {\n  width: 100%;\n  border-collapse: collapse;\n}\nion-content tr:nth-of-type(odd) {\n  background: black;\n}\nion-content th {\n  background: #333;\n  color: white;\n}\nion-content td, ion-content th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNob3dkZXRhaWwucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUdBO0VBZ0NFLG1CQUFBO0FBakNGO0FBR0U7RUFDRTtJQUNFLGVBQUE7RUFESjtBQUNGO0FBR0U7RUFDRTtJQUNFLGVBQUE7RUFESjtBQUNGO0FBR0U7RUFDRTtJQUNFLGVBQUE7RUFESjtBQUNGO0FBR0U7RUFDRTtJQUNFLGVBQUE7RUFESjtBQUNGO0FBR0U7RUFDRTtJQUNFLGNBQUE7RUFESjtBQUNGO0FBSUU7RUFDRSxXQUFBO0VBQ0EseUJBQUE7QUFGSjtBQUtFO0VBQ0UsaUJBQUE7QUFISjtBQUtFO0VBQ0UsZ0JBQUE7RUFDQSxZQUFBO0FBSEo7QUFLRTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtFQUNBLGdCQUFBO0FBSEoiLCJmaWxlIjoic2hvd2RldGFpbC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBpb24tdG9vbGJhciB7XHJcbi8vICAgLS1iYWNrZ3JvdW5kOiB2YXIoLS1pb24tY29sb3Itc3VjY2Vzcyk7XHJcbi8vIH1cclxuaW9uLWNvbnRlbnQge1xyXG4gIC8vIC0tYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KHRvIGJvdHRvbSwgIzVmOGZmOCwgI2ZmZmZmZik7XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNTAwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTJweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDUwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTFweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogNDAwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTBweDtcclxuICAgIH1cclxuICB9XHJcbiAgQG1lZGlhIHNjcmVlbiBhbmQgKG1heC13aWR0aDogMzcwcHgpIHtcclxuICAgIHRkLHRoICB7XHJcbiAgICAgIGZvbnQtc2l6ZTogOXB4O1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgdGFibGUge1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBib3JkZXItY29sbGFwc2U6IGNvbGxhcHNlO1xyXG4gIH1cclxuICAvKiBaZWJyYSBzdHJpcGluZyAqL1xyXG4gIHRyOm50aC1vZi10eXBlKG9kZCkge1xyXG4gICAgYmFja2dyb3VuZDogYmxhY2s7XHJcbiAgfVxyXG4gIHRoIHtcclxuICAgIGJhY2tncm91bmQ6ICMzMzM7XHJcbiAgICBjb2xvcjogd2hpdGU7XHJcbiAgfVxyXG4gIHRkLCB0aCB7XHJcbiAgICBwYWRkaW5nOiAzcHg7XHJcbiAgICBib3JkZXI6IDFweCBzb2xpZCAjY2NjO1xyXG4gICAgdGV4dC1hbGlnbjogbGVmdDtcclxuICB9XHJcblxyXG59XHJcbiJdfQ== */";
      /***/
    },

    /***/
    4471:
    /*!***************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/showdetail/showdetail.page.html ***!
      \***************************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Customer Ledger</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Date</th>\n      <th style=\"background: #333; \">Total</th>\n      <th style=\"background: rgb(4, 151, 70); \">Debit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Credit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Net Balance</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of data\">\n      <td>{{a.other}}</td>\n      <td>{{a.total}}</td>\n      <td>{{a.debit}}</td>\n      <td>{{a.credit}}</td>\n      <td>{{a.net_balance}}</td>\n      <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n    </tr>\n    </tbody>\n  </table>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Total\n    </ion-label>\n    <ion-input name=\"total\" type=\"number\" [(ngModel)]=\"rece.total\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Debit\n    </ion-label>\n    <ion-input name=\"debit\" type=\"number\" [(ngModel)]=\"rece.debit\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-button  expand=\"block\" color=\"dark\" style=\"margin:10px;height:2.5rem\" (click) = updatecustomerbalance()>Total</ion-button>\n\n</ion-content>\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_showdetail_showdetail_module_ts-es5.js.map