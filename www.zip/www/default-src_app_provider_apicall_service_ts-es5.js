(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["default-src_app_provider_apicall_service_ts"], {
    /***/
    39829:
    /*!*******************************************!*\
      !*** ./src/app/provider/alert.service.ts ***!
      \*******************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AlertService": function AlertService() {
          return (
            /* binding */
            _AlertService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @ionic/angular */
      80476);

      var _AlertService = /*#__PURE__*/function () {
        function AlertService(Alert, nav) {
          _classCallCheck(this, AlertService);

          this.Alert = Alert;
          this.nav = nav;
        }

        _createClass(AlertService, [{
          key: "loginAlert",
          value: function loginAlert() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.Alert.create({
                        header: 'Welcome',
                        message: 'Your Are Successfully Login',
                        buttons: [{
                          text: 'Okay'
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "signup",
          value: function signup() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var alert;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.Alert.create({
                        header: 'Congrats',
                        subHeader: 'Your Are Successfully Registered',
                        message: 'Now please Login',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context2.sent;
                      _context2.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "password",
          value: function password() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var alert;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.Alert.create({
                        header: 'Sorry',
                        message: 'Password not Matched',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context3.sent;
                      _context3.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }, {
          key: "email",
          value: function email() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              var alert;
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.Alert.create({
                        message: 'Invalid Email',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context4.sent;
                      _context4.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          }
        }, {
          key: "invalidlogin",
          value: function invalidlogin() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              var alert;
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      _context5.next = 2;
                      return this.Alert.create({
                        message: 'Invalid User name or Password',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context5.sent;
                      _context5.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          }
        }, {
          key: "connection",
          value: function connection() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
              var alert;
              return regeneratorRuntime.wrap(function _callee6$(_context6) {
                while (1) {
                  switch (_context6.prev = _context6.next) {
                    case 0:
                      _context6.next = 2;
                      return this.Alert.create({
                        subHeader: 'Check your Internet connection',
                        message: 'Connection failed!',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context6.sent;
                      _context6.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context6.stop();
                  }
                }
              }, _callee6, this);
            }));
          }
        }, {
          key: "invalidpass",
          value: function invalidpass() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
              var alert;
              return regeneratorRuntime.wrap(function _callee7$(_context7) {
                while (1) {
                  switch (_context7.prev = _context7.next) {
                    case 0:
                      _context7.next = 2;
                      return this.Alert.create({
                        subHeader: 'please inter Valid password',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context7.sent;
                      _context7.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context7.stop();
                  }
                }
              }, _callee7, this);
            }));
          }
        }, {
          key: "call",
          value: function call(message) {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
              var alert;
              return regeneratorRuntime.wrap(function _callee8$(_context8) {
                while (1) {
                  switch (_context8.prev = _context8.next) {
                    case 0:
                      _context8.next = 2;
                      return this.Alert.create({
                        header: 'Cafe Verona',
                        subHeader: message,
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context8.sent;
                      _context8.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context8.stop();
                  }
                }
              }, _callee8, this);
            }));
          }
        }, {
          key: "country",
          value: function country() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
              var _this = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee9$(_context9) {
                while (1) {
                  switch (_context9.prev = _context9.next) {
                    case 0:
                      _context9.next = 2;
                      return this.Alert.create({
                        message: 'Sorry We Dont Deliver to Any Country Except Orange',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this.nav.navigateForward('/Home');
                          }
                        }]
                      });

                    case 2:
                      alert = _context9.sent;
                      _context9.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context9.stop();
                  }
                }
              }, _callee9, this);
            }));
          }
        }, {
          key: "allready",
          value: function allready() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
              var alert;
              return regeneratorRuntime.wrap(function _callee10$(_context10) {
                while (1) {
                  switch (_context10.prev = _context10.next) {
                    case 0:
                      _context10.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'This Email is Already Exist',
                        message: 'Please login',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context10.sent;
                      _context10.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context10.stop();
                  }
                }
              }, _callee10, this);
            }));
          }
        }, {
          key: "oldincorrect",
          value: function oldincorrect() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee11() {
              var alert;
              return regeneratorRuntime.wrap(function _callee11$(_context11) {
                while (1) {
                  switch (_context11.prev = _context11.next) {
                    case 0:
                      _context11.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'Old Password Incorrect',
                        message: 'Please Try Again',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context11.sent;
                      _context11.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context11.stop();
                  }
                }
              }, _callee11, this);
            }));
          }
        }, {
          key: "newmatch",
          value: function newmatch() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee12() {
              var alert;
              return regeneratorRuntime.wrap(function _callee12$(_context12) {
                while (1) {
                  switch (_context12.prev = _context12.next) {
                    case 0:
                      _context12.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'New Passwords Dont Match',
                        message: 'Try Again',
                        buttons: ['Ok']
                      });

                    case 2:
                      alert = _context12.sent;
                      _context12.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context12.stop();
                  }
                }
              }, _callee12, this);
            }));
          }
        }, {
          key: "updateprofile",
          value: function updateprofile() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee13() {
              var _this2 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee13$(_context13) {
                while (1) {
                  switch (_context13.prev = _context13.next) {
                    case 0:
                      _context13.next = 2;
                      return this.Alert.create({
                        header: 'Succesfull',
                        subHeader: 'Profile updated',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this2.nav.navigateForward('/tabs/tab3');
                          }
                        }]
                      });

                    case 2:
                      alert = _context13.sent;
                      _context13.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context13.stop();
                  }
                }
              }, _callee13, this);
            }));
          }
        }, {
          key: "passupdate",
          value: function passupdate() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee14() {
              var _this3 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee14$(_context14) {
                while (1) {
                  switch (_context14.prev = _context14.next) {
                    case 0:
                      _context14.next = 2;
                      return this.Alert.create({
                        header: 'Succesfull',
                        subHeader: 'Password updated',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this3.nav.navigateForward('/editprofile');
                          }
                        }]
                      });

                    case 2:
                      alert = _context14.sent;
                      _context14.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context14.stop();
                  }
                }
              }, _callee14, this);
            }));
          }
        }, {
          key: "addpost",
          value: function addpost() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee15() {
              var _this4 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee15$(_context15) {
                while (1) {
                  switch (_context15.prev = _context15.next) {
                    case 0:
                      _context15.next = 2;
                      return this.Alert.create({
                        header: 'Succesfull',
                        subHeader: 'Your Add has Been Posted',
                        buttons: [{
                          text: 'Okay',
                          handler: function handler() {
                            _this4.nav.navigateForward('/tabs/tab3');
                          }
                        }]
                      });

                    case 2:
                      alert = _context15.sent;
                      _context15.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context15.stop();
                  }
                }
              }, _callee15, this);
            }));
          }
        }, {
          key: "services",
          value: function services() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee16() {
              var alert;
              return regeneratorRuntime.wrap(function _callee16$(_context16) {
                while (1) {
                  switch (_context16.prev = _context16.next) {
                    case 0:
                      _context16.next = 2;
                      return this.Alert.create({
                        header: 'Ooops',
                        subHeader: 'please select appropriate services related  sub service',
                        buttons: ['ok']
                      });

                    case 2:
                      alert = _context16.sent;
                      _context16.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context16.stop();
                  }
                }
              }, _callee16, this);
            }));
          }
        }]);

        return AlertService;
      }();

      _AlertService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.AlertController
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_1__.NavController
        }];
      };

      _AlertService = (0, tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
      })], _AlertService);
      /***/
    },

    /***/
    10119:
    /*!*********************************************!*\
      !*** ./src/app/provider/apicall.service.ts ***!
      \*********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "ApicallService": function ApicallService() {
          return (
            /* binding */
            _ApicallService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _auth_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./auth.service */
      62430);
      /* harmony import */


      var _global_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./global.service */
      82836);
      /* harmony import */


      var _alert_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./alert.service */
      39829);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      80476);

      var _ApicallService = /*#__PURE__*/function () {
        function ApicallService(menuCtrl, authservice, global, Alert, navigate) {
          _classCallCheck(this, ApicallService);

          this.menuCtrl = menuCtrl;
          this.authservice = authservice;
          this.global = global;
          this.Alert = Alert;
          this.navigate = navigate; // this.authservice.observeHttp.subscribe(data => 
          //   { 
          //     this.prgres=parseInt(JSON.stringify(data))/100; 
          //     console.log(this.prgres);
          //     if(this.prgres==1){
          //     this.getmenu();
          //     this.navigate.navigateBack("/menu");
          //     this.Alert.call("New Categeory Added");
          //     }
          //   }
          //   )  
        }

        _createClass(ApicallService, [{
          key: "api_login",
          value: function api_login(signin) {
            var _this5 = this;

            this.authservice.con(signin, 'login').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee17() {
                return regeneratorRuntime.wrap(function _callee17$(_context17) {
                  while (1) {
                    switch (_context17.prev = _context17.next) {
                      case 0:
                        this.response = JSON.parse(String(res));

                        if (!(this.response.error === false)) {
                          _context17.next = 6;
                          break;
                        }

                        this.global.set_User(this.response.user);
                        this.Alert.loginAlert();
                        this.navigate.navigateForward("/ordercat");
                        return _context17.abrupt("return");

                      case 6:
                        this.Alert.invalidlogin();
                        console.log(this.response.error); // tslint:disable-next-line: whitespace

                      case 8:
                      case "end":
                        return _context17.stop();
                    }
                  }
                }, _callee17, this);
              }));
            }, function (err) {
              _this5.Alert.connection();
            });
          }
        }, {
          key: "api_getallproducts",
          value: function api_getallproducts() {
            var _this6 = this;

            this.authservice.getdata('viewrawcat').then(function (result) {
              _this6.global.set_Products(JSON.parse(String(result)));
            }, function (err) {
              _this6.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "addcat",
          value: function addcat(data) {
            var _this7 = this;

            this.authservice.con(data, 'addrawcat').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this7, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee18() {
                return regeneratorRuntime.wrap(function _callee18$(_context18) {
                  while (1) {
                    switch (_context18.prev = _context18.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context18.next = 5;
                          break;
                        }

                        this.Alert.call("New Categeory Added");
                        this.api_getallproducts();
                        return _context18.abrupt("return");

                      case 5:
                      case "end":
                        return _context18.stop();
                    }
                  }
                }, _callee18, this);
              }));
            }, function (err) {
              console.log(err);

              _this7.Alert.connection();
            });
          }
        }, {
          key: "addmenucat",
          value: function addmenucat(data) {
            var _this8 = this;

            this.authservice.con(data, 'insertmenucat').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this8, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee19() {
                return regeneratorRuntime.wrap(function _callee19$(_context19) {
                  while (1) {
                    switch (_context19.prev = _context19.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context19.next = 6;
                          break;
                        }

                        this.getmenu();
                        this.navigate.navigateBack("/menu");
                        this.Alert.call("New Categeory Added");
                        return _context19.abrupt("return");

                      case 6:
                      case "end":
                        return _context19.stop();
                    }
                  }
                }, _callee19, this);
              }));
            }, function (err) {
              console.log(err);

              _this8.Alert.connection();
            });
          }
        }, {
          key: "editcat",
          value: function editcat(data) {
            var _this9 = this;

            this.authservice.con(data, 'editrawcat').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this9, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee20() {
                return regeneratorRuntime.wrap(function _callee20$(_context20) {
                  while (1) {
                    switch (_context20.prev = _context20.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context20.next = 5;
                          break;
                        }

                        this.Alert.call("Categeory Updated");
                        this.api_getallproducts();
                        return _context20.abrupt("return");

                      case 5:
                      case "end":
                        return _context20.stop();
                    }
                  }
                }, _callee20, this);
              }));
            }, function (err) {
              console.log(err);

              _this9.Alert.connection();
            });
          }
        }, {
          key: "editsubcat",
          value: function editsubcat(data) {
            var _this10 = this;

            this.authservice.con(data, 'editrawsub').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this10, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee21() {
                return regeneratorRuntime.wrap(function _callee21$(_context21) {
                  while (1) {
                    switch (_context21.prev = _context21.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context21.next = 5;
                          break;
                        }

                        this.Alert.call("Item Editted");
                        this.getsub(data.callid);
                        return _context21.abrupt("return");

                      case 5:
                      case "end":
                        return _context21.stop();
                    }
                  }
                }, _callee21, this);
              }));
            }, function (err) {
              console.log(err);

              _this10.Alert.connection();
            });
          }
        }, {
          key: "getsub",
          value: function getsub(id) {
            var _this11 = this;

            this.authservice.getdata('viewrawsub/' + id).then(function (data) {
              _this11.response = JSON.parse(String(data));

              _this11.global.set_Subcat(JSON.parse(String(data)));

              console.log(_this11.response);

              _this11.navigate.navigateForward("/subcat");
            }, function (err) {
              _this11.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "getdetails",
          value: function getdetails(id) {
            var _this12 = this;

            this.authservice.getdata('getsubhistory/' + id).then(function (data) {
              _this12.response = JSON.parse(String(data));

              _this12.global.set_Cart(JSON.parse(String(data)));

              console.log(_this12.response);

              _this12.navigate.navigateForward("/stockdetail");
            }, function (err) {
              _this12.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "getmenudetails",
          value: function getmenudetails(id) {
            var _this13 = this;

            this.authservice.getdata('getallmenu/' + id).then(function (data) {
              _this13.response = JSON.parse(String(data));
              console.log(_this13.response);

              _this13.global.set_Menusub(JSON.parse(String(data)));
            }, function (err) {
              _this13.Alert.connection();
            });
          }
        }, {
          key: "getmenu",
          value: function getmenu() {
            var _this14 = this;

            this.authservice.getdata('getallmenucategory').then(function (data) {
              console.log(data);
              _this14.response = JSON.parse(String(data));

              _this14.global.set_Menu(JSON.parse(String(data)));
            }, function (err) {
              _this14.Alert.connection();
            });
          }
        }, {
          key: "getorder",
          value: function getorder() {
            var _this15 = this;

            this.authservice.getdata('getallorder').then(function (data) {
              _this15.all = JSON.parse(String(data));

              _this15.global.set_All(_this15.all);

              _this15.global.set_Pending(_this15.all.filter(function (data) {
                return data.o_status == "pending";
              }));

              _this15.global.set_Cancelled(_this15.all.filter(function (data) {
                return data.o_status == "cancelled";
              }));

              _this15.global.set_Completed(_this15.all.filter(function (data) {
                return data.o_status == "completed";
              }));
            }, function (err) {
              _this15.Alert.connection();
            });
          }
        }, {
          key: "getstock",
          value: function getstock() {
            var _this16 = this;

            this.authservice.getdata('getallstock').then(function (data) {
              _this16.response = JSON.parse(String(data));
              console.log(_this16.response);
              _this16.less = _this16.response.filter(function (data) {
                return data.is_remaining < data.min_quantity;
              });

              _this16.global.set_Stock(_this16.response);

              _this16.global.set_Less(_this16.less);

              console.log(_this16.response);
            }, function (err) {
              _this16.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "addsub",
          value: function addsub(data) {
            var _this17 = this;

            this.authservice.con(data, 'addrawsub').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this17, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee22() {
                return regeneratorRuntime.wrap(function _callee22$(_context22) {
                  while (1) {
                    switch (_context22.prev = _context22.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context22.next = 5;
                          break;
                        }

                        this.Alert.call("Added New Item");
                        this.getsub(data.id);
                        return _context22.abrupt("return");

                      case 5:
                      case "end":
                        return _context22.stop();
                    }
                  }
                }, _callee22, this);
              }));
            }, function (err) {
              console.log(err);

              _this17.Alert.connection();
            });
          }
        }, {
          key: "addorder",
          value: function addorder(data) {
            var _this18 = this;

            this.authservice.con(data, 'addorder').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this18, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee23() {
                return regeneratorRuntime.wrap(function _callee23$(_context23) {
                  while (1) {
                    switch (_context23.prev = _context23.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());
                        this.updatordergradients(this.response);
                        console.log(this.response);

                      case 3:
                      case "end":
                        return _context23.stop();
                    }
                  }
                }, _callee23, this);
              }));
            }, function (err) {
              console.log(err);

              _this18.Alert.connection();
            });
          }
        }, {
          key: "updatordergradients",
          value: function updatordergradients(data) {
            var _this19 = this;

            ;
            this.authservice.con(data, 'updatordergradients').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this19, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee24() {
                return regeneratorRuntime.wrap(function _callee24$(_context24) {
                  while (1) {
                    switch (_context24.prev = _context24.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (this.response.error === false) {
                          this.Alert.call("Order Placed");
                        }

                      case 2:
                      case "end":
                        return _context24.stop();
                    }
                  }
                }, _callee24, this);
              }));
            }, function (err) {
              console.log(err);

              _this19.Alert.connection();
            });
          }
        }, {
          key: "api_showtransaction",
          value: function api_showtransaction(data) {
            var _this20 = this;

            ;
            this.authservice.con(data, 'gettransaction').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this20, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee25() {
                return regeneratorRuntime.wrap(function _callee25$(_context25) {
                  while (1) {
                    switch (_context25.prev = _context25.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());
                        this.global.set_Transactiondetail(this.response);

                      case 2:
                      case "end":
                        return _context25.stop();
                    }
                  }
                }, _callee25, this);
              }));
            }, function (err) {
              console.log(err);

              _this20.Alert.connection();
            });
          }
        }, {
          key: "editorder",
          value: function editorder(data) {
            var _this21 = this;

            this.authservice.con(data, 'updateorderstatus').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this21, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee26() {
                return regeneratorRuntime.wrap(function _callee26$(_context26) {
                  while (1) {
                    switch (_context26.prev = _context26.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context26.next = 5;
                          break;
                        }

                        this.Alert.call("Order Status Updated");
                        this.getorder();
                        return _context26.abrupt("return");

                      case 5:
                      case "end":
                        return _context26.stop();
                    }
                  }
                }, _callee26, this);
              }));
            }, function (err) {
              console.log(err);

              _this21.Alert.connection();
            });
          }
        }, {
          key: "insertmenusub",
          value: function insertmenusub(data) {
            var _this22 = this;

            this.authservice.con(data, 'insertmenusubcat').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this22, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee27() {
                var _this23 = this;

                return regeneratorRuntime.wrap(function _callee27$(_context27) {
                  while (1) {
                    switch (_context27.prev = _context27.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context27.next = 5;
                          break;
                        }

                        this.Alert.call("Added New Item");
                        this.global.Id.subscribe(function (res) {
                          _this23.getmenudetails(res);

                          _this23.navigate.navigateBack(["/menuitem"]);
                        });
                        return _context27.abrupt("return");

                      case 5:
                      case "end":
                        return _context27.stop();
                    }
                  }
                }, _callee27, this);
              }));
            }, function (err) {
              console.log(err);

              _this22.Alert.connection();
            });
          }
        }, {
          key: "insertstock",
          value: function insertstock(data) {
            var _this24 = this;

            this.authservice.con(data, 'insertpurchase').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this24, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee28() {
                return regeneratorRuntime.wrap(function _callee28$(_context28) {
                  while (1) {
                    switch (_context28.prev = _context28.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context28.next = 5;
                          break;
                        }

                        this.Alert.call("Stock Inserted");
                        this.navigate.navigateBack("/subcat");
                        return _context28.abrupt("return");

                      case 5:
                      case "end":
                        return _context28.stop();
                    }
                  }
                }, _callee28, this);
              }));
            }, function (err) {
              console.log(err);

              _this24.Alert.connection();
            });
          }
        }, {
          key: "api_addorder",
          value: function api_addorder(data1) {
            var _this25 = this;

            this.authservice.con(data1, 'addorder').then(function (res) {
              console.log(res);
              _this25.response = JSON.parse(String(res));
              console.log(_this25.response.message);

              if (_this25.response.error === true && _this25) {
                if (_this25.response.error1 === true) {
                  _this25.Alert.oldincorrect();

                  return;
                }

                _this25.Alert.connection();

                return;
              }

              if (_this25.response.error === false) {
                _this25.Alert.passupdate();
              }
            }, function (err) {
              _this25.Alert.connection();
            });
          }
        }, {
          key: "getprofile",
          value: function getprofile() {
            var _this26 = this;

            this.global.User.subscribe(function (user) {
              console.log('user from global = ' + JSON.stringify(user));

              _this26.authservice.getdata('getprofile/' + user.userid).then(function (data) {
                _this26.global.set_User(JSON.parse(String(data)));

                console.log(' user profile = ' + data);
              });
            });
          }
        }, {
          key: "api_city",
          value: function api_city() {
            var _this27 = this;

            this.authservice.getdata('getcity').then(function (result) {
              _this27.global.set_City(JSON.parse(String(result)));
            }, function (err) {
              _this27.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_subcat",
          value: function api_subcat() {
            var _this28 = this;

            this.authservice.getdata('getallsub').then(function (result) {}, function (err) {
              _this28.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_subcat1",
          value: function api_subcat1() {
            var _this29 = this;

            this.authservice.getdata('getallsub1').then(function (result) {
              _this29.global.set_SubServices1(JSON.parse(String(result)));
            }, function (err) {
              _this29.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_subcat2",
          value: function api_subcat2() {
            var _this30 = this;

            this.authservice.getdata('getallsub2').then(function (result) {
              _this30.global.set_SubServices2(JSON.parse(String(result)));
            }, function (err) {
              _this30.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getcustomer",
          value: function api_getcustomer() {
            var _this31 = this;

            this.authservice.getdata('getcustomer').then(function (result) {
              _this31.global.set_Customer(JSON.parse(String(result)));
            }, function (err) {
              _this31.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getcustomerdetails",
          value: function api_getcustomerdetails(id) {
            var _this32 = this;

            this.authservice.getdata('getcustomerdetail/' + id).then(function (result) {
              _this32.data = JSON.parse(String(result));

              _this32.global.set_Customerdetails(_this32.data);

              console.log(_this32.data); // this.router.navigate(['customerdetail']);
            }, function (err) {
              _this32.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addcustomer",
          value: function api_addcustomer(data) {
            var _this33 = this;

            this.authservice.con(data, 'insertcustomer').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this33, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee29() {
                return regeneratorRuntime.wrap(function _callee29$(_context29) {
                  while (1) {
                    switch (_context29.prev = _context29.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context29.next = 5;
                          break;
                        }

                        this.Alert.call("New Customer Added");
                        this.api_getcustomer();
                        return _context29.abrupt("return");

                      case 5:
                      case "end":
                        return _context29.stop();
                    }
                  }
                }, _callee29, this);
              }));
            }, function (err) {
              console.log(err);

              _this33.Alert.connection();
            });
          }
        }, {
          key: "api_updatecustomerbalance",
          value: function api_updatecustomerbalance(data) {
            var _this34 = this;

            this.authservice.con(data, 'updatecustomerbalance').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this34, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee30() {
                return regeneratorRuntime.wrap(function _callee30$(_context30) {
                  while (1) {
                    switch (_context30.prev = _context30.next) {
                      case 0:
                        this.data = JSON.parse(String(res));

                      case 1:
                      case "end":
                        return _context30.stop();
                    }
                  }
                }, _callee30, this);
              }));
            }, function (err) {
              _this34.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getseller",
          value: function api_getseller() {
            var _this35 = this;

            this.authservice.getdata('getseller').then(function (result) {
              _this35.global.set_Seller(JSON.parse(String(result)));
            }, function (err) {
              _this35.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_getsellerdetails",
          value: function api_getsellerdetails(id) {
            var _this36 = this;

            this.authservice.getdata('getsellerdetail/' + id).then(function (result) {
              _this36.data = JSON.parse(String(result));

              _this36.global.set_Sellerdetails(_this36.data);

              console.log(_this36.data);
            }, function (err) {
              _this36.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_updatesellerbalance",
          value: function api_updatesellerbalance(data) {
            var _this37 = this;

            this.authservice.con(data, 'updatesellerbalance').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this37, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee31() {
                return regeneratorRuntime.wrap(function _callee31$(_context31) {
                  while (1) {
                    switch (_context31.prev = _context31.next) {
                      case 0:
                        this.data = JSON.parse(String(res));

                      case 1:
                      case "end":
                        return _context31.stop();
                    }
                  }
                }, _callee31, this);
              }));
            }, function (err) {
              _this37.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addseller",
          value: function api_addseller(data) {
            var _this38 = this;

            this.authservice.con(data, 'insertseller').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this38, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee32() {
                return regeneratorRuntime.wrap(function _callee32$(_context32) {
                  while (1) {
                    switch (_context32.prev = _context32.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context32.next = 5;
                          break;
                        }

                        this.Alert.call("New Customer Added");
                        this.api_getcustomer();
                        return _context32.abrupt("return");

                      case 5:
                      case "end":
                        return _context32.stop();
                    }
                  }
                }, _callee32, this);
              }));
            }, function (err) {
              console.log(err);

              _this38.Alert.connection();
            });
          }
        }, {
          key: "api_getexpense",
          value: function api_getexpense() {
            var _this39 = this;

            this.authservice.getdata('getexpense').then(function (result) {
              _this39.global.set_Expense(JSON.parse(String(result)));
            }, function (err) {
              _this39.Alert.connection();

              console.log(err);
            });
          }
        }, {
          key: "api_addexpense",
          value: function api_addexpense(data) {
            var _this40 = this;

            this.authservice.con(data, 'insertexpense').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this40, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee33() {
                return regeneratorRuntime.wrap(function _callee33$(_context33) {
                  while (1) {
                    switch (_context33.prev = _context33.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context33.next = 5;
                          break;
                        }

                        this.Alert.call("New Customer Added");
                        this.api_getexpense();
                        return _context33.abrupt("return");

                      case 5:
                      case "end":
                        return _context33.stop();
                    }
                  }
                }, _callee33, this);
              }));
            }, function (err) {
              console.log(err);

              _this40.Alert.connection();
            });
          }
        }, {
          key: "api_addexpensedetails",
          value: function api_addexpensedetails(data) {
            var _this41 = this;

            this.authservice.con(data, 'insertexpensedetail').then(function (res) {
              return (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__awaiter)(_this41, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee34() {
                return regeneratorRuntime.wrap(function _callee34$(_context34) {
                  while (1) {
                    switch (_context34.prev = _context34.next) {
                      case 0:
                        this.response = JSON.parse(String(res).toString());

                        if (!(this.response.error === false)) {
                          _context34.next = 4;
                          break;
                        }

                        this.Alert.call("New Customer Added");
                        return _context34.abrupt("return");

                      case 4:
                      case "end":
                        return _context34.stop();
                    }
                  }
                }, _callee34, this);
              }));
            }, function (err) {
              console.log(err);

              _this41.Alert.connection();
            });
          }
        }, {
          key: "api_getexpensedetails",
          value: function api_getexpensedetails(id) {
            var _this42 = this;

            this.authservice.getdata('getexpensedetail/' + id).then(function (result) {
              _this42.data = JSON.parse(String(result));

              _this42.global.set_Expensedetails(_this42.data);

              console.log(_this42.data);
            }, function (err) {
              _this42.Alert.connection();

              console.log(err);
            });
          }
        }]);

        return ApicallService;
      }();

      _ApicallService.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController
        }, {
          type: _auth_service__WEBPACK_IMPORTED_MODULE_0__.AuthService
        }, {
          type: _global_service__WEBPACK_IMPORTED_MODULE_1__.GlobalService
        }, {
          type: _alert_service__WEBPACK_IMPORTED_MODULE_2__.AlertService
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.NavController
        }];
      };

      _ApicallService = (0, tslib__WEBPACK_IMPORTED_MODULE_3__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_5__.Injectable)({
        providedIn: 'root'
      })], _ApicallService);
      /***/
    },

    /***/
    62430:
    /*!******************************************!*\
      !*** ./src/app/provider/auth.service.ts ***!
      \******************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "AuthService": function AuthService() {
          return (
            /* binding */
            _AuthService
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/common/http */
      91841);
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! rxjs */
      79765);

      var apiUrl = 'https://Learn2earnn.com/CafeVerona/public/'; //const apiUrl = 'http://localhost/caffeverona/public/';

      var _AuthService = /*#__PURE__*/function () {
        function AuthService(http) {
          _classCallCheck(this, AuthService);

          this.http = http;
          this.httpEventListener = new rxjs__WEBPACK_IMPORTED_MODULE_0__.Subject();
          this.observeHttp = this.httpEventListener.asObservable();
        } //   con(data: any , type: any ) {
        //     // tslint:disable-next-line: no-shadowed-variable
        //     return new Promise((resolve, reject) => {
        //       // tslint:disable-next-line: whitespace
        //       this.http.post(apiUrl+type, JSON.stringify(data),{
        //         reportProgress: true,
        //       }).
        //       subscribe(res=>{
        //        console.log(JSON.stringify(res));
        //         resolve(JSON.stringify(res));
        //       }, (err) => {
        //         reject(err);
        //         console.log(err);
        //       });
        //     });
        //   }


        _createClass(AuthService, [{
          key: "con",
          value: function con(data, type) {
            var _this43 = this;

            var req = new _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpRequest('POST', apiUrl + type, data, {
              // headers: You can put your headers type hear such as content/type, token...
              reportProgress: true
            });
            return new Promise(function (resolve, reject) {
              _this43.http.request(req).subscribe(function (event) {
                switch (event.type) {
                  case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpEventType.UploadProgress:
                    var percentDone = Math.round(100 * event.loaded / event.total);

                    _this43.getHttpEvent().next(percentDone); // console.log(`Posting in progress! ${percentDone}% \n
                    // Bytes being upload: ${event.loaded} \n
                    // Total no. of bytes to upload: ${event.total}`);


                    break;

                  case _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpEventType.Response:
                    resolve(JSON.stringify(event.body));
                }
              }, function (err) {
                console.log(err);
                reject(err);
              });
            });
          }
        }, {
          key: "getHttpEvent",
          value: function getHttpEvent() {
            return this.httpEventListener;
          } // geting posts

        }, {
          key: "getdata",
          value: function getdata(type) {
            var _this44 = this;

            return new Promise(function (resolve, reject) {
              _this44.http.get(apiUrl + type).subscribe(function (res) {
                resolve(JSON.stringify(res));
              }, function (err) {
                reject(err);
                console.log(err);
              });
            });
          }
        }]);

        return AuthService;
      }();

      _AuthService.ctorParameters = function () {
        return [{
          type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__.HttpClient
        }];
      };

      _AuthService = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.Injectable)({
        providedIn: 'root'
      })], _AuthService);
      /***/
    }
  }]);
})();
//# sourceMappingURL=default-src_app_provider_apicall_service_ts-es5.js.map