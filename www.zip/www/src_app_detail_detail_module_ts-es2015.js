(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_detail_detail_module_ts"],{

/***/ 42080:
/*!*************************************************!*\
  !*** ./src/app/detail/detail-routing.module.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageRoutingModule": function() { return /* binding */ DetailPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _detail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail.page */ 33495);




const routes = [
    {
        path: '',
        component: _detail_page__WEBPACK_IMPORTED_MODULE_0__.DetailPage
    }
];
let DetailPageRoutingModule = class DetailPageRoutingModule {
};
DetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], DetailPageRoutingModule);



/***/ }),

/***/ 9251:
/*!*****************************************!*\
  !*** ./src/app/detail/detail.module.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPageModule": function() { return /* binding */ DetailPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _detail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detail-routing.module */ 42080);
/* harmony import */ var _detail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.page */ 33495);







let DetailPageModule = class DetailPageModule {
};
DetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _detail_routing_module__WEBPACK_IMPORTED_MODULE_0__.DetailPageRoutingModule
        ],
        declarations: [_detail_page__WEBPACK_IMPORTED_MODULE_1__.DetailPage]
    })
], DetailPageModule);



/***/ }),

/***/ 33495:
/*!***************************************!*\
  !*** ./src/app/detail/detail.page.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "DetailPage": function() { return /* binding */ DetailPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_detail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./detail.page.html */ 40276);
/* harmony import */ var _detail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detail.page.scss */ 99685);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/provider/apicall.service */ 10119);
/* harmony import */ var src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/provider/global.service */ 82836);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 39895);








let DetailPage = class DetailPage {
    constructor(loadingController, router, alert, actionSheetCtrl, menu, apicall, global) {
        this.loadingController = loadingController;
        this.router = router;
        this.alert = alert;
        this.actionSheetCtrl = actionSheetCtrl;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.co = { name: null, other: '' };
        this.se = { name: null, address: null, mobile_no: null };
        this.ty = { name: null, address: null, other: '' };
        this.cu = { name: null, address: null, mobile_no: null };
        this.ex = { name: null };
        this.updatedetail = { customer_id: null, received: null };
        this.del = { s_id: null };
    }
    ngOnInit() {
        this.sign = 'cu';
        this.apicall.api_getseller();
        this.global.Seller.subscribe(res => {
            this.selle = res;
            this.seller = res;
        });
        this.apicall.api_getcustomer();
        this.global.Customer.subscribe(res => {
            this.custome = res;
            this.customer = res;
        });
        this.apicall.api_getexpense();
        this.global.Expense.subscribe(res => {
            this.expens = res;
            this.expense = res;
        });
    }
    filterex(evt) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.expense = this.expens;
            let val = evt.target.value;
            if (val && val.trim() != '') {
                this.expense = this.expense.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addex() {
        this.apicall.api_addexpense(this.ex);
        this.ex.name = null;
    }
    // tslint:disable-next-line:variable-name
    detailex(e_id) {
        console.log(e_id);
        this.apicall.api_getexpensedetails(e_id);
        this.router.navigate(['expensedetail'], { state: { data: { e_id } } });
    }
    filterse(evt) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.seller = this.selle;
            let val = evt.target.value;
            if (val && val.trim() != '') {
                this.seller = this.seller.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addse() {
        this.apicall.api_addseller(this.se);
        this.se.name = null;
        this.se.address = null;
        this.se.mobile_no = null;
    }
    // tslint:disable-next-line:variable-name
    deletese(s_id) {
        console.log(this.del);
        this.apicall.api_getsellerdetails(s_id);
        this.router.navigate(['sellerdetail'], { state: { data: { s_id } } });
    }
    filtercu(evt) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.customer = this.custome;
            let val = evt.target.value;
            if (val && val.trim() != '') {
                this.customer = this.customer.filter((item) => {
                    return ((item.name.toLowerCase()).startsWith(val.toLowerCase()));
                });
            }
        });
    }
    addcu() {
        console.log(this.cu);
        this.apicall.api_addcustomer(this.cu);
        this.cu.name = null;
        this.cu.address = null;
    }
    // tslint:disable-next-line:variable-name
    details(c_id) {
        this.apicall.api_getcustomerdetails(c_id);
        this.router.navigate(['showdetail'], { state: { data: { c_id } } });
    }
    // tslint:disable-next-line:variable-name
    // async customerdetail(c_id) {
    //   const buttons = [
    //     {
    //       text: 'See Detail',
    //       icon: 'eye',
    //       handler: () => {
    //           this.apicall.api_getcustomerdetails(c_id);
    //           this.router.navigate(['showdetail']);
    //       }
    //     },
    //     {
    //       text: ' Add Credit',
    //       icon: 'add',
    //       handler: () => {
    //         this.credit(id);
    //       }
    //     },
    //     {
    //       text: 'Cancel',
    //       icon: 'close',
    //       role: 'cancel',
    //     }
    //   ];
    //
    //   const actionSheet = await this.actionSheetCtrl.create({
    //     header: 'Select One',
    //     buttons
    //   });
    //   await actionSheet.present();
    // }
    credit(id) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Al-Nafay',
                mode: 'ios',
                subHeader: 'Add Credit',
                inputs: [
                    {
                        name: 'name',
                        type: 'number',
                        placeholder: 'Amount'
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                    }, {
                        text: 'Credit',
                        handler: (alertData) => {
                            this.updatedetail.customer_id = id;
                            this.updatedetail.received = alertData.name;
                            console.log(this.updatedetail);
                            /// this.apicall.api_updatecustomerbalance(this.updatedetail);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    // tslint:disable-next-line:variable-name
    detailcustomer(customer_id) {
        this.presentLoadingWithOptions();
        //  this.apicall.api_getcustomerdetails(customer_id);
        this.presentLoadingWithOptions();
        // this.router.navigate(['customerdetail']);
    }
    presentLoadingWithOptions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: 'circular',
                duration: 200,
                message: 'Order Is Being Placed',
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const {} = yield loading.onDidDismiss();
        });
    }
};
DetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: src_app_provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService },
    { type: src_app_provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService }
];
DetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-detail',
        template: _raw_loader_detail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_detail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], DetailPage);



/***/ }),

/***/ 99685:
/*!*****************************************!*\
  !*** ./src/app/detail/detail.page.scss ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content ion-item {\n  --background: transparent;\n}\nion-content ion-item ion-input {\n  border-bottom: 1px solid black;\n}\nion-content ion-button {\n  margin: 15px 20px 15px 20px;\n  border-radius: 30px;\n  box-shadow: 4px 9px 29px -9px #050505;\n}\nion-content ion-list {\n  background: transparent;\n}\nion-row {\n  width: 90%;\n}\nion-row ion-item {\n  width: 100%;\n  margin-top: 0;\n  margin-bottom: -1rem;\n}\nion-row ion-item ion-row {\n  justify-content: center;\n}\nion-row ion-item ion-row ion-label {\n  font-size: small;\n  margin-top: 0;\n  margin-bottom: 0;\n  margin-left: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBS0U7RUFDRSx5QkFBQTtBQUpKO0FBS0k7RUFDRSw4QkFBQTtBQUhOO0FBTUU7RUFDRSwyQkFBQTtFQUNBLG1CQUFBO0VBQ0EscUNBQUE7QUFKSjtBQU1FO0VBQ0UsdUJBQUE7QUFKSjtBQU9BO0VBQ0UsVUFBQTtBQUpGO0FBS0U7RUFDRSxXQUFBO0VBQ0EsYUFBQTtFQUNBLG9CQUFBO0FBSEo7QUFJSTtFQUNFLHVCQUFBO0FBRk47QUFHTTtFQUNFLGdCQUFBO0VBQ0EsYUFBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7QUFEUiIsImZpbGUiOiJkZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaW9uLXRvb2xiYXIge1xyXG4vLyAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xyXG4vLyB9XHJcbmlvbi1jb250ZW50IHtcclxuICAvLyAtLWJhY2tncm91bmQtY29sb3I6IzkyOTQ5QztcclxuICBpb24taXRlbXtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBpb24taW5wdXR7XHJcbiAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBibGFjaztcclxuICAgIH1cclxuICB9XHJcbiAgaW9uLWJ1dHRvbntcclxuICAgIG1hcmdpbjoxNXB4IDIwcHggMTVweCAyMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMzBweDtcclxuICAgIGJveC1zaGFkb3c6IDRweCA5cHggMjlweCAtOXB4ICMwNTA1MDU7XHJcbiAgfVxyXG4gIGlvbi1saXN0e1xyXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgfVxyXG59XHJcbmlvbi1yb3d7XHJcbiAgd2lkdGg6OTAlO1xyXG4gIGlvbi1pdGVte1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBtYXJnaW4tdG9wOiAwO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogLTFyZW07XHJcbiAgICBpb24tcm93e1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgaW9uLWxhYmVse1xyXG4gICAgICAgIGZvbnQtc2l6ZTogc21hbGw7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgICAgIG1hcmdpbi1sZWZ0OiAyMHB4O1xyXG5cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 40276:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/detail/detail.page.html ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Detail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"medium\">\n  <ion-segment color=\"dark\" [(ngModel)]=\"sign\">\n    <ion-segment-button value=\"cu\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Customer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"se\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Distributer</ion-label>\n    </ion-segment-button>\n    <ion-segment-button value=\"ex\">\n      <ion-icon name=\"add\"></ion-icon>\n      <ion-label>Expense</ion-label>\n    </ion-segment-button>\n  </ion-segment>\n  <div color=\"dark\" class=\"main\" [ngSwitch]=\"sign\">\n    <ion-list class=\"f\" *ngSwitchCase=\"'cu'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addcu()\">\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Customer Name</ion-label> -->\n          <ion-input placeholder=\"Customer Name\" name=\"name\" type=\"text\" [(ngModel)]=\"cu.name\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Customer Address</ion-label> -->\n          <ion-input placeholder=\"Customer Address\" name=\"address\" type=\"text\" [(ngModel)]=\"cu.address\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Customer Mobile No</ion-label> -->\n          <ion-input placeholder=\"Customer Mobile No\" name=\"address\" type=\"text\" [(ngModel)]=\"cu.mobile_no\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"dark\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar (ionInput)=\"filtercu($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of customer\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"dark\" (click)=\"details(a.c_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'se'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addse()\">\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Distributer Name</ion-label> -->\n          <ion-input placeholder=\"Distributer Name\" name=\"name\" type=\"text\" [(ngModel)]=\"se.name\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Distributer Address</ion-label> -->\n          <ion-input placeholder=\"Distributer Address\" name=\"address\" type=\"text\" [(ngModel)]=\"se.address\"></ion-input>\n        </ion-item>\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Mobile NO</ion-label> -->\n          <ion-input placeholder=\"Mobile No\" name=\"address\" type=\"text\" [(ngModel)]=\"se.mobile_no\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"dark\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar (ionInput)=\"filterse($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of seller\">\n        <ion-item>\n          {{a.name}}&nbsp;{{a.address}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"dark\" (click)=\"deletese(a.s_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n    <ion-list class=\"f\" *ngSwitchCase=\"'ex'\">\n      <form #form=\"ngForm\" (ngSubmit)=\"addex()\">\n        <ion-item lines=\"none\">\n          <!-- <ion-label color=\"dark\" position=\"floating\">Add Expense</ion-label> -->\n          <ion-input placeholder=\"Add Expense\" name=\"name\" type=\"text\" [(ngModel)]=\"ex.name\"></ion-input>\n        </ion-item>\n        <ion-button expand=\"block\" color=\"dark\" type=\"submit\" [disabled]=\"form.invalid\">Add</ion-button>\n      </form>\n      <ion-searchbar (ionInput)=\"filterex($event)\"></ion-searchbar>\n      <ion-item-sliding *ngFor=\"let a of expense\">\n        <ion-item>\n          {{a.name}}\n        </ion-item>\n        <ion-item-options side=\"end\">\n          <ion-item-option color=\"dark\" (click)=\"detailex(a.e_id)\">See Detail</ion-item-option>\n        </ion-item-options>\n      </ion-item-sliding>\n    </ion-list>\n  </div>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_detail_detail_module_ts-es2015.js.map