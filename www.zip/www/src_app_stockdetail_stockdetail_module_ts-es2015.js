(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_stockdetail_stockdetail_module_ts"],{

/***/ 79566:
/*!***********************************************************!*\
  !*** ./src/app/stockdetail/stockdetail-routing.module.ts ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StockdetailPageRoutingModule": function() { return /* binding */ StockdetailPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _stockdetail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./stockdetail.page */ 90848);




const routes = [
    {
        path: '',
        component: _stockdetail_page__WEBPACK_IMPORTED_MODULE_0__.StockdetailPage
    }
];
let StockdetailPageRoutingModule = class StockdetailPageRoutingModule {
};
StockdetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], StockdetailPageRoutingModule);



/***/ }),

/***/ 50194:
/*!***************************************************!*\
  !*** ./src/app/stockdetail/stockdetail.module.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StockdetailPageModule": function() { return /* binding */ StockdetailPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _stockdetail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./stockdetail-routing.module */ 79566);
/* harmony import */ var _stockdetail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stockdetail.page */ 90848);







let StockdetailPageModule = class StockdetailPageModule {
};
StockdetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _stockdetail_routing_module__WEBPACK_IMPORTED_MODULE_0__.StockdetailPageRoutingModule
        ],
        declarations: [_stockdetail_page__WEBPACK_IMPORTED_MODULE_1__.StockdetailPage]
    })
], StockdetailPageModule);



/***/ }),

/***/ 90848:
/*!*************************************************!*\
  !*** ./src/app/stockdetail/stockdetail.page.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "StockdetailPage": function() { return /* binding */ StockdetailPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_stockdetail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./stockdetail.page.html */ 506);
/* harmony import */ var _stockdetail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stockdetail.page.scss */ 3174);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);







let StockdetailPage = class StockdetailPage {
    constructor(menu, apicall, global) {
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
    }
    ngOnInit() {
        this.folder = "Café Verona";
        this.menu.enable(true);
        this.apicall.getstock();
        this.global.Cart.subscribe(res => {
            this.details = res;
        });
    }
};
StockdetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__.MenuController },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService }
];
StockdetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-stockdetail',
        template: _raw_loader_stockdetail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_stockdetail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], StockdetailPage);



/***/ }),

/***/ 3174:
/*!***************************************************!*\
  !*** ./src/app/stockdetail/stockdetail.page.scss ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".main {\n  margin: 10px;\n  border: 1px solid black;\n  background-color: rgba(0, 0, 0, 0.548);\n  border-radius: 10px;\n}\n.main .right11 {\n  float: right;\n  margin-right: 20px;\n}\n.main .head {\n  display: inline;\n  width: 100%;\n}\n.main .head .left {\n  float: left;\n  margin-left: 10px;\n}\n.main .head .center {\n  margin: 0 auto;\n  margin-top: 16px;\n  width: 140px;\n  padding-left: 50px;\n}\n.main .head .right {\n  float: right;\n  margin-right: 20px;\n  margin-top: -22px;\n}\n.main .body {\n  display: inline;\n  width: 100%;\n}\n.main .body .left1 {\n  float: left;\n  margin-left: 10px;\n}\n.main .body .center1 {\n  margin: 0 auto;\n  margin-top: 15px;\n  width: 100px;\n  padding-left: 50px;\n}\n.main .body .right1 {\n  float: right;\n  margin-right: 20px;\n  margin-top: -22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN0b2NrZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLFlBQUE7RUFDQSx1QkFBQTtFQUNBLHNDQUFBO0VBQ0EsbUJBQUE7QUFDSjtBQUFJO0VBQ0ksWUFBQTtFQUNBLGtCQUFBO0FBRVI7QUFBSTtFQUNJLGVBQUE7RUFDQSxXQUFBO0FBRVI7QUFEUTtFQUNJLFdBQUE7RUFDQSxpQkFBQTtBQUdaO0FBRFE7RUFDSSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUFHWjtBQURRO0VBQ0csWUFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QUFHWDtBQUFJO0VBQ0ksZUFBQTtFQUNBLFdBQUE7QUFFUjtBQURRO0VBQ0ksV0FBQTtFQUNBLGlCQUFBO0FBR1o7QUFEUTtFQUNJLGNBQUE7RUFDQSxnQkFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtBQUdaO0FBRFE7RUFDRyxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQUdYIiwiZmlsZSI6InN0b2NrZGV0YWlsLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5tYWlue1xyXG4gICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgYmxhY2s7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDAsIDAsIDAsIDAuNTQ4KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAucmlnaHQxMXtcclxuICAgICAgICBmbG9hdDogcmlnaHQ7IFxyXG4gICAgICAgIG1hcmdpbi1yaWdodDogMjBweDtcclxuICAgICB9XHJcbiAgICAuaGVhZHtcclxuICAgICAgICBkaXNwbGF5OiBpbmxpbmU7XHJcbiAgICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgICAgLmxlZnR7XHJcbiAgICAgICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmNlbnRlcntcclxuICAgICAgICAgICAgbWFyZ2luOjAgYXV0bztcclxuICAgICAgICAgICAgbWFyZ2luLXRvcDogMTZweDtcclxuICAgICAgICAgICAgd2lkdGg6MTQwcHg7XHJcbiAgICAgICAgICAgIHBhZGRpbmctbGVmdDogNTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLnJpZ2h0e1xyXG4gICAgICAgICAgIGZsb2F0OiByaWdodDsgXHJcbiAgICAgICAgICAgbWFyZ2luLXJpZ2h0OiAyMHB4O1xyXG4gICAgICAgICAgIG1hcmdpbi10b3A6IC0yMnB4O1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuICAgIC5ib2R5e1xyXG4gICAgICAgIGRpc3BsYXk6IGlubGluZTtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICAubGVmdDF7XHJcbiAgICAgICAgICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgICAgICAgICBtYXJnaW4tbGVmdDogMTBweDtcclxuICAgICAgICB9XHJcbiAgICAgICAgLmNlbnRlcjF7XHJcbiAgICAgICAgICAgIG1hcmdpbjowIGF1dG87XHJcbiAgICAgICAgICAgIG1hcmdpbi10b3A6IDE1cHg7XHJcbiAgICAgICAgICAgIHdpZHRoOjEwMHB4O1xyXG4gICAgICAgICAgICBwYWRkaW5nLWxlZnQ6IDUwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5yaWdodDF7XHJcbiAgICAgICAgICAgZmxvYXQ6IHJpZ2h0OyBcclxuICAgICAgICAgICBtYXJnaW4tcmlnaHQ6IDIwcHg7XHJcbiAgICAgICAgICAgbWFyZ2luLXRvcDogLTIycHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59Il19 */");

/***/ }),

/***/ 506:
/*!*****************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stockdetail/stockdetail.page.html ***!
  \*****************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-row class=\"main\" *ngFor=\"let a of details\"> \n    <ion-row class=\"head\">\n      <p class=\"left\">Date Purchased</p>\n      <p class=\"center\" > Quantity</p> \n      <p class=\"right\"  > Price</p>\n      \n    </ion-row>\n    <ion-row class=\"body\">\n      <p class=\"left1\">{{a.ish_date_time}}</p> \n      <p class=\"center1\" >{{a.ish_quantity}}</p>\n      <p class=\"right1\"  > {{a.ish_price}}</p>\n      \n    </ion-row>\n  </ion-row>\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_stockdetail_stockdetail_module_ts-es2015.js.map