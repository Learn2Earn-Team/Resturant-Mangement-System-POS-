(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_subcat_subcat_module_ts"],{

/***/ 1695:
/*!*************************************************!*\
  !*** ./src/app/subcat/subcat-routing.module.ts ***!
  \*************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubcatPageRoutingModule": function() { return /* binding */ SubcatPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _subcat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subcat.page */ 75708);




const routes = [
    {
        path: '',
        component: _subcat_page__WEBPACK_IMPORTED_MODULE_0__.SubcatPage
    }
];
let SubcatPageRoutingModule = class SubcatPageRoutingModule {
};
SubcatPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SubcatPageRoutingModule);



/***/ }),

/***/ 339:
/*!*****************************************!*\
  !*** ./src/app/subcat/subcat.module.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubcatPageModule": function() { return /* binding */ SubcatPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _subcat_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./subcat-routing.module */ 1695);
/* harmony import */ var _subcat_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subcat.page */ 75708);







let SubcatPageModule = class SubcatPageModule {
};
SubcatPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _subcat_routing_module__WEBPACK_IMPORTED_MODULE_0__.SubcatPageRoutingModule
        ],
        declarations: [_subcat_page__WEBPACK_IMPORTED_MODULE_1__.SubcatPage]
    })
], SubcatPageModule);



/***/ }),

/***/ 75708:
/*!***************************************!*\
  !*** ./src/app/subcat/subcat.page.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SubcatPage": function() { return /* binding */ SubcatPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_subcat_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./subcat.page.html */ 5470);
/* harmony import */ var _subcat_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./subcat.page.scss */ 47024);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);








let SubcatPage = class SubcatPage {
    constructor(route, actionSheetController, alert, global, apicall) {
        this.route = route;
        this.actionSheetController = actionSheetController;
        this.alert = alert;
        this.global = global;
        this.apicall = apicall;
        this.add = { id: "", name: "", min_quantity: "" };
        this.del = { id: "" };
        this.editdata = { id: null, name: null, callid: null, min_quantity: null };
    }
    ngOnInit() {
        this.folder = "Café Verona";
        this.global.Subcat.subscribe(res => {
            this.subcat = res;
            console.log(res);
        });
        this.global.Catid.subscribe(res => {
            this.id = res;
            console.log(res);
        });
    }
    addnew() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Café Verona',
                mode: 'ios',
                subHeader: 'Add New Item',
                inputs: [
                    {
                        name: 'name',
                        type: 'text',
                        placeholder: "Name"
                    }, {
                        name: 'min',
                        type: 'number',
                        placeholder: "Minimum Quantity"
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                    }, {
                        text: 'Okay',
                        handler: (alertData) => {
                            this.add.name = alertData.name;
                            this.add.min_quantity = alertData.min;
                            this.add.id = this.id;
                            console.log(this.add);
                            this.apicall.addsub(this.add);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    sheet(id, name, cid, min) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Manage',
                cssClass: 'my-custom-class',
                buttons: [{
                        text: 'Add Purchase',
                        icon: 'add-outline',
                        handler: () => {
                            this.global.set_Selected(id);
                            this.route.navigate(['/add']);
                        }
                    },
                    {
                        text: 'Edit Item',
                        icon: 'pencil-outline',
                        handler: () => {
                            this.edit(id, name, min);
                        }
                    }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                        }
                    }]
            });
            yield actionSheet.present();
        });
    }
    edit(id, name, min) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Café Verona',
                mode: 'ios',
                subHeader: 'Edit Item',
                inputs: [
                    {
                        name: 'name',
                        type: 'text',
                        placeholder: name
                    },
                    {
                        name: 'min',
                        type: 'number',
                        placeholder: min
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                    }, {
                        text: 'Update',
                        handler: (alertData) => {
                            this.editdata.name = alertData.name;
                            this.editdata.min_quantity = alertData.min;
                            this.editdata.id = id;
                            this.editdata.callid = this.id;
                            this.apicall.editsubcat(this.editdata);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
SubcatPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService }
];
SubcatPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-subcat',
        template: _raw_loader_subcat_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_subcat_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SubcatPage);



/***/ }),

/***/ 47024:
/*!*****************************************!*\
  !*** ./src/app/subcat/subcat.page.scss ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-row {\n  width: 100%;\n  justify-content: center;\n}\nion-row ion-button {\n  margin: 10px;\n  width: 100%;\n  --background-color: rgb(0, 0, 0, 0.5);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmNhdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsdUJBQUE7QUFDSjtBQUFJO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxxQ0FBQTtBQUVSIiwiZmlsZSI6InN1YmNhdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tcm93e1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIC0tYmFja2dyb3VuZC1jb2xvcjogcmdiKDAsIDAsIDAsIDAuNSk7XHJcbiAgICB9XHJcbn0iXX0= */");

/***/ }),

/***/ 5470:
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subcat/subcat.page.html ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"medium\">\n  <ion-row *ngFor=\"let a of subcat\">\n    <ion-button expand=\"block\" color=\"dark\" (click)=\"sheet(a.isc_id,a.is_name,a.ic_id,a.min_quantity)\">{{a.is_name}}</ion-button>\n  </ion-row>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"addnew()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_subcat_subcat_module_ts-es2015.js.map