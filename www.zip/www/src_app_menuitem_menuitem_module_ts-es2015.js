(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_menuitem_menuitem_module_ts"],{

/***/ 61159:
/*!*****************************************************!*\
  !*** ./src/app/menuitem/menuitem-routing.module.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuitemPageRoutingModule": function() { return /* binding */ MenuitemPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _menuitem_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menuitem.page */ 51525);




const routes = [
    {
        path: '',
        component: _menuitem_page__WEBPACK_IMPORTED_MODULE_0__.MenuitemPage
    }
];
let MenuitemPageRoutingModule = class MenuitemPageRoutingModule {
};
MenuitemPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], MenuitemPageRoutingModule);



/***/ }),

/***/ 16825:
/*!*********************************************!*\
  !*** ./src/app/menuitem/menuitem.module.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuitemPageModule": function() { return /* binding */ MenuitemPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _menuitem_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./menuitem-routing.module */ 61159);
/* harmony import */ var _menuitem_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menuitem.page */ 51525);







let MenuitemPageModule = class MenuitemPageModule {
};
MenuitemPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _menuitem_routing_module__WEBPACK_IMPORTED_MODULE_0__.MenuitemPageRoutingModule
        ],
        declarations: [_menuitem_page__WEBPACK_IMPORTED_MODULE_1__.MenuitemPage]
    })
], MenuitemPageModule);



/***/ }),

/***/ 51525:
/*!*******************************************!*\
  !*** ./src/app/menuitem/menuitem.page.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "MenuitemPage": function() { return /* binding */ MenuitemPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_menuitem_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./menuitem.page.html */ 97555);
/* harmony import */ var _menuitem_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./menuitem.page.scss */ 58577);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);








let MenuitemPage = class MenuitemPage {
    constructor(route, cdr, toast, global, apicall) {
        this.route = route;
        this.cdr = cdr;
        this.toast = toast;
        this.global = global;
        this.apicall = apicall;
    }
    ngAfterContentChecked() {
        this.cdr.detectChanges();
        // call or add here your code
    }
    ionViewWillEnter() {
    }
    addnew() {
        this.route.navigate(["/addsub"]);
    }
    ngOnInit() {
        this.global.Menusub.subscribe((res) => {
            this.Cat = res;
            console.log(res);
        });
    }
};
MenuitemPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__.Router },
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService }
];
MenuitemPage = (0,tslib__WEBPACK_IMPORTED_MODULE_7__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-menuitem',
        template: _raw_loader_menuitem_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_menuitem_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], MenuitemPage);



/***/ }),

/***/ 58577:
/*!*********************************************!*\
  !*** ./src/app/menuitem/menuitem.page.scss ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content ion-row {\n  justify-content: center;\n}\nion-content ion-row ion-col {\n  background-color: var(--ion-color-dark);\n  box-shadow: 0px 2px 8px -1px #050505;\n  text-align: center;\n  min-width: 16rem;\n  max-width: 16rem;\n  margin: 3px;\n  border-radius: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1lbnVpdGVtLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDSTtFQUNJLHVCQUFBO0FBQVI7QUFDUTtFQUNFLHVDQUFBO0VBQ0Esb0NBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxXQUFBO0VBQ0EsbUJBQUE7QUFDViIsImZpbGUiOiJtZW51aXRlbS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudCB7XHJcbiAgICBpb24tcm93e1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGlvbi1jb2wge1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xyXG4gICAgICAgICAgYm94LXNoYWRvdzogMHB4IDJweCA4cHggLTFweCAjMDUwNTA1O1xyXG4gICAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgICAgbWluLXdpZHRoOiAxNnJlbTtcclxuICAgICAgICAgIG1heC13aWR0aDogMTZyZW07XHJcbiAgICAgICAgICBtYXJnaW46IDNweDtcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbn1cclxuIl19 */");

/***/ }),

/***/ 97555:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/menuitem/menuitem.page.html ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-grid color=\"dark\">\n    <ion-row >\n      <ion-col class=\"main\" *ngFor=\"let a of Cat\" (click)=\"getsub(a.ic_id)\">\n        <h3>{{a.m_name}}</h3>\n        <p>Production Cost:{{a.m_production_cost}}</p>\n        <p>Retail Cost:{{a.m_price}}</p>\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"addnew()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_menuitem_menuitem_module_ts-es2015.js.map