(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_sellerdetail_sellerdetail_module_ts"],{

/***/ 95041:
/*!*************************************************************!*\
  !*** ./src/app/sellerdetail/sellerdetail-routing.module.ts ***!
  \*************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SellerdetailPageRoutingModule": function() { return /* binding */ SellerdetailPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _sellerdetail_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sellerdetail.page */ 86823);




const routes = [
    {
        path: '',
        component: _sellerdetail_page__WEBPACK_IMPORTED_MODULE_0__.SellerdetailPage
    }
];
let SellerdetailPageRoutingModule = class SellerdetailPageRoutingModule {
};
SellerdetailPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], SellerdetailPageRoutingModule);



/***/ }),

/***/ 40188:
/*!*****************************************************!*\
  !*** ./src/app/sellerdetail/sellerdetail.module.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SellerdetailPageModule": function() { return /* binding */ SellerdetailPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _sellerdetail_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./sellerdetail-routing.module */ 95041);
/* harmony import */ var _sellerdetail_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sellerdetail.page */ 86823);







let SellerdetailPageModule = class SellerdetailPageModule {
};
SellerdetailPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _sellerdetail_routing_module__WEBPACK_IMPORTED_MODULE_0__.SellerdetailPageRoutingModule
        ],
        declarations: [_sellerdetail_page__WEBPACK_IMPORTED_MODULE_1__.SellerdetailPage]
    })
], SellerdetailPageModule);



/***/ }),

/***/ 86823:
/*!***************************************************!*\
  !*** ./src/app/sellerdetail/sellerdetail.page.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "SellerdetailPage": function() { return /* binding */ SellerdetailPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_sellerdetail_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./sellerdetail.page.html */ 55575);
/* harmony import */ var _sellerdetail_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sellerdetail.page.scss */ 47293);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);








let SellerdetailPage = class SellerdetailPage {
    constructor(loadingController, alert, router, menu, apicall, global) {
        this.loadingController = loadingController;
        this.alert = alert;
        this.router = router;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.history = { invoice_id: null, name: 'customer', type: null, quantity: null, action: null, user: null };
        this.updatedetail = { s_id: '', net_balance: '', received: '' };
        // tslint:disable-next-line:variable-name
        this.rece = { s_id: null, total: null, debit: null, net_balance: 0 };
    }
    ngOnInit() {
        console.log(history.state.data);
        this.rece.s_id = history.state.data.s_id;
        this.global.Sellerdetails.subscribe(res => {
            console.log(res);
            this.data = res;
            if (Object.keys(this.data).length === 0) {
                this.rece.net_balance = 0;
                console.log(this.rece.net_balance);
            }
            else {
                this.last = this.data[this.data.length - 1];
                this.rece.net_balance = this.last.net_balance;
                console.log(this.rece.net_balance);
                // console.log(this.last.net_balance);
            }
        });
    }
    updatecustomerbalance() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            // this.rece.c_id = this.data[0].c_id;
            //
            this.updatedetail.received = this.rece;
            console.log(this.rece);
            this.apicall.api_updatesellerbalance(this.rece);
            this.router.navigate(['detail']);
        });
    }
    presentLoadingWithOptions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: "circular",
                duration: 200,
                message: 'Order Is Being Placed',
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const {} = yield loading.onDidDismiss();
        });
    }
};
SellerdetailPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService }
];
SellerdetailPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-sellerdetail',
        template: _raw_loader_sellerdetail_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_sellerdetail_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], SellerdetailPage);



/***/ }),

/***/ 47293:
/*!*****************************************************!*\
  !*** ./src/app/sellerdetail/sellerdetail.page.scss ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content {\n  /* Zebra striping */\n}\n@media screen and (max-width: 550px) {\n  ion-content td, ion-content th {\n    font-size: 14px;\n  }\n}\n@media screen and (max-width: 500px) {\n  ion-content td, ion-content th {\n    font-size: 12px;\n  }\n}\n@media screen and (max-width: 450px) {\n  ion-content td, ion-content th {\n    font-size: 11px;\n  }\n}\n@media screen and (max-width: 400px) {\n  ion-content td, ion-content th {\n    font-size: 10px;\n  }\n}\n@media screen and (max-width: 370px) {\n  ion-content td, ion-content th {\n    font-size: 9px;\n  }\n}\nion-content table {\n  width: 100%;\n  border-collapse: collapse;\n}\nion-content tr:nth-of-type(odd) {\n  background: black;\n}\nion-content th {\n  background: #333;\n  color: white;\n}\nion-content td, ion-content th {\n  padding: 3px;\n  border: 1px solid #ccc;\n  text-align: left;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNlbGxlcmRldGFpbC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBR0E7RUFnQ0UsbUJBQUE7QUFqQ0Y7QUFHRTtFQUNFO0lBQ0UsZUFBQTtFQURKO0FBQ0Y7QUFHRTtFQUNFO0lBQ0UsZUFBQTtFQURKO0FBQ0Y7QUFHRTtFQUNFO0lBQ0UsZUFBQTtFQURKO0FBQ0Y7QUFHRTtFQUNFO0lBQ0UsZUFBQTtFQURKO0FBQ0Y7QUFHRTtFQUNFO0lBQ0UsY0FBQTtFQURKO0FBQ0Y7QUFJRTtFQUNFLFdBQUE7RUFDQSx5QkFBQTtBQUZKO0FBS0U7RUFDRSxpQkFBQTtBQUhKO0FBS0U7RUFDRSxnQkFBQTtFQUNBLFlBQUE7QUFISjtBQUtFO0VBQ0UsWUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QUFISiIsImZpbGUiOiJzZWxsZXJkZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gaW9uLXRvb2xiYXIge1xyXG4vLyAgIC0tYmFja2dyb3VuZDogdmFyKC0taW9uLWNvbG9yLXN1Y2Nlc3MpO1xyXG4vLyB9XHJcbmlvbi1jb250ZW50IHtcclxuICAvLyAtLWJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCh0byBib3R0b20sICM1ZjhmZjgsICNmZmZmZmYpO1xyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDU1MHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICBmb250LXNpemU6IDE0cHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDUwMHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICBmb250LXNpemU6IDEycHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQ1MHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICBmb250LXNpemU6IDExcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDQwMHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICBmb250LXNpemU6IDEwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIEBtZWRpYSBzY3JlZW4gYW5kIChtYXgtd2lkdGg6IDM3MHB4KSB7XHJcbiAgICB0ZCx0aCAge1xyXG4gICAgICBmb250LXNpemU6IDlweDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIHRhYmxlIHtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYm9yZGVyLWNvbGxhcHNlOiBjb2xsYXBzZTtcclxuICB9XHJcbiAgLyogWmVicmEgc3RyaXBpbmcgKi9cclxuICB0cjpudGgtb2YtdHlwZShvZGQpIHtcclxuICAgIGJhY2tncm91bmQ6IGJsYWNrO1xyXG4gIH1cclxuICB0aCB7XHJcbiAgICBiYWNrZ3JvdW5kOiAjMzMzO1xyXG4gICAgY29sb3I6IHdoaXRlO1xyXG4gIH1cclxuICB0ZCwgdGgge1xyXG4gICAgcGFkZGluZzogM3B4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2NjYztcclxuICAgIHRleHQtYWxpZ246IGxlZnQ7XHJcbiAgfVxyXG5cclxufVxyXG4iXX0= */");

/***/ }),

/***/ 55575:
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/sellerdetail/sellerdetail.page.html ***!
  \*******************************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button color=\"light\"></ion-back-button>\n    </ion-buttons>\n    <ion-title color=\"light\">Customer Ledger</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <table>\n    <thead>\n    <tr>\n      <th style=\"background: #333; \">Date</th>\n      <th style=\"background: #333; \">Total</th>\n      <th style=\"background: rgb(4, 151, 70); \">Debit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Credit</th>\n      <th style=\"background: rgb(204, 13, 13); \">Net Balance</th>\n    </tr>\n    </thead>\n    <tbody>\n\n    <tr *ngFor=\"let a of data\">\n      <td>{{a.other}}</td>\n      <td>{{a.total}}</td>\n      <td>{{a.debit}}</td>\n      <td>{{a.credit}}</td>\n      <td>{{a.net_balance}}</td>\n      <!--       <ion-button style=\"margin: 1px\" (click)=\"updatecustomerbalance(a)\"></ion-button>-->\n    </tr>\n    </tbody>\n  </table>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Total\n    </ion-label>\n    <ion-input name=\"total\" type=\"number\" [(ngModel)]=\"rece.total\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-item style=\"--background: transparent;\">\n    <ion-label style=\"width: 80%;\">\n      Debit\n    </ion-label>\n    <ion-input name=\"debit\" type=\"number\" [(ngModel)]=\"rece.debit\" text-right  style=\"border-bottom: 1px solid black;\"></ion-input>\n  </ion-item>\n  <ion-button  expand=\"block\" color=\"dark\" style=\"margin:10px;height:2.5rem\" (click) = updatecustomerbalance()>Total</ion-button>\n\n</ion-content>\n");

/***/ })

}]);
//# sourceMappingURL=src_app_sellerdetail_sellerdetail_module_ts-es2015.js.map