(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_ordercat_ordercat_module_ts"], {
    /***/
    53015:
    /*!*****************************************************!*\
      !*** ./src/app/ordercat/ordercat-routing.module.ts ***!
      \*****************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "OrdercatPageRoutingModule": function OrdercatPageRoutingModule() {
          return (
            /* binding */
            _OrdercatPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _ordercat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./ordercat.page */
      31229);

      var routes = [{
        path: '',
        component: _ordercat_page__WEBPACK_IMPORTED_MODULE_0__.OrdercatPage
      }];

      var _OrdercatPageRoutingModule = function OrdercatPageRoutingModule() {
        _classCallCheck(this, OrdercatPageRoutingModule);
      };

      _OrdercatPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _OrdercatPageRoutingModule);
      /***/
    },

    /***/
    85546:
    /*!*********************************************!*\
      !*** ./src/app/ordercat/ordercat.module.ts ***!
      \*********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "OrdercatPageModule": function OrdercatPageModule() {
          return (
            /* binding */
            _OrdercatPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _ordercat_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./ordercat-routing.module */
      53015);
      /* harmony import */


      var _ordercat_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./ordercat.page */
      31229);

      var _OrdercatPageModule = function OrdercatPageModule() {
        _classCallCheck(this, OrdercatPageModule);
      };

      _OrdercatPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _ordercat_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrdercatPageRoutingModule],
        declarations: [_ordercat_page__WEBPACK_IMPORTED_MODULE_1__.OrdercatPage]
      })], _OrdercatPageModule);
      /***/
    },

    /***/
    31229:
    /*!*******************************************!*\
      !*** ./src/app/ordercat/ordercat.page.ts ***!
      \*******************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "OrdercatPage": function OrdercatPage() {
          return (
            /* binding */
            _OrdercatPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_ordercat_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./ordercat.page.html */
      67818);
      /* harmony import */


      var _ordercat_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./ordercat.page.scss */
      94731);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../provider/apicall.service */
      10119);
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../provider/global.service */
      82836);

      var _OrdercatPage = /*#__PURE__*/function () {
        function OrdercatPage(loadingController, actionSheetController, route, menu, apicall, global) {
          _classCallCheck(this, OrdercatPage);

          this.loadingController = loadingController;
          this.actionSheetController = actionSheetController;
          this.route = route;
          this.menu = menu;
          this.apicall = apicall;
          this.global = global;
        }

        _createClass(OrdercatPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.apicall.getmenu();
            this.global.Menu.subscribe(function (res) {
              _this.data = res;
            });
            this.folder = 'Café Verona';
            this.menu.enable(true);
          }
        }, {
          key: "sheet",
          value: function sheet(id, img) {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.apicall.getmenudetails(id);
                      this.selected = this.data.filter(function (data) {
                        return data.mc_id == id;
                      });
                      this.presentLoading();
                      console.log(this.selected);
                      this.global.set_Cimage(this.selected);

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "presentLoading",
          value: function presentLoading() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var loading, _yield$loading$onDidD, role, data;

              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.loadingController.create({
                        cssClass: 'my-custom-class',
                        message: 'Please wait...',
                        duration: 1000
                      });

                    case 2:
                      loading = _context2.sent;
                      _context2.next = 5;
                      return loading.present();

                    case 5:
                      _context2.next = 7;
                      return loading.onDidDismiss();

                    case 7:
                      _yield$loading$onDidD = _context2.sent;
                      role = _yield$loading$onDidD.role;
                      data = _yield$loading$onDidD.data;
                      console.log('Loading dismissed!');
                      this.route.navigate(['/ordersub']);

                    case 12:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }]);

        return OrdercatPage;
      }();

      _OrdercatPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.LoadingController
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ActionSheetController
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_6__.Router
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService
        }];
      };

      _OrdercatPage = (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-ordercat',
        template: _raw_loader_ordercat_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_ordercat_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _OrdercatPage);
      /***/
    },

    /***/
    94731:
    /*!*********************************************!*\
      !*** ./src/app/ordercat/ordercat.page.scss ***!
      \*********************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-icon {\n  zoom: 1.5;\n  margin-right: 5px;\n}\n\nion-row {\n  justify-content: center;\n}\n\nion-row ion-col {\n  background-color: var(--ion-color-dark);\n  box-shadow: 0px 2px 8px -1px #050505;\n  text-align: center;\n  min-width: 10rem;\n  max-width: 10rem;\n  min-height: 10rem;\n  margin: 3px;\n  border-radius: 10px;\n}\n\nion-row ion-col img {\n  max-width: 8rem;\n  max-height: 8rem;\n  border-radius: 5px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyY2F0LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLFNBQUE7RUFDQSxpQkFBQTtBQUNGOztBQUNBO0VBQ0ksdUJBQUE7QUFFSjs7QUFESTtFQUNFLHVDQUFBO0VBQ0Esb0NBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtBQUdOOztBQUZNO0VBQ0UsZUFBQTtFQUNBLGdCQUFBO0VBQ0Esa0JBQUE7QUFJUiIsImZpbGUiOiJvcmRlcmNhdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taWNvbntcclxuICB6b29tOiAxLjU7XHJcbiAgbWFyZ2luLXJpZ2h0OiA1cHg7XHJcbn1cclxuaW9uLXJvd3tcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgaW9uLWNvbCB7XHJcbiAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgICAgYm94LXNoYWRvdzogMHB4IDJweCA4cHggLTFweCAjMDUwNTA1O1xyXG4gICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgIG1pbi13aWR0aDogMTByZW07XHJcbiAgICAgIG1heC13aWR0aDogMTByZW07XHJcbiAgICAgIG1pbi1oZWlnaHQ6IDEwcmVtO1xyXG4gICAgICBtYXJnaW46IDNweDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgaW1ne1xyXG4gICAgICAgIG1heC13aWR0aDogOHJlbTtcclxuICAgICAgICBtYXgtaGVpZ2h0OiA4cmVtO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH0iXX0= */";
      /***/
    },

    /***/
    67818:
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ordercat/ordercat.page.html ***!
      \***********************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n    <ion-icon slot=\"end\" routerLink=\"/cart\" name=\"cart\"></ion-icon>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-grid color=\"dark\">\n    <ion-row>\n      <ion-col color=\"dark\" *ngFor=\"let a of data\" (click)=\"sheet(a.mc_id,a.image)\">\n        <img src={{a.image}}>\n        <br>\n        {{a.mc_name}}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n</ion-content>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_ordercat_ordercat_module_ts-es5.js.map