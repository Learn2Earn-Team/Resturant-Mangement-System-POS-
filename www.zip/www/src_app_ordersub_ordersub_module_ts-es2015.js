(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_ordersub_ordersub_module_ts"],{

/***/ 55634:
/*!*****************************************************!*\
  !*** ./src/app/ordersub/ordersub-routing.module.ts ***!
  \*****************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersubPageRoutingModule": function() { return /* binding */ OrdersubPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ordersub_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ordersub.page */ 86646);




const routes = [
    {
        path: '',
        component: _ordersub_page__WEBPACK_IMPORTED_MODULE_0__.OrdersubPage
    }
];
let OrdersubPageRoutingModule = class OrdersubPageRoutingModule {
};
OrdersubPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], OrdersubPageRoutingModule);



/***/ }),

/***/ 9280:
/*!*********************************************!*\
  !*** ./src/app/ordersub/ordersub.module.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersubPageModule": function() { return /* binding */ OrdersubPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _ordersub_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ordersub-routing.module */ 55634);
/* harmony import */ var _ordersub_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ordersub.page */ 86646);







let OrdersubPageModule = class OrdersubPageModule {
};
OrdersubPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _ordersub_routing_module__WEBPACK_IMPORTED_MODULE_0__.OrdersubPageRoutingModule
        ],
        declarations: [_ordersub_page__WEBPACK_IMPORTED_MODULE_1__.OrdersubPage]
    })
], OrdersubPageModule);



/***/ }),

/***/ 86646:
/*!*******************************************!*\
  !*** ./src/app/ordersub/ordersub.page.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "OrdersubPage": function() { return /* binding */ OrdersubPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_ordersub_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./ordersub.page.html */ 41778);
/* harmony import */ var _ordersub_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ordersub.page.scss */ 56272);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);







let OrdersubPage = class OrdersubPage {
    constructor(cdr, toast, global, apicall) {
        this.cdr = cdr;
        this.toast = toast;
        this.global = global;
        this.apicall = apicall;
        this.price = 1;
        this.number = 1;
        this.addtocart = { m_id: '', item_name: '', quantity: '', price: '', image: '' };
        this.cart = [];
        this.check = [];
    }
    ngAfterContentChecked() {
        this.cdr.detectChanges();
        // call or add here your code
    }
    ionViewWillEnter() {
        this.global.Cimage.subscribe(res => {
            this.data = res;
            this.image = this.data[0].image;
            this.name = this.data[0].mc_name;
        });
        this.global.Menusub.subscribe(res => {
            this.menu = res;
            this.price = this.menu[0].m_price;
            this.default = this.menu[0].m_id;
        });
        if (this.discount != 100) {
            this.orig = this.price;
            this.dis = "none";
        }
        this.global.Cart.subscribe(res => {
            this.check = res;
        });
    }
    ngOnInit() {
        this.global.Cimage.subscribe(res => {
            this.data = res;
            this.image = this.data[0].image;
            this.name = this.data[0].mc_name;
        });
        this.global.Menusub.subscribe(res => {
            this.menu = res;
            this.price = this.menu[0].m_price;
            this.default = this.menu[0].m_id;
        });
        if (this.discount != 100) {
            this.orig = this.price;
            this.dis = "none";
        }
        this.global.Cart.subscribe(res => {
            this.check = res;
        });
    }
    function(quantity, num) {
        if (num == 1) {
            if (this.number != 1) {
                this.number--;
            }
            quantity = this.quanttity;
        }
        else if (num == 2) {
            if (this.number != 10) {
                this.number++;
            }
            quantity = this.quanttity;
        }
        this.quanttity = quantity;
        for (let index = 0; index < this.menu.length; index++) {
            if (quantity == this.menu[index].m_id) {
                this.save = this.menu[index].m_price;
                // if (this.discount != 100) {
                //   this.calculate = this.price;
                //   this.orignal = this.price;
                //   this.calculate = (this.calculate / 100) * this.discount;
                //   this.price = this.price - this.calculate;
                //   this.orig=this.price;
                // }
                this.price = this.number * this.save;
            }
        }
    }
    order() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            this.addtocart.m_id = this.quanttity;
            this.temp = this.menu.filter(data => data.m_id == this.addtocart.m_id);
            this.addtocart.item_name = this.temp[0].m_name;
            this.addtocart.quantity = this.number;
            this.addtocart.price = this.save;
            this.addtocart.image = this.image;
            if (this.check.length == 0) {
                this.cart.push(this.addtocart);
                this.global.set_Cart(this.cart);
                console.log(this.cart, "First");
            }
            else {
                this.cart = this.check;
                this.cart.push(this.addtocart);
                this.global.set_Cart(this.cart);
                console.log(this.cart, "Remaining");
            }
            const toast = yield this.toast.create({
                message: 'Added to Cart',
                duration: 2000,
                buttons: [
                    {
                        side: 'end',
                        icon: 'cart',
                        text: 'View Cart',
                        handler: () => {
                        }
                    },
                ]
            });
            toast.present();
            this.addtocart = {};
        });
    }
};
OrdersubPage.ctorParameters = () => [
    { type: _angular_core__WEBPACK_IMPORTED_MODULE_5__.ChangeDetectorRef },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ToastController },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService }
];
OrdersubPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-ordersub',
        template: _raw_loader_ordersub_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_ordersub_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], OrdersubPage);



/***/ }),

/***/ 56272:
/*!*********************************************!*\
  !*** ./src/app/ordersub/ordersub.page.scss ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".image {\n  justify-content: center;\n  border-bottom-right-radius: 10px;\n  border-bottom-left-radius: 10px;\n  background-color: var(--ion-color-dark);\n  box-shadow: 0px 2px 10px 2px #646363;\n}\n.image img {\n  height: 15rem;\n}\n.icon {\n  zoom: 1.5;\n  margin-right: 5px;\n}\n.tittle {\n  margin-left: 1rem;\n  margin-bottom: 0;\n}\n.tittle h1 {\n  margin-top: 0;\n  font-family: times-new-roman;\n}\n.title {\n  margin-left: 1rem;\n  margin-bottom: 0;\n}\n.title h1 {\n  font-family: times-new-roman;\n  color: #1ad839;\n  font-size: 3rem;\n  margin-bottom: 0;\n}\n.title .discount {\n  margin-top: 0;\n  font-family: times-new-roman;\n}\n.title .orignal {\n  margin-top: 2px;\n  font-family: times-new-roman;\n  opacity: 0.5;\n}\n.description {\n  margin-left: 1rem;\n  margin-right: 1rem;\n}\n.description h3 {\n  font-family: times-new-roman;\n}\n.description pre {\n  margin-top: 0;\n  white-space: pre-wrap;\n  font-family: times-new-roman;\n  width: 100%;\n}\n.quantity {\n  justify-content: center;\n}\n.quantity .minus {\n  float: left;\n  background-color: var(--ion-color-dark);\n  height: 2.8rem;\n  width: 2.8rem;\n  border-top-left-radius: 5px;\n  border-bottom-left-radius: 5px;\n}\n.quantity .minus ion-icon {\n  color: var(--ion-color-light);\n  padding: 0.9rem;\n}\n.quantity .input {\n  border: 1px solid var(--ion-color-dark);\n  float: left;\n  width: 60%;\n  text-align: center;\n  justify-content: center;\n}\n.quantity .input h3 {\n  margin: 6px 0 0 0;\n}\n.quantity .plus {\n  float: right;\n  background-color: var(--ion-color-dark);\n  height: 2.8rem;\n  width: 2.8rem;\n  border-top-right-radius: 5px;\n  border-bottom-right-radius: 5px;\n}\n.quantity .plus ion-icon {\n  color: var(--ion-color-light);\n  padding: 0.9rem;\n}\n.weight {\n  justify-content: center;\n}\n.weight ion-label {\n  margin-top: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm9yZGVyc3ViLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLHVCQUFBO0VBQ0EsZ0NBQUE7RUFDQSwrQkFBQTtFQUNBLHVDQUFBO0VBQ0Esb0NBQUE7QUFDSjtBQUFJO0VBQ0ksYUFBQTtBQUVSO0FBQ0E7RUFDSSxTQUFBO0VBQ0EsaUJBQUE7QUFFSjtBQUFBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtBQUdKO0FBRkk7RUFDSSxhQUFBO0VBQ0EsNEJBQUE7QUFJUjtBQURBO0VBQ0ksaUJBQUE7RUFDQSxnQkFBQTtBQUlKO0FBSEk7RUFDSSw0QkFBQTtFQUNBLGNBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QUFLUjtBQUhJO0VBQ0ksYUFBQTtFQUNBLDRCQUFBO0FBS1I7QUFISTtFQUNJLGVBQUE7RUFDQSw0QkFBQTtFQUNBLFlBQUE7QUFLUjtBQUZBO0VBQ0ksaUJBQUE7RUFDQSxrQkFBQTtBQUtKO0FBSkk7RUFDSSw0QkFBQTtBQU1SO0FBSkk7RUFDSSxhQUFBO0VBQ0EscUJBQUE7RUFDQSw0QkFBQTtFQUNBLFdBQUE7QUFNUjtBQUhBO0VBQ0ksdUJBQUE7QUFNSjtBQUxJO0VBQ0ksV0FBQTtFQUNBLHVDQUFBO0VBQ0EsY0FBQTtFQUNBLGFBQUE7RUFDQSwyQkFBQTtFQUNBLDhCQUFBO0FBT1I7QUFOUTtFQUNJLDZCQUFBO0VBQ0EsZUFBQTtBQVFaO0FBTEk7RUFDSSx1Q0FBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtBQU9SO0FBTlE7RUFDSSxpQkFBQTtBQVFaO0FBTEk7RUFDSSxZQUFBO0VBQ0EsdUNBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLDRCQUFBO0VBQ0EsK0JBQUE7QUFPUjtBQU5RO0VBQ0ksNkJBQUE7RUFDQSxlQUFBO0FBUVo7QUFKQTtFQUNJLHVCQUFBO0FBT0o7QUFOSTtFQUNJLGdCQUFBO0FBUVIiLCJmaWxlIjoib3JkZXJzdWIucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmltYWdle1xyXG4gICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICBib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czogMTBweDtcclxuICAgIGJvcmRlci1ib3R0b20tbGVmdC1yYWRpdXM6IDEwcHg7XHJcbiAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICBib3gtc2hhZG93OiAwcHggMnB4IDEwcHggMnB4IHJnYigxMDAsIDk5LCA5OSk7XHJcbiAgICBpbWd7XHJcbiAgICAgICAgaGVpZ2h0OiAxNXJlbTtcclxuICAgIH1cclxufVxyXG4uaWNvbntcclxuICAgIHpvb206IDEuNTtcclxuICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gIH1cclxuLnRpdHRsZXtcclxuICAgIG1hcmdpbi1sZWZ0OiAxcmVtO1xyXG4gICAgbWFyZ2luLWJvdHRvbTogMDtcclxuICAgIGgxe1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IHRpbWVzLW5ldy1yb21hbjtcclxuICAgIH1cclxufVxyXG4udGl0bGV7XHJcbiAgICBtYXJnaW4tbGVmdDogMXJlbTtcclxuICAgIG1hcmdpbi1ib3R0b206IDA7XHJcbiAgICBoMXtcclxuICAgICAgICBmb250LWZhbWlseTogdGltZXMtbmV3LXJvbWFuO1xyXG4gICAgICAgIGNvbG9yOiByZ2IoMjYsIDIxNiwgNTcpO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogM3JlbTtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAwO1xyXG4gICAgfVxyXG4gICAgLmRpc2NvdW50e1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDA7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IHRpbWVzLW5ldy1yb21hbjtcclxuICAgIH1cclxuICAgIC5vcmlnbmFse1xyXG4gICAgICAgIG1hcmdpbi10b3A6IDJweDtcclxuICAgICAgICBmb250LWZhbWlseTogdGltZXMtbmV3LXJvbWFuO1xyXG4gICAgICAgIG9wYWNpdHk6IDAuNTtcclxuICAgIH1cclxufVxyXG4uZGVzY3JpcHRpb257XHJcbiAgICBtYXJnaW4tbGVmdDogMXJlbTtcclxuICAgIG1hcmdpbi1yaWdodDogMXJlbTtcclxuICAgIGgze1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiB0aW1lcy1uZXctcm9tYW47XHJcbiAgICB9XHJcbiAgICBwcmV7XHJcbiAgICAgICAgbWFyZ2luLXRvcDogMDtcclxuICAgICAgICB3aGl0ZS1zcGFjZTogcHJlLXdyYXA7ICBcclxuICAgICAgICBmb250LWZhbWlseTogdGltZXMtbmV3LXJvbWFuO1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgfVxyXG59XHJcbi5xdWFudGl0eXtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgLm1pbnVze1xyXG4gICAgICAgIGZsb2F0OmxlZnQ7IFxyXG4gICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgICAgICBoZWlnaHQ6IDIuOHJlbTtcclxuICAgICAgICB3aWR0aDogMi44cmVtO1xyXG4gICAgICAgIGJvcmRlci10b3AtbGVmdC1yYWRpdXM6IDVweDtcclxuICAgICAgICBib3JkZXItYm90dG9tLWxlZnQtcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLjlyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG4gICAgLmlucHV0e1xyXG4gICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgICAgICBmbG9hdDpsZWZ0O1xyXG4gICAgICAgIHdpZHRoOiA2MCU7XHJcbiAgICAgICAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgIGgze1xyXG4gICAgICAgICAgICBtYXJnaW46IDZweCAwIDAgMDtcclxuICAgICAgICB9XHJcbiAgICB9XHJcbiAgICAucGx1c3tcclxuICAgICAgICBmbG9hdDpyaWdodDtcclxuICAgICAgICBiYWNrZ3JvdW5kLWNvbG9yOiB2YXIoLS1pb24tY29sb3ItZGFyayk7XHJcbiAgICAgICAgaGVpZ2h0OiAyLjhyZW07XHJcbiAgICAgICAgd2lkdGg6IDIuOHJlbTtcclxuICAgICAgICBib3JkZXItdG9wLXJpZ2h0LXJhZGl1czogNXB4O1xyXG4gICAgICAgIGJvcmRlci1ib3R0b20tcmlnaHQtcmFkaXVzOiA1cHg7XHJcbiAgICAgICAgaW9uLWljb257XHJcbiAgICAgICAgICAgIGNvbG9yOiB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLjlyZW07XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbi53ZWlnaHR7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGlvbi1sYWJlbHtcclxuICAgICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgfVxyXG5cclxuXHJcbn0iXX0= */");

/***/ }),

/***/ 41778:
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/ordersub/ordersub.page.html ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ name }}</ion-title>\n    <ion-icon slot=\"end\" class=\"icon        \" routerLink=\"/cart\" name=\"cart\"></ion-icon>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-row class=\"image\"><img src={{image}}></ion-row>\n  <ion-row class=\"title\">\n    <h1><b>Rs{{price}}</b></h1>\n  </ion-row>\n  <ion-row [style.display]=\"dis\" class=\"title\">\n    <H3 class=\"orignal\"><s>${{orignal}}</s></H3>\n    <H3 class=\"discount\">-{{discount}}%</H3>\n  </ion-row>\n  <ion-row class=\"tittle\">\n    <h1>{{name}}</h1>\n  </ion-row>\n  <ion-row class=\"weight\">\n    <ion-label>Select Type</ion-label>\n    <ion-select placeholder=\"Select One\" name=\"menu\" type=\"submit\" [(ngModel)]=\"quantity\"\n      (ionChange)=\"function(quantity,0)\" interface=\"action-sheet\" value=\"{{default}}\">\n      <ion-select-option *ngFor=\"let grid of menu\" value={{grid.m_id}}>{{grid.m_name}}</ion-select-option>\n    </ion-select>\n\n  </ion-row>\n  <ion-row class=\"quantity\">\n    <div class=\"minus\" (click)=\"function(0,1)\">\n      <ion-icon name=\"remove-outline\"></ion-icon>\n    </div>\n    <div class=\"input\">\n      <h3>{{number}}</h3>\n    </div>\n    <div class=\"plus\" (click)=\"function(0,2)\">\n      <ion-icon name=\"add-outline\"></ion-icon>\n    </div>\n  </ion-row>\n  <ion-button expand=\"block\" (click)=\"order()\" color=\"dark\"\n    style=\"margin-left: 2rem; margin-right: 2rem; height: 3rem;\">\n    <ion-icon name=\"cart-outline\"></ion-icon>\n    Add to Cart\n  </ion-button>\n  <!--   \n  <ion-row class=\"description\">\n    <h3>Description :</h3>\n    <pre>{{description}}</pre>\n  </ion-row> -->\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_ordersub_ordersub_module_ts-es2015.js.map