(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_folder_folder_module_ts"], {
    /***/
    59771:
    /*!*************************************************!*\
      !*** ./src/app/folder/folder-routing.module.ts ***!
      \*************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FolderPageRoutingModule": function FolderPageRoutingModule() {
          return (
            /* binding */
            _FolderPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _folder_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./folder.page */
      48470);

      var routes = [{
        path: '',
        component: _folder_page__WEBPACK_IMPORTED_MODULE_0__.FolderPage
      }];

      var _FolderPageRoutingModule = function FolderPageRoutingModule() {
        _classCallCheck(this, FolderPageRoutingModule);
      };

      _FolderPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _FolderPageRoutingModule);
      /***/
    },

    /***/
    3412:
    /*!*****************************************!*\
      !*** ./src/app/folder/folder.module.ts ***!
      \*****************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FolderPageModule": function FolderPageModule() {
          return (
            /* binding */
            _FolderPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _folder_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./folder-routing.module */
      59771);
      /* harmony import */


      var _folder_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./folder.page */
      48470);

      var _FolderPageModule = function FolderPageModule() {
        _classCallCheck(this, FolderPageModule);
      };

      _FolderPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _folder_routing_module__WEBPACK_IMPORTED_MODULE_0__.FolderPageRoutingModule],
        declarations: [_folder_page__WEBPACK_IMPORTED_MODULE_1__.FolderPage]
      })], _FolderPageModule);
      /***/
    },

    /***/
    48470:
    /*!***************************************!*\
      !*** ./src/app/folder/folder.page.ts ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "FolderPage": function FolderPage() {
          return (
            /* binding */
            _FolderPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_folder_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./folder.page.html */
      7154);
      /* harmony import */


      var _folder_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./folder.page.scss */
      77065);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../provider/apicall.service */
      10119);

      var _FolderPage = /*#__PURE__*/function () {
        function FolderPage(menu, apicall) {
          _classCallCheck(this, FolderPage);

          this.menu = menu;
          this.apicall = apicall;
          this.signin = {
            username: "",
            password: "",
            role: ""
          };
        }

        _createClass(FolderPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.folder = "Café Verona";
            this.menu.enable(false);
          }
        }, {
          key: "login",
          value: function login() {
            console.log(this.signin);
            this.apicall.api_login(this.signin);
          }
        }]);

        return FolderPage;
      }();

      _FolderPage.ctorParameters = function () {
        return [{
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__.MenuController
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService
        }];
      };

      _FolderPage = (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_5__.Component)({
        selector: 'app-folder',
        template: _raw_loader_folder_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_folder_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _FolderPage);
      /***/
    },

    /***/
    77065:
    /*!*****************************************!*\
      !*** ./src/app/folder/folder.page.scss ***!
      \*****************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-content .upper {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  height: 90%;\n}\nion-content .upper .center {\n  background-color: rgba(0, 0, 0, 0.4);\n  width: 90%;\n  height: 21rem;\n  border-radius: 20px;\n}\nion-content .upper .center .img {\n  margin-top: 1rem;\n  justify-content: center;\n  margin-bottom: 1rem;\n  margin-top: 1rem;\n}\nion-content .upper .center .fields {\n  justify-content: center;\n  margin: 1rem;\n}\nion-content .upper .center .fields ion-input {\n  border: none;\n  border-bottom: 1px solid #929191;\n  padding: 0.5rem 1rem;\n}\nion-content .upper .center ion-button {\n  margin-left: 1rem;\n  margin-right: 1rem;\n  height: 3.3rem;\n}\nion-content .upper .center .radio {\n  margin-left: 1rem;\n  margin-right: 1rem;\n  border-bottom: 1px solid #929191;\n}\nion-content .upper .center .radio ion-item {\n  --background:rgb(0, 0, 0,0);\n}\nion-content .upper .center .radio ion-item ion-label {\n  color: #b9b7b7;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZvbGRlci5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0U7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSx1QkFBQTtFQUNBLFdBQUE7QUFBSjtBQUNJO0VBQ0Usb0NBQUE7RUFDQSxVQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0FBQ047QUFBTTtFQUNFLGdCQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLGdCQUFBO0FBRVI7QUFBTTtFQUNFLHVCQUFBO0VBQ0EsWUFBQTtBQUVSO0FBRFE7RUFDRSxZQUFBO0VBQ0YsZ0NBQUE7RUFDQSxvQkFBQTtBQUdSO0FBQU07RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsY0FBQTtBQUVSO0FBQU07RUFDRSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0NBQUE7QUFFUjtBQURRO0VBQ0UsMkJBQUE7QUFHVjtBQUZVO0VBQ0UsY0FBQTtBQUlaIiwiZmlsZSI6ImZvbGRlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY29udGVudHtcbiAgLnVwcGVye1xuICAgIGRpc3BsYXk6IGZsZXg7XG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICBoZWlnaHQ6IDkwJTtcbiAgICAuY2VudGVye1xuICAgICAgYmFja2dyb3VuZC1jb2xvcjpyZ2IoMCwgMCwgMCwwLjQpO1xuICAgICAgd2lkdGg6IDkwJTtcbiAgICAgIGhlaWdodDogMjFyZW07XG4gICAgICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICAgICAgLmltZ3tcbiAgICAgICAgbWFyZ2luLXRvcDogMXJlbTtcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gICAgICAgIG1hcmdpbi1ib3R0b206IDFyZW07XG4gICAgICAgIG1hcmdpbi10b3A6IDFyZW07XG4gICAgICB9XG4gICAgICAuZmllbGRze1xuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgICAgICAgbWFyZ2luOiAxcmVtO1xuICAgICAgICBpb24taW5wdXR7XG4gICAgICAgICAgYm9yZGVyOm5vbmU7XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjOTI5MTkxO1xuICAgICAgICBwYWRkaW5nOiAwLjVyZW0gMXJlbTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaW9uLWJ1dHRvbntcbiAgICAgICAgbWFyZ2luLWxlZnQ6IDFyZW07XG4gICAgICAgIG1hcmdpbi1yaWdodDogMXJlbTtcbiAgICAgICAgaGVpZ2h0OiAzLjNyZW07XG4gICAgICB9XG4gICAgICAucmFkaW97XG4gICAgICAgIG1hcmdpbi1sZWZ0OiAxcmVtO1xuICAgICAgICBtYXJnaW4tcmlnaHQ6IDFyZW07XG4gICAgICAgIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjOTI5MTkxO1xuICAgICAgICBpb24taXRlbXtcbiAgICAgICAgICAtLWJhY2tncm91bmQ6cmdiKDAsIDAsIDAsMCk7XG4gICAgICAgICAgaW9uLWxhYmVse1xuICAgICAgICAgICAgY29sb3I6cmdiKDE4NSwgMTgzLCAxODMpXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuICB9XG59Il19 */";
      /***/
    },

    /***/
    7154:
    /*!*******************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/folder/folder.page.html ***!
      \*******************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"medium\">\n  <ion-row class=\"upper\">\n    <div class=\"center\">\n      <ion-row class=\"img\">\n        <ion-avatar>\n          <img src=\"../../assets/icon/favicon.png\">\n        </ion-avatar>\n\n      </ion-row>\n      <form #form=\"ngForm\" (ngSubmit)=\"login(form)\">\n      <ion-row class=\"fields\">\n        <ion-input name=\"name\"  type=\"text\" placeholder=\"User Name\" [(ngModel)]=\"signin.username\"></ion-input>\n      </ion-row>\n      <ion-row class=\"fields\">\n        <ion-input name=\"password\" type=\"password\" placeholder=\"Password\"  [(ngModel)]=\"signin.password\"></ion-input>\n      </ion-row>\n        <ion-radio-group name=\"role\" [(ngModel)]=\"signin.role\" >\n          <ion-row class=\"radio\">\n            <ion-col>\n              <ion-item lines=\"none\">\n                <ion-label>Admin</ion-label>\n                <ion-radio slot=\"start\" color=\"success\" value=\"admin\"></ion-radio>\n              </ion-item>\n            </ion-col>\n            <ion-col>\n              <ion-item lines=\"none\">\n                <ion-label>Staff</ion-label>\n              <ion-radio slot=\"start\" value=\"staff\"></ion-radio>\n              </ion-item>\n            </ion-col>\n          </ion-row>\n        </ion-radio-group>\n      <ion-button expand=\"block\" color=\"dark\" type=\"submit\"  [disabled]=\"form.invalid || signin.role==''\">Login</ion-button>\n    </form>\n    </div>\n  </ion-row>\n</ion-content>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_folder_folder_module_ts-es5.js.map