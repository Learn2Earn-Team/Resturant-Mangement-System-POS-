(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_cat_cat_module_ts"],{

/***/ 94695:
/*!*******************************************!*\
  !*** ./src/app/cat/cat-routing.module.ts ***!
  \*******************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CatPageRoutingModule": function() { return /* binding */ CatPageRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _cat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cat.page */ 63545);




const routes = [
    {
        path: '',
        component: _cat_page__WEBPACK_IMPORTED_MODULE_0__.CatPage
    }
];
let CatPageRoutingModule = class CatPageRoutingModule {
};
CatPageRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule],
    })
], CatPageRoutingModule);



/***/ }),

/***/ 19944:
/*!***********************************!*\
  !*** ./src/app/cat/cat.module.ts ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CatPageModule": function() { return /* binding */ CatPageModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common */ 38583);
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/forms */ 3679);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _cat_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./cat-routing.module */ 94695);
/* harmony import */ var _cat_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cat.page */ 63545);







let CatPageModule = class CatPageModule {
};
CatPageModule = (0,tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule,
            _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule,
            _cat_routing_module__WEBPACK_IMPORTED_MODULE_0__.CatPageRoutingModule
        ],
        declarations: [_cat_page__WEBPACK_IMPORTED_MODULE_1__.CatPage]
    })
], CatPageModule);



/***/ }),

/***/ 63545:
/*!*********************************!*\
  !*** ./src/app/cat/cat.page.ts ***!
  \*********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "CatPage": function() { return /* binding */ CatPage; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_cat_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./cat.page.html */ 31131);
/* harmony import */ var _cat_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cat.page.scss */ 59300);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../provider/apicall.service */ 10119);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../provider/global.service */ 82836);







let CatPage = class CatPage {
    constructor(actionSheetController, alert, menu, apicall, global) {
        this.actionSheetController = actionSheetController;
        this.alert = alert;
        this.menu = menu;
        this.apicall = apicall;
        this.global = global;
        this.add = { name: "" };
        this.editt = { id: "", name: "" };
    }
    ngOnInit() {
        this.folder = "Café Verona";
        this.menu.enable(true);
        this.apicall.api_getallproducts();
        this.global.Products.subscribe(res => {
            this.products = res;
            console.log(res);
        });
    }
    getsub(id, name) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: 'Manage',
                cssClass: 'my-custom-class',
                buttons: [
                    {
                        text: 'View Details',
                        icon: 'eye-outline',
                        handler: () => {
                            this.apicall.getsub(id);
                            this.global.set_Catid(id);
                        }
                    }, {
                        text: 'Edit Item',
                        icon: 'pencil-outline',
                        handler: () => {
                            this.edit(id, name);
                        }
                    }, {
                        text: 'Cancel',
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                        }
                    }
                ]
            });
            yield actionSheet.present();
        });
    }
    addnew() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Café Verona',
                mode: 'ios',
                subHeader: 'Add New Categeory',
                inputs: [
                    {
                        name: 'name',
                        type: 'text',
                        placeholder: 'Item Name'
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                    }, {
                        text: 'Add',
                        handler: (alertData) => {
                            this.add.name = alertData.name;
                            this.apicall.addcat(this.add);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    edit(id, name) {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, function* () {
            const alert = yield this.alert.create({
                cssClass: 'my-custom-class',
                header: 'Café Verona',
                mode: 'ios',
                subHeader: 'Edit Item',
                inputs: [
                    {
                        name: 'name',
                        type: 'text',
                        placeholder: name
                    }
                ],
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                    }, {
                        text: 'Update',
                        handler: (alertData) => {
                            console.log("edit");
                            this.editt.id = id;
                            this.editt.name = alertData.name;
                            this.apicall.editcat(this.editt);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
};
CatPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.ActionSheetController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.AlertController },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__.MenuController },
    { type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService }
];
CatPage = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_6__.Component)({
        selector: 'app-cat',
        template: _raw_loader_cat_page_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_cat_page_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], CatPage);



/***/ }),

/***/ 59300:
/*!***********************************!*\
  !*** ./src/app/cat/cat.page.scss ***!
  \***********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content ion-row {\n  justify-content: center;\n}\nion-content ion-row ion-col {\n  background-color: var(--ion-color-dark);\n  box-shadow: 0px 2px 8px -1px #050505;\n  text-align: center;\n  min-width: 7rem;\n  max-width: 7rem;\n  min-height: 7rem;\n  margin: 3px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: 10px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNhdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0k7RUFDSSx1QkFBQTtBQUFSO0FBQ1E7RUFDSSx1Q0FBQTtFQUNBLG9DQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsZUFBQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUFDWiIsImZpbGUiOiJjYXQucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLWNvbnRlbnQge1xyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6IHZhcigtLWlvbi1jb2xvci1kYXJrKTtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogMHB4IDJweCA4cHggLTFweCAjMDUwNTA1O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIG1pbi13aWR0aDogN3JlbTtcclxuICAgICAgICAgICAgbWF4LXdpZHRoOiA3cmVtO1xyXG4gICAgICAgICAgICBtaW4taGVpZ2h0OiA3cmVtO1xyXG4gICAgICAgICAgICBtYXJnaW46IDNweDtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59XHJcbiJdfQ== */");

/***/ }),

/***/ 31131:
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cat/cat.page.html ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-menu-button></ion-menu-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content color=\"medium\">\n  <ion-grid color=\"dark\">\n    <ion-row>\n      <ion-col *ngFor=\"let grid of products\" (click)=\"getsub(grid.ic_id,grid.ic_name)\" color=\"dark\">\n        {{grid.ic_name}}\n      </ion-col>\n    </ion-row>\n  </ion-grid>\n\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"addnew()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>");

/***/ })

}]);
//# sourceMappingURL=src_app_cat_cat_module_ts-es2015.js.map