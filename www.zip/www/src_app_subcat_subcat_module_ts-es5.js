(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["src_app_subcat_subcat_module_ts"], {
    /***/
    1695:
    /*!*************************************************!*\
      !*** ./src/app/subcat/subcat-routing.module.ts ***!
      \*************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SubcatPageRoutingModule": function SubcatPageRoutingModule() {
          return (
            /* binding */
            _SubcatPageRoutingModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _subcat_page__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./subcat.page */
      75708);

      var routes = [{
        path: '',
        component: _subcat_page__WEBPACK_IMPORTED_MODULE_0__.SubcatPage
      }];

      var _SubcatPageRoutingModule = function SubcatPageRoutingModule() {
        _classCallCheck(this, SubcatPageRoutingModule);
      };

      _SubcatPageRoutingModule = (0, tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_2__.NgModule)({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule.forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_3__.RouterModule]
      })], _SubcatPageRoutingModule);
      /***/
    },

    /***/
    339:
    /*!*****************************************!*\
      !*** ./src/app/subcat/subcat.module.ts ***!
      \*****************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SubcatPageModule": function SubcatPageModule() {
          return (
            /* binding */
            _SubcatPageModule
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/common */
      38583);
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/forms */
      3679);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _subcat_routing_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! ./subcat-routing.module */
      1695);
      /* harmony import */


      var _subcat_page__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./subcat.page */
      75708);

      var _SubcatPageModule = function SubcatPageModule() {
        _classCallCheck(this, SubcatPageModule);
      };

      _SubcatPageModule = (0, tslib__WEBPACK_IMPORTED_MODULE_2__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_3__.NgModule)({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_4__.CommonModule, _angular_forms__WEBPACK_IMPORTED_MODULE_5__.FormsModule, _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.IonicModule, _subcat_routing_module__WEBPACK_IMPORTED_MODULE_0__.SubcatPageRoutingModule],
        declarations: [_subcat_page__WEBPACK_IMPORTED_MODULE_1__.SubcatPage]
      })], _SubcatPageModule);
      /***/
    },

    /***/
    75708:
    /*!***************************************!*\
      !*** ./src/app/subcat/subcat.page.ts ***!
      \***************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export */


      __webpack_require__.d(__webpack_exports__, {
        /* harmony export */
        "SubcatPage": function SubcatPage() {
          return (
            /* binding */
            _SubcatPage
          );
        }
        /* harmony export */

      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! tslib */
      64762);
      /* harmony import */


      var _raw_loader_subcat_page_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! !raw-loader!./subcat.page.html */
      5470);
      /* harmony import */


      var _subcat_page_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! ./subcat.page.scss */
      47024);
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/core */
      37716);
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      39895);
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic/angular */
      80476);
      /* harmony import */


      var _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../provider/apicall.service */
      10119);
      /* harmony import */


      var _provider_global_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ../provider/global.service */
      82836);

      var _SubcatPage = /*#__PURE__*/function () {
        function SubcatPage(route, actionSheetController, alert, global, apicall) {
          _classCallCheck(this, SubcatPage);

          this.route = route;
          this.actionSheetController = actionSheetController;
          this.alert = alert;
          this.global = global;
          this.apicall = apicall;
          this.add = {
            id: "",
            name: "",
            min_quantity: ""
          };
          this.del = {
            id: ""
          };
          this.editdata = {
            id: null,
            name: null,
            callid: null,
            min_quantity: null
          };
        }

        _createClass(SubcatPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.folder = "Café Verona";
            this.global.Subcat.subscribe(function (res) {
              _this.subcat = res;
              console.log(res);
            });
            this.global.Catid.subscribe(function (res) {
              _this.id = res;
              console.log(res);
            });
          }
        }, {
          key: "addnew",
          value: function addnew() {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this2 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alert.create({
                        cssClass: 'my-custom-class',
                        header: 'Café Verona',
                        mode: 'ios',
                        subHeader: 'Add New Item',
                        inputs: [{
                          name: 'name',
                          type: 'text',
                          placeholder: "Name"
                        }, {
                          name: 'min',
                          type: 'number',
                          placeholder: "Minimum Quantity"
                        }],
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel'
                        }, {
                          text: 'Okay',
                          handler: function handler(alertData) {
                            _this2.add.name = alertData.name;
                            _this2.add.min_quantity = alertData.min;
                            _this2.add.id = _this2.id;
                            console.log(_this2.add);

                            _this2.apicall.addsub(_this2.add);
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "sheet",
          value: function sheet(id, name, cid, min) {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this3 = this;

              var actionSheet;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.actionSheetController.create({
                        header: 'Manage',
                        cssClass: 'my-custom-class',
                        buttons: [{
                          text: 'Add Purchase',
                          icon: 'add-outline',
                          handler: function handler() {
                            _this3.global.set_Selected(id);

                            _this3.route.navigate(['/add']);
                          }
                        }, {
                          text: 'Edit Item',
                          icon: 'pencil-outline',
                          handler: function handler() {
                            _this3.edit(id, name, min);
                          }
                        }, {
                          text: 'Cancel',
                          icon: 'close',
                          role: 'cancel',
                          handler: function handler() {}
                        }]
                      });

                    case 2:
                      actionSheet = _context2.sent;
                      _context2.next = 5;
                      return actionSheet.present();

                    case 5:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "edit",
          value: function edit(id, name, min) {
            return (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__awaiter)(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              var _this4 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.alert.create({
                        cssClass: 'my-custom-class',
                        header: 'Café Verona',
                        mode: 'ios',
                        subHeader: 'Edit Item',
                        inputs: [{
                          name: 'name',
                          type: 'text',
                          placeholder: name
                        }, {
                          name: 'min',
                          type: 'number',
                          placeholder: min
                        }],
                        buttons: [{
                          text: 'Cancel',
                          role: 'cancel'
                        }, {
                          text: 'Update',
                          handler: function handler(alertData) {
                            _this4.editdata.name = alertData.name;
                            _this4.editdata.min_quantity = alertData.min;
                            _this4.editdata.id = id;
                            _this4.editdata.callid = _this4.id;

                            _this4.apicall.editsubcat(_this4.editdata);
                          }
                        }]
                      });

                    case 2:
                      alert = _context3.sent;
                      _context3.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          }
        }]);

        return SubcatPage;
      }();

      _SubcatPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__.Router
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.ActionSheetController
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.AlertController
        }, {
          type: _provider_global_service__WEBPACK_IMPORTED_MODULE_3__.GlobalService
        }, {
          type: _provider_apicall_service__WEBPACK_IMPORTED_MODULE_2__.ApicallService
        }];
      };

      _SubcatPage = (0, tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([(0, _angular_core__WEBPACK_IMPORTED_MODULE_7__.Component)({
        selector: 'app-subcat',
        template: _raw_loader_subcat_page_html__WEBPACK_IMPORTED_MODULE_0__["default"],
        styles: [_subcat_page_scss__WEBPACK_IMPORTED_MODULE_1__["default"]]
      })], _SubcatPage);
      /***/
    },

    /***/
    47024:
    /*!*****************************************!*\
      !*** ./src/app/subcat/subcat.page.scss ***!
      \*****************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-row {\n  width: 100%;\n  justify-content: center;\n}\nion-row ion-button {\n  margin: 10px;\n  width: 100%;\n  --background-color: rgb(0, 0, 0, 0.5);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInN1YmNhdC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxXQUFBO0VBQ0EsdUJBQUE7QUFDSjtBQUFJO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxxQ0FBQTtBQUVSIiwiZmlsZSI6InN1YmNhdC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tcm93e1xyXG4gICAgd2lkdGg6IDEwMCU7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGlvbi1idXR0b257XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIC0tYmFja2dyb3VuZC1jb2xvcjogcmdiKDAsIDAsIDAsIDAuNSk7XHJcbiAgICB9XHJcbn0iXX0= */";
      /***/
    },

    /***/
    5470:
    /*!*******************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/subcat/subcat.page.html ***!
      \*******************************************************************************/

    /***/
    function _(__unused_webpack_module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header [translucent]=\"true\">\n  <ion-toolbar color=\"dark\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <ion-title>{{ folder }}</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content color=\"medium\">\n  <ion-row *ngFor=\"let a of subcat\">\n    <ion-button expand=\"block\" color=\"dark\" (click)=\"sheet(a.isc_id,a.is_name,a.ic_id,a.min_quantity)\">{{a.is_name}}</ion-button>\n  </ion-row>\n  <ion-fab horizontal=\"end\" vertical=\"bottom\" slot=\"fixed\">\n    <ion-fab-button color=\"dark\" (click)=\"addnew()\">\n      <ion-icon name=\"add\"></ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>";
      /***/
    }
  }]);
})();
//# sourceMappingURL=src_app_subcat_subcat_module_ts-es5.js.map