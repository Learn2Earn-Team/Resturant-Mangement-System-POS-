(self["webpackChunkverona"] = self["webpackChunkverona"] || []).push([["main"],{

/***/ 98255:
/*!*******************************************************!*\
  !*** ./$_lazy_route_resources/ lazy namespace object ***!
  \*******************************************************/
/***/ (function(module) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = 98255;
module.exports = webpackEmptyAsyncContext;

/***/ }),

/***/ 90158:
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRoutingModule": function() { return /* binding */ AppRoutingModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ 39895);



const routes = [
    {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
    },
    {
        path: 'home',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_folder_folder_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./folder/folder.module */ 3412)).then(m => m.FolderPageModule)
    },
    {
        path: 'items',
        loadChildren: () => __webpack_require__.e(/*! import() */ "src_app_items_items_module_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./items/items.module */ 92029)).then(m => m.ItemsPageModule)
    },
    {
        path: 'cat',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_cat_cat_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./cat/cat.module */ 19944)).then(m => m.CatPageModule)
    },
    {
        path: 'add',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_add_add_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./add/add.module */ 9454)).then(m => m.AddPageModule)
    },
    {
        path: 'stock',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_stock_stock_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stock/stock.module */ 92718)).then(m => m.StockPageModule)
    },
    {
        path: 'menu',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_menu_menu_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./menu/menu.module */ 32825)).then(m => m.MenuPageModule)
    },
    {
        path: 'menuitem',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_menuitem_menuitem_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./menuitem/menuitem.module */ 16825)).then(m => m.MenuitemPageModule)
    },
    {
        path: 'order',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_order_order_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./order/order.module */ 78865)).then(m => m.OrderPageModule)
    },
    {
        path: 'subcat',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_subcat_subcat_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./subcat/subcat.module */ 339)).then(m => m.SubcatPageModule)
    },
    {
        path: 'addcat',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_addcat_addcat_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./addcat/addcat.module */ 36627)).then(m => m.AddcatPageModule)
    },
    {
        path: 'addsub',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_addsub_addsub_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./addsub/addsub.module */ 91850)).then(m => m.AddsubPageModule)
    },
    {
        path: 'stockdetail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_stockdetail_stockdetail_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./stockdetail/stockdetail.module */ 50194)).then(m => m.StockdetailPageModule)
    },
    {
        path: 'ordercat',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_ordercat_ordercat_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./ordercat/ordercat.module */ 85546)).then(m => m.OrdercatPageModule)
    },
    {
        path: 'ordersub',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_ordersub_ordersub_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./ordersub/ordersub.module */ 9280)).then(m => m.OrdersubPageModule)
    },
    {
        path: 'cart',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_cart_cart_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./cart/cart.module */ 12943)).then(m => m.CartPageModule)
    },
    {
        path: 'transactions',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_transactions_transactions_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./transactions/transactions.module */ 65528)).then(m => m.TransactionsPageModule)
    },
    {
        path: 'detail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_detail_detail_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./detail/detail.module */ 9251)).then(m => m.DetailPageModule)
    },
    {
        path: 'showdetail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_showdetail_showdetail_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./showdetail/showdetail.module */ 33933)).then(m => m.ShowdetailPageModule)
    },
    {
        path: 'sellerdetail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_sellerdetail_sellerdetail_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./sellerdetail/sellerdetail.module */ 40188)).then(m => m.SellerdetailPageModule)
    },
    {
        path: 'expensedetail',
        loadChildren: () => Promise.all(/*! import() */[__webpack_require__.e("default-src_app_provider_apicall_service_ts"), __webpack_require__.e("src_app_expensedetail_expensedetail_module_ts")]).then(__webpack_require__.bind(__webpack_require__, /*! ./expensedetail/expensedetail.module */ 34202)).then(m => m.ExpensedetailPageModule)
    }
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = (0,tslib__WEBPACK_IMPORTED_MODULE_0__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_1__.NgModule)({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule.forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__.PreloadAllModules })
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__.RouterModule]
    })
], AppRoutingModule);



/***/ }),

/***/ 55041:
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppComponent": function() { return /* binding */ AppComponent; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !raw-loader!./app.component.html */ 91106);
/* harmony import */ var _app_component_scss__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./app.component.scss */ 43069);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ 51524);
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ 73494);
/* harmony import */ var _provider_global_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./provider/global.service */ 82836);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/router */ 39895);









let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, global, rout, loadingController) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.global = global;
        this.rout = rout;
        this.loadingController = loadingController;
        this.selectedIndex = 0;
        this.appPages = [
            {
                id: 1,
                title: 'Add Order',
                url: '/ordercat',
                icon: 'heart'
            },
            {
                id: 2,
                title: 'Add Raw Items',
                url: '/cat',
                icon: 'mail'
            },
            {
                id: 3,
                title: 'View Stock',
                url: '/stock',
                icon: 'paper-plane'
            },
            {
                id: 4,
                title: 'Add Menu',
                url: '/menu',
                icon: 'heart'
            },
            {
                id: 5,
                title: 'Order Details',
                url: '/order',
                icon: 'archive'
            },
            {
                id: 5,
                title: 'Account Detail',
                url: '/detail',
                icon: 'archive'
            },
            {
                id: 6,
                title: 'See All Transactions',
                url: '/transactions',
                icon: 'calendar'
            },
            {
                id: 7,
                title: 'Logout',
                url: '/',
                icon: 'power'
            },
        ];
        this.initializeApp();
    }
    router(route, id) {
        if (this.user.i_role == "admin") {
            this.rout.navigate([route]);
        }
        else if (this.user.i_role == "staff" && id == 1 || id == 2 || id == 6) {
            this.rout.navigate([route]);
        }
        else {
            this.presentLoadingWithOptions();
        }
    }
    presentLoadingWithOptions() {
        return (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__awaiter)(this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                spinner: null,
                duration: 500,
                message: "Sorry You Don't have access to this Feature",
                translucent: true,
                cssClass: 'custom-class custom-loading',
                backdropDismiss: true
            });
            yield loading.present();
            const { role, data } = yield loading.onDidDismiss();
        });
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
        });
    }
    ngOnInit() {
        this.global.User.subscribe(res => {
            this.user = res;
        });
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.Platform },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_2__.SplashScreen },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_3__.StatusBar },
    { type: _provider_global_service__WEBPACK_IMPORTED_MODULE_4__.GlobalService },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_7__.Router },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__.LoadingController }
];
AppComponent = (0,tslib__WEBPACK_IMPORTED_MODULE_5__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_8__.Component)({
        selector: 'app-root',
        template: _raw_loader_app_component_html__WEBPACK_IMPORTED_MODULE_0__.default,
        styles: [_app_component_scss__WEBPACK_IMPORTED_MODULE_1__.default]
    })
], AppComponent);



/***/ }),

/***/ 36747:
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppModule": function() { return /* binding */ AppModule; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ 39075);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/router */ 39895);
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ 80476);
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ 51524);
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ 73494);
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app.component */ 55041);
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./app-routing.module */ 90158);
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @angular/common/http */ 91841);
/* harmony import */ var ngx_electron__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ngx-electron */ 15439);
/* harmony import */ var ionic_selectable__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ionic-selectable */ 93319);












let AppModule = class AppModule {
};
AppModule = (0,tslib__WEBPACK_IMPORTED_MODULE_4__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_5__.NgModule)({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent],
        entryComponents: [],
        imports: [
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__.BrowserModule,
            _angular_common_http__WEBPACK_IMPORTED_MODULE_7__.HttpClientModule,
            _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicModule.forRoot(),
            _app_routing_module__WEBPACK_IMPORTED_MODULE_3__.AppRoutingModule,
            ngx_electron__WEBPACK_IMPORTED_MODULE_9__.NgxElectronModule,
            ionic_selectable__WEBPACK_IMPORTED_MODULE_10__.IonicSelectableModule
        ],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_1__.StatusBar,
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_0__.SplashScreen,
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_11__.RouteReuseStrategy, useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__.IonicRouteStrategy }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_2__.AppComponent]
    })
], AppModule);



/***/ }),

/***/ 82836:
/*!********************************************!*\
  !*** ./src/app/provider/global.service.ts ***!
  \********************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "GlobalService": function() { return /* binding */ GlobalService; }
/* harmony export */ });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! tslib */ 64762);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! rxjs */ 26215);



let GlobalService = class GlobalService {
    constructor() {
        this.user = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.User = this.user.asObservable();
        this.cat = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Cat = this.cat.asObservable();
        this.city = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.City = this.city.asObservable();
        this.products = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Products = this.products.asObservable();
        this.badge = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Badge = this.badge.asObservable();
        this.selected = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Selected = this.selected.asObservable();
        this.cart = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Cart = this.cart.asObservable();
        this.subcat = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Subcat = this.subcat.asObservable();
        this.subservices1 = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.SubServices1 = this.subservices1.asObservable();
        this.subservices2 = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.SubServices2 = this.subservices2.asObservable();
        this.usersdata = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Usersdata = this.usersdata.asObservable();
        this.id = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Id = this.id.asObservable();
        this.postsbyid = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Postsbyid = this.postsbyid.asObservable();
        this.worker1 = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Worker1 = this.worker1.asObservable();
        this.order = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Order = this.order.asObservable();
        this.profile = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Profile = this.profile.asObservable();
        this.image = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Image = this.image.asObservable();
        this.stock = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Stock = this.stock.asObservable();
        this.menu = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Menu = this.menu.asObservable();
        this.menusub = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Menusub = this.menusub.asObservable();
        this.catid = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Catid = this.catid.asObservable();
        this.all = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.All = this.all.asObservable();
        this.pending = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Pending = this.pending.asObservable();
        this.cancelled = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Cancelled = this.cancelled.asObservable();
        this.completed = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Completed = this.completed.asObservable();
        this.cimage = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Cimage = this.cimage.asObservable();
        this.less = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Less = this.less.asObservable();
        this.transactiondetail = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Transactiondetail = this.transactiondetail.asObservable();
        this.customer = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Customer = this.customer.asObservable();
        this.customerdetails = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Customerdetails = this.customerdetails.asObservable();
        this.sellerdetails = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Sellerdetails = this.sellerdetails.asObservable();
        this.expensedetails = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Expensedetails = this.expensedetails.asObservable();
        this.seller = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Seller = this.seller.asObservable();
        this.expense = new rxjs__WEBPACK_IMPORTED_MODULE_0__.BehaviorSubject('');
        this.Expense = this.expense.asObservable();
    }
    set_User(user) {
        this.user.next(user);
    }
    set_Catid(catid) {
        this.catid.next(catid);
    }
    set_All(all) {
        this.all.next(all);
    }
    set_Pending(pending) {
        this.pending.next(pending);
    }
    set_Cancelled(cancelled) {
        this.cancelled.next(cancelled);
    }
    set_Completed(completed) {
        this.completed.next(completed);
    }
    set_Cimage(cimage) {
        this.cimage.next(cimage);
    }
    set_Less(less) {
        this.less.next(less);
    }
    set_Transactiondetail(transactiondetail) {
        this.transactiondetail.next(transactiondetail);
    }
    set_Cat(cat) {
        this.cat.next(cat);
    }
    set_City(city) {
        this.city.next(city);
    }
    set_Stock(stock) {
        this.stock.next(stock);
    }
    set_Products(products) {
        this.products.next(products);
    }
    set_Selected(selected) {
        this.selected.next(selected);
    }
    set_Badge(badge) {
        this.badge.next(badge);
    }
    set_Cart(cart) {
        this.cart.next(cart);
    }
    set_Menu(menu) {
        this.menu.next(menu);
    }
    set_Menusub(menusub) {
        this.menusub.next(menusub);
    }
    set_Subcat(subcat) {
        this.subcat.next(subcat);
    }
    set_SubServices1(subservices1) {
        this.subservices1.next(subservices1);
    }
    set_SubServices2(subservices1) {
        this.subservices2.next(subservices1);
    }
    set_id(id) {
        this.id.next(id);
    }
    set_Postsbyid(postsbyid) {
        this.postsbyid.next(postsbyid);
    }
    set_Worker1(worker1) {
        this.worker1.next(worker1);
    }
    set_Order(order) {
        this.order.next(order);
    }
    set_Profile(profile) {
        this.profile.next(profile);
    }
    set_image(image) {
        this.image.next(image);
    }
    set_paimage(image) {
        this.image.next(image);
    }
    set_Customer(customer) {
        this.customer.next(customer);
    }
    set_Customerdetails(customerdetails) {
        this.customerdetails.next(customerdetails);
    }
    set_Sellerdetails(sellerdetails) {
        this.sellerdetails.next(sellerdetails);
    }
    set_Expensedetails(expensedetails) {
        this.expensedetails.next(expensedetails);
    }
    set_Seller(seller) {
        this.seller.next(seller);
    }
    set_Expense(expense) {
        this.expense.next(expense);
    }
};
GlobalService.ctorParameters = () => [];
GlobalService = (0,tslib__WEBPACK_IMPORTED_MODULE_1__.__decorate)([
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.Injectable)({
        providedIn: 'root'
    })
], GlobalService);



/***/ }),

/***/ 92340:
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "environment": function() { return /* binding */ environment; }
/* harmony export */ });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ 14431:
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ 37716);
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ 24608);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./app/app.module */ 36747);
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./environments/environment */ 92340);




if (_environments_environment__WEBPACK_IMPORTED_MODULE_1__.environment.production) {
    (0,_angular_core__WEBPACK_IMPORTED_MODULE_2__.enableProdMode)();
}
(0,_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_3__.platformBrowserDynamic)().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_0__.AppModule)
    .catch(err => console.log(err));


/***/ }),

/***/ 50863:
/*!******************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm/ lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \******************************************************************************************************************************************/
/***/ (function(module, __unused_webpack_exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		47321,
		"common",
		"node_modules_ionic_core_dist_esm_ion-action-sheet_entry_js"
	],
	"./ion-alert.entry.js": [
		36108,
		"common",
		"node_modules_ionic_core_dist_esm_ion-alert_entry_js"
	],
	"./ion-app_8.entry.js": [
		31489,
		"common",
		"node_modules_ionic_core_dist_esm_ion-app_8_entry_js"
	],
	"./ion-avatar_3.entry.js": [
		10305,
		"common",
		"node_modules_ionic_core_dist_esm_ion-avatar_3_entry_js"
	],
	"./ion-back-button.entry.js": [
		15830,
		"common",
		"node_modules_ionic_core_dist_esm_ion-back-button_entry_js"
	],
	"./ion-backdrop.entry.js": [
		37757,
		"node_modules_ionic_core_dist_esm_ion-backdrop_entry_js"
	],
	"./ion-button_2.entry.js": [
		30392,
		"common",
		"node_modules_ionic_core_dist_esm_ion-button_2_entry_js"
	],
	"./ion-card_5.entry.js": [
		66911,
		"common",
		"node_modules_ionic_core_dist_esm_ion-card_5_entry_js"
	],
	"./ion-checkbox.entry.js": [
		30937,
		"common",
		"node_modules_ionic_core_dist_esm_ion-checkbox_entry_js"
	],
	"./ion-chip.entry.js": [
		78695,
		"common",
		"node_modules_ionic_core_dist_esm_ion-chip_entry_js"
	],
	"./ion-col_3.entry.js": [
		16034,
		"node_modules_ionic_core_dist_esm_ion-col_3_entry_js"
	],
	"./ion-datetime_3.entry.js": [
		68837,
		"common",
		"node_modules_ionic_core_dist_esm_ion-datetime_3_entry_js"
	],
	"./ion-fab_3.entry.js": [
		34195,
		"common",
		"node_modules_ionic_core_dist_esm_ion-fab_3_entry_js"
	],
	"./ion-img.entry.js": [
		41709,
		"node_modules_ionic_core_dist_esm_ion-img_entry_js"
	],
	"./ion-infinite-scroll_2.entry.js": [
		33087,
		"node_modules_ionic_core_dist_esm_ion-infinite-scroll_2_entry_js"
	],
	"./ion-input.entry.js": [
		84513,
		"common",
		"node_modules_ionic_core_dist_esm_ion-input_entry_js"
	],
	"./ion-item-option_3.entry.js": [
		58056,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item-option_3_entry_js"
	],
	"./ion-item_8.entry.js": [
		10862,
		"common",
		"node_modules_ionic_core_dist_esm_ion-item_8_entry_js"
	],
	"./ion-loading.entry.js": [
		7509,
		"common",
		"node_modules_ionic_core_dist_esm_ion-loading_entry_js"
	],
	"./ion-menu_3.entry.js": [
		76272,
		"common",
		"node_modules_ionic_core_dist_esm_ion-menu_3_entry_js"
	],
	"./ion-modal.entry.js": [
		71855,
		"common",
		"node_modules_ionic_core_dist_esm_ion-modal_entry_js"
	],
	"./ion-nav_2.entry.js": [
		38708,
		"common",
		"node_modules_ionic_core_dist_esm_ion-nav_2_entry_js"
	],
	"./ion-popover.entry.js": [
		23527,
		"common",
		"node_modules_ionic_core_dist_esm_ion-popover_entry_js"
	],
	"./ion-progress-bar.entry.js": [
		24694,
		"common",
		"node_modules_ionic_core_dist_esm_ion-progress-bar_entry_js"
	],
	"./ion-radio_2.entry.js": [
		19222,
		"common",
		"node_modules_ionic_core_dist_esm_ion-radio_2_entry_js"
	],
	"./ion-range.entry.js": [
		25277,
		"common",
		"node_modules_ionic_core_dist_esm_ion-range_entry_js"
	],
	"./ion-refresher_2.entry.js": [
		39921,
		"common",
		"node_modules_ionic_core_dist_esm_ion-refresher_2_entry_js"
	],
	"./ion-reorder_2.entry.js": [
		83122,
		"common",
		"node_modules_ionic_core_dist_esm_ion-reorder_2_entry_js"
	],
	"./ion-ripple-effect.entry.js": [
		51602,
		"node_modules_ionic_core_dist_esm_ion-ripple-effect_entry_js"
	],
	"./ion-route_4.entry.js": [
		45174,
		"common",
		"node_modules_ionic_core_dist_esm_ion-route_4_entry_js"
	],
	"./ion-searchbar.entry.js": [
		7895,
		"common",
		"node_modules_ionic_core_dist_esm_ion-searchbar_entry_js"
	],
	"./ion-segment_2.entry.js": [
		76164,
		"common",
		"node_modules_ionic_core_dist_esm_ion-segment_2_entry_js"
	],
	"./ion-select_3.entry.js": [
		20592,
		"common",
		"node_modules_ionic_core_dist_esm_ion-select_3_entry_js"
	],
	"./ion-slide_2.entry.js": [
		27162,
		"node_modules_ionic_core_dist_esm_ion-slide_2_entry_js"
	],
	"./ion-spinner.entry.js": [
		81374,
		"common",
		"node_modules_ionic_core_dist_esm_ion-spinner_entry_js"
	],
	"./ion-split-pane.entry.js": [
		97896,
		"node_modules_ionic_core_dist_esm_ion-split-pane_entry_js"
	],
	"./ion-tab-bar_2.entry.js": [
		25043,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab-bar_2_entry_js"
	],
	"./ion-tab_2.entry.js": [
		77802,
		"common",
		"node_modules_ionic_core_dist_esm_ion-tab_2_entry_js"
	],
	"./ion-text.entry.js": [
		29072,
		"common",
		"node_modules_ionic_core_dist_esm_ion-text_entry_js"
	],
	"./ion-textarea.entry.js": [
		32191,
		"common",
		"node_modules_ionic_core_dist_esm_ion-textarea_entry_js"
	],
	"./ion-toast.entry.js": [
		40801,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toast_entry_js"
	],
	"./ion-toggle.entry.js": [
		67110,
		"common",
		"node_modules_ionic_core_dist_esm_ion-toggle_entry_js"
	],
	"./ion-virtual-scroll.entry.js": [
		10431,
		"node_modules_ionic_core_dist_esm_ion-virtual-scroll_entry_js"
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function() { return Object.keys(map); };
webpackAsyncContext.id = 50863;
module.exports = webpackAsyncContext;

/***/ }),

/***/ 43069:
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".app-logo {\n  background-image: url('a.jpeg');\n  height: 80px;\n  width: 80px;\n  background-repeat: no-repeat;\n  border-radius: 320px;\n  background-position: center;\n  background-size: contain;\n  background-color: #e3f8ff;\n  margin: 75px auto;\n}\n\nion-list {\n  margin: 0;\n  background-color: var(--ion-color-dark);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFwcC5jb21wb25lbnQuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLCtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSw0QkFBQTtFQUNBLG9CQUFBO0VBQ0EsMkJBQUE7RUFDQSx3QkFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7QUFDRjs7QUFDQTtFQUNFLFNBQUE7RUFDQSx1Q0FBQTtBQUVGIiwiZmlsZSI6ImFwcC5jb21wb25lbnQuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5hcHAtbG9nb3tcbiAgYmFja2dyb3VuZC1pbWFnZTogdXJsKC4uL2Fzc2V0cy9hLmpwZWcpO1xuICBoZWlnaHQ6IDgwcHg7XG4gIHdpZHRoOiA4MHB4O1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBib3JkZXItcmFkaXVzOiAzMjBweDtcbiAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyO1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvbnRhaW47XG4gIGJhY2tncm91bmQtY29sb3I6ICNlM2Y4ZmY7XG4gIG1hcmdpbjogNzVweCBhdXRvO1xufVxuaW9uLWxpc3R7XG4gIG1hcmdpbjogMDtcbiAgYmFja2dyb3VuZC1jb2xvcjogdmFyKC0taW9uLWNvbG9yLWRhcmspO1xufVxuIl19 */");

/***/ }),

/***/ 91106:
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-app>\n  <ion-split-pane contentId=\"main-content\">\n    <ion-menu contentId=\"main-content\" type=\"reveal\"  translucent>\n      <ion-content color=\"dark\">\n        <div class=\"app-logo\">\n        </div>\n        \n\n        <ion-list  >\n          \n          <ion-menu-toggle auto-hide=\"false\" *ngFor=\"let p of appPages; let i = index\" lines=\"none\" >\n            <ion-item (click)=\"selectedIndex = i\" color=\"dark\"  routerDirection=\"root\"  (click)=\"router(p.url,p.id)\"  detail=\"false\" [class.selected]=\"selectedIndex == i\">\n              <ion-icon slot=\"start\" [ios]=\"p.icon + '-outline'\" [md]=\"p.icon + '-sharp'\"></ion-icon>\n              <ion-label >{{ p.title }}</ion-label>\n            </ion-item>\n          </ion-menu-toggle>\n        </ion-list>\n      </ion-content>\n    </ion-menu>\n    <ion-router-outlet id=\"main-content\"></ion-router-outlet>\n  </ion-split-pane>\n</ion-app>\n\n");

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
/******/ __webpack_require__.O(0, ["vendor"], function() { return __webpack_exec__(14431); });
/******/ var __webpack_exports__ = __webpack_require__.O();
/******/ }
]);
//# sourceMappingURL=main-es2015.js.map